/*
 *<b>Ballistica Version 2.1 "Foe-hammer". </b><br>
 *<b>Copyright 2014 Ballistica Software Defined Scope System (SDSS)</b><br>
 *<pre>
 *   This program is free software: you can redistribute it and/or modify<br>
 *   it under the terms of the GNU General Public License as published by<br>
 *   the Free Software Foundation, either version 3 of the License, or<br>
 *   (at your option) any later version.<br>
 *   <br>
 *   This program is distributed in the hope that it will be useful,<br>
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of<br>
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the<br>
 *   GNU General Public License for more details.<br>
 *   <br>
 *   You should have received a copy of the GNU General Public License<br>
 *   along with this program.  If not, see &lt;http://www.gnu.org/licenses/&gt;.<br>
 * </pre>
 * <pre>
 *   This file is part of Ballistica.<br>
 *   <br>
 *   Ballistica is free software: you can redistribute it and/or modify<br>
 *   it under the terms of the GNU General Public License as published by<br>
 *   the Free Software Foundation, either version 3 of the License, or<br>
 *   (at your option) any later version.<br>
 *   <br>
 *   Ballistica is distributed in the hope that it will be useful,<br>
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of<br>
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the<br>
 *   GNU General Public License for more details.<br>
 *   <br>
 *   You should have received a copy of the GNU General Public License<br>
 *     along with Ballistica.  If not, see &lt;http://www.gnu.org/licenses/&gt;.<br>
*/
#include "Environmentalstatus.h"
Environmentalstatus::Environmentalstatus() {
	 iENVStatIterationControl = 0; // checking environment every iteration of the loop may be too much. For an aerial platform, the frequency of this check might have to increase as altitude and barometric can change rapidly.
	 iENVStatReset = 100;    // Check every 100th time in this case
	 changeEvent = true;
	 barometric = 29.59;		// defaults
	 temperature = 70.00;
	 relativeHumidity = .7;
}
Environmentalstatus::~Environmentalstatus() {}
bool Environmentalstatus::isChanged(){
	// The actual value would be a flag meaning "a change took place". This is always set to false each call.
	if(iENVStatIterationControl++ > iENVStatReset) { // Check for environmental changes.
		iENVStatIterationControl = 0; // reset nth counter
		return checkENVStatusUpdate();
	} // if
	return false;       // not checking yet
}
bool Environmentalstatus::checkENVStatusUpdate(){
	//  The goal of this function is to make the necessary API calls into any system
	//  that may be monitoring the environment. This would be a device such as a weather monitor
	//  for example.
	//  This is driven by the main control loop.
	return changeEvent;
}
void Environmentalstatus::setRelativeHumidity(double direction){
	changeEvent = true;
	windAngle = direction;
}
double Environmentalstatus::getRelativeHumidity(){
	return relativeHumidity;
}
void Environmentalstatus::setWindDirection(double direction){
	changeEvent = true;
	windAngle = direction;
}
double Environmentalstatus::getWindDirection(){
	return windAngle;
}
void Environmentalstatus::setWindSpeed(double speed){
	windSpeed = speed;
	changeEvent = true;
}
double Environmentalstatus::getWindSpeed(){
	return windSpeed;
}
void Environmentalstatus::setTempurature(double temp){
	changeEvent = true;
	temperature = temp;
}
double Environmentalstatus::getTempurature(){
	return temperature;
}
void Environmentalstatus::setBarometric(double baro){
	changeEvent = true;
	barometric = baro;
}
double Environmentalstatus::getBarometric(){
	return barometric;
}
void Environmentalstatus::setAltitude(double alt){
	changeEvent = true;
	altitude = alt;
}
double Environmentalstatus::getAltitude(){
	return altitude;
}
void Environmentalstatus::drawWindDirection(Mat& g, int x, int y){
	// Incoming X and Y values are the screen center.
	Scalar color = Scalar(0,255,255);
	ellipse(g, Point(x, y), Size( 50, 50), 0, 0, 360, color,2, 1, 0);
	color = Scalar(0,0,255);
	vector<Point> points;
	switch((int)windAngle){// The wind angle (0=headwind, 90=right to left, 180=tailwind, 270/-90=left to right
		case(0):{    // Headwind arrow
			points.push_back(Point(x,y));
			points.push_back(Point(x+10, y-55));
			points.push_back(Point(x-10,y-55));
			break;
		} // 0
		case(90):{// Right to left arrow
			points.push_back(Point(x+55,y-10));
			points.push_back(Point(x+55,y+10));
			points.push_back(Point(x,y));
			break;
		} // 0
		case(180):{ // Tailwind arrow
			points.push_back(Point(x,y));
			points.push_back(Point(x+10,y+55));
			points.push_back(Point(x-10,y+55));
			break;
		} // 0
		case(270):{ // Left to right arrow
			points.push_back(Point(x,y));
			points.push_back(Point(x-55,y-10));
			points.push_back(Point(x-55,y+10));
			break;
		} // 0
		default:{ // Oddity?
			points.push_back(Point(x,y));
			points.push_back(Point(x-10,y-10));
			points.push_back(Point(x+10,y-10));
			break;
		}  // default
	} // switch
	vector<vector<Point> > polygons;
	polygons.push_back(points);
	fillPoly(g, polygons, color, 8,0, Point(0,0));
	color = Scalar(0,255,255);
		// Show the wind speed alongside the reticle
	stringstream oss;
	oss << "WIND DIREC " << windAngle;
	putText(g, oss.str(),Point(x + 62, y + 10), 1, 0.9, color, 1, 1, false);
	oss.str("");
	oss << "WIND SPEED " <<  windSpeed;
	putText(g, oss.str(),Point( x + 62, y + 30), 1, 0.9, color, 1, 1, false);
}


void Environmentalstatus::drawTempuratureIndication(Mat& g, int x, int y){
	rectangle(g, Rect(x, y-20, 10, 40),Scalar(0,0,255), 1, 1, 0);
	for (int incr = y-20; incr < y+20; incr+=5){
		line(g, Point(x-10, incr), Point(x, incr), Scalar(0,0,255), 1,1,0);
	} // for
	stringstream oss;
	oss << "TEMP: " <<  temperature;
	putText(g, oss.str(),Point(x+15, y-20), 1, 0.9, Scalar(0,0,255), 1, 1, false);
}
void Environmentalstatus::drawBarometricIndication(Mat& g, int x, int y){
	rectangle(g, Rect(x, y-50, 10, y), Scalar(255,255,255), 1, 1, 0);
	for (int incr = y-50; incr < y+100; incr+=10){
		line(g, Point(x-10, incr), Point(x, incr), Scalar(255,255,255), 1,1,0);
	} // for
	stringstream oss;
	oss << "BARO: " << barometric;
	putText(g, oss.str(), Point(x+15, y-20), 1, 0.9, Scalar(255,255,255), 1, 1, false);
}
void Environmentalstatus::drawAltitudeIndication(Mat &g, int x, int y){
	for (int incr = y-50; incr < y+100; incr+=10){
		line(g, Point(x, incr), Point(x+20, incr), Scalar(0,255,255), 2,1,0);
	} // for
	stringstream oss;
	oss << "ALTITUDE " << altitude;
	putText(g, oss.str(), Point(x+30, y-20), 1, 0.9, Scalar(0,255,255), 1, 1, false);
}
