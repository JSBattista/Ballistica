/*
Ballistica 2.1
 *<b>Ballistica Version 2 "Foe-hammer". </b><br>
 *<b>Copyright 2014 Ballistica Software Defined Scope System (SDSS)</b><br>
 *<pre>
 *   This program is free software: you can redistribute it and/or modify<br>
 *   it under the terms of the GNU General Public License as published by<br>
 *   the Free Software Foundation, either version 3 of the License, or<br>
 *   (at your option) any later version.<br>
 *   <br>
 *   This program is distributed in the hope that it will be useful,<br>
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of<br>
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the<br>
 *   GNU General Public License for more details.<br>
 *   <br>
 *   You should have received a copy of the GNU General Public License<br>
 *   along with this program.  If not, see &lt;http://www.gnu.org/licenses/&gt;.<br>
 * </pre>
 * <pre>
 *   This file is part of Ballistica.<br>
 *   <br>
 *   Ballistica is free software: you can redistribute it and/or modify<br>
 *   it under the terms of the GNU General Public License as published by<br>
 *   the Free Software Foundation, either version 3 of the License, or<br>
 *   (at your option) any later version.<br>
 *   <br>
 *   Ballistica is distributed in the hope that it will be useful,<br>
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of<br>
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the<br>
 *   GNU General Public License for more details.<br>
 *   <br>
 *   You should have received a copy of the GNU General Public License<br>
 *     along with Ballistica.  If not, see &lt;http://www.gnu.org/licenses/&gt;.<br>
*/
#ifndef CALIBRATOR_H_
#define CALIBRATOR_H_
#include <opencv2\highgui\highgui.hpp>
#include <opencv2\imgproc\imgproc.hpp>
#include <opencv2\core\core.hpp>
class Calibrator {
public:
    Calibrator();
    virtual ~Calibrator();
    void setLowPixCap();
    void setHighPixCap();
    bool getCalCapStatus();
    bool lowCaptured();
    bool highCaptured();
    double getLowPixelCal();
    double getHighPixelCal();
    void incrementCalibrationDistance();
    void decrementCalibrationDistance();
    int getCalibrationYardage();
    void displayThroughCalibrationCapture(cv::Mat&);
private:
    cv::Rect *calRect;
    unsigned long scanArea;
    int lowmagpixelscap;
    int maxmagpixelscap;
    int minx;
    int miny;
    int maxx;
    int maxy;
    int caldistance;
    bool caplow;
    bool caphigh;
    bool lowcapped;
    bool highcapped;
};
#endif /* CALIBRATOR_H_ */
