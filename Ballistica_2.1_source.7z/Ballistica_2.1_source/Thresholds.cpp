/*
 *<b>Ballistica Version 2.1 "Foe-hammer". </b><br>
 *<b>Copyright 2014 Ballistica Software Defined Scope System (SDSS)</b><br>
 *<pre>
 *   This program is free software: you can redistribute it and/or modify<br>
 *   it under the terms of the GNU General Public License as published by<br>
 *   the Free Software Foundation, either version 3 of the License, or<br>
 *   (at your option) any later version.<br>
 *   <br>
 *   This program is distributed in the hope that it will be useful,<br>
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of<br>
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the<br>
 *   GNU General Public License for more details.<br>
 *   <br>
 *   You should have received a copy of the GNU General Public License<br>
 *   along with this program.  If not, see &lt;http://www.gnu.org/licenses/&gt;.<br>
 * </pre>
 * <pre>
 *   This file is part of Ballistica.<br>
 *   <br>
 *   Ballistica is free software: you can redistribute it and/or modify<br>
 *   it under the terms of the GNU General Public License as published by<br>
 *   the Free Software Foundation, either version 3 of the License, or<br>
 *   (at your option) any later version.<br>
 *   <br>
 *   Ballistica is distributed in the hope that it will be useful,<br>
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of<br>
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the<br>
 *   GNU General Public License for more details.<br>
 *   <br>
 *   You should have received a copy of the GNU General Public License<br>
 *     along with Ballistica.  If not, see &lt;http://www.gnu.org/licenses/&gt;.<br>
*/
#include "Thresholds.h"
#include <stdio.h>
Thresholds::Thresholds() {
	// TODO Auto-generated constructor stub
	lighting_setRangeMIN = 0;
	lighting_setRangeMAX = 40;
	levelIndex = 0;
}
Thresholds::~Thresholds() {
	// TODO Auto-generated destructor stub
}
void Thresholds::setLightLevel(int level){
	if(level > lighting_setRangeMAX)levelIndex = lighting_setRangeMAX;
	if(level < lighting_setRangeMIN)levelIndex = lighting_setRangeMIN;
	switch (level) {
		case 0:{levelIndex = 10;setLightOnDark(levelIndex);break;}// 0 - 10 are light on dark settings
		case 1:{levelIndex = 10;setLightOnDark(levelIndex);break;}
		case 2:{levelIndex = 10;setLightOnDark(levelIndex);break;}
		case 3:{levelIndex = 10;setLightOnDark(levelIndex);break;}
		case 4:{levelIndex = 10;setLightOnDark(levelIndex);break;}
		case 5:{levelIndex = 10;setLightOnDark(levelIndex);break;}
		case 6:{levelIndex = 10;setLightOnDark(levelIndex);break;}
		case 7:{levelIndex = 10;setLightOnDark(levelIndex);break;}
		case 8:{levelIndex = 10;setLightOnDark(levelIndex);break;}
		case 9:{levelIndex = 10;setLightOnDark(levelIndex);break;}
		case 10:{
			levelIndex = 10;
			setLightOnDark(levelIndex);
			break;} // 10
		case 11:{levelIndex = 20;setLightOnLight(levelIndex);break;}
		case 12:{levelIndex = 20;setLightOnLight(levelIndex);break;}
		case 13:{levelIndex = 20;setLightOnLight(levelIndex);break;}
		case 14:{levelIndex = 20;setLightOnLight(levelIndex);break;}
		case 15:{levelIndex = 20;setLightOnLight(levelIndex);break;}
		case 16:{levelIndex = 20;setLightOnLight(levelIndex);break;}
		case 17:{levelIndex = 20;setLightOnLight(levelIndex);break;}
		case 18:{levelIndex = 20;setLightOnLight(levelIndex);break;}
		case 19:{
			levelIndex = 20;
			setLightOnLight(levelIndex);
			break;}
		case 20:{ // 11 - 20 are light on light settings
			levelIndex = 20;
			setLightOnLight(levelIndex);
			break;
		} // 20
		case 21:{levelIndex = 30;setDarkOnLight(levelIndex);break;}// 21-30 are dark on light settings
		case 22:{levelIndex = 30;setDarkOnLight(levelIndex);break;}
		case 23:{levelIndex = 30;setDarkOnLight(levelIndex);break;}
		case 24:{levelIndex = 30;setDarkOnLight(levelIndex);break;}
		case 25:{levelIndex = 30;setDarkOnLight(levelIndex);break;}
		case 26:{levelIndex = 30;setDarkOnLight(levelIndex);break;}
		case 27:{levelIndex = 30;setDarkOnLight(levelIndex);break;}
		case 28:{levelIndex = 30;setDarkOnLight(levelIndex);break;}
		case 29:{levelIndex = 30;setDarkOnLight(levelIndex);break;}
		case 30:{
			levelIndex = 30;
			setDarkOnLight(levelIndex);
			break;
		} // 30
		case 31:{levelIndex = 40;setDarkOnDark(levelIndex);break;}// 31-40 are dark on dark settings
		case 32:{levelIndex = 40;setDarkOnDark(levelIndex);break;}
		case 33:{levelIndex = 40;setDarkOnDark(levelIndex);break;}
		case 34:{levelIndex = 40;setDarkOnDark(levelIndex);break;}
		case 35:{levelIndex = 40;setDarkOnDark(levelIndex);break;}
		case 36:{levelIndex = 40;setDarkOnDark(levelIndex);break;}
		case 37:{levelIndex = 40;setDarkOnDark(levelIndex);break;}
		case 38:{levelIndex = 40;setDarkOnDark(levelIndex);break;}
		case 39:{levelIndex = 40;setDarkOnDark(levelIndex);break;}
		case 40:{
			levelIndex = 40;
			setDarkOnDark(levelIndex);
			break;
		} // 40
		case 41:{
			levelIndex = 0;
			setDefaultLighting();
			break;
		} // 41
		default:{
			levelIndex = 0;
			break;
		}
	} // switch
	// Note: further additional case blocks that represent other light spectrums
	// should have a value that represents the starting wavelengh of the band.
}
void Thresholds::setDefaultLighting(){
	lighting_low          = 65;        // default values
	lighting_high         = 255;
	lighting_smooth       = 1;
	lighting_type         = CV_THRESH_BINARY;
}
void Thresholds::setZeroLightingParameters(){
	lighting_low          = 0;        // default values
	lighting_high         = 0;
	lighting_smooth       = 1;
	lighting_type         = CV_THRESH_BINARY;
}
void Thresholds::setDirectLighting(int a, int b, int c, int d){
	lighting_low = a;
	lighting_high = b;
	lighting_smooth = c;
	if (d > 4) d = 0;
	lighting_type = d;
}
void Thresholds::setDirectType(int i) {
	// See OpenCV Imgproc settings
	if (i > 4) i = 0;
	lighting_type = i;
}
void Thresholds::setLightOnDark(int level){
	   switch (level) {
		case 10: {
			lighting_low = 1;
			lighting_high = 255;
			lighting_smooth = 3;  // This can really bog down a blur algorithm so don't use this in a "wide area" scan
			lighting_type = CV_THRESH_TOZERO_INV;
			highcolor = cv::Scalar(255,255,255);//WHITE
			lowcolor = cv::Scalar(0,0,0);//BLACK
			break;
		} //case 10
		default :{setDefaultLighting();break;} // default
	} // switch
}
void Thresholds::setLightOnLight(int level){
	switch (level) {
		case 19:{
			lighting_low = 1;
			lighting_high = 255;
			lighting_smooth = 1;
			lighting_type = CV_THRESH_BINARY_INV;
			highcolor = cv::Scalar(170,170,170);//GRAY;
			lowcolor = cv::Scalar(85,85,85);//DARK_GRAY;
			return;
		} //case 19
		case 20:{
			lighting_low = 0;
			lighting_high = 1;
			lighting_smooth = 17;// This can really bog down a blur algorithm so don't use this in a "wide area" scan
			lighting_type = CV_THRESH_BINARY_INV;
			highcolor = cv::Scalar(170,170,170);//GRAY;
			lowcolor = cv::Scalar(85,85,85);//DARK_GRAY;
			return;
		} //case 20
		default :{setDefaultLighting();break;} // default
	} // switch
}
void Thresholds::setDarkOnLight(int level){
	switch (level) {
		case 30: {
			lighting_low = 194;
			lighting_high = 24;
			lighting_smooth = 19;// This can really bog down a blur algorithm so don't use this in a "wide area" scan
			lighting_type = CV_THRESH_BINARY;
			highcolor = cv::Scalar(0,0,0);//BLACK;
			lowcolor = cv::Scalar(255,255,255);//WHITE
			break;
		} // case 30
		default :{setDefaultLighting();
				break;
		} // default
	} // switch
}
void Thresholds::setDarkOnDark(int level){
	switch (level) {
		case 40: {
			lighting_low = 45;
			lighting_high = 60;
			lighting_smooth = 9;
			lighting_type = CV_THRESH_TOZERO;
			highcolor = cv::Scalar(85,85,85); //DARK_GRAY
			lowcolor = cv::Scalar(0,0,0);//BLACK
			break;
		} // case 40
		default :{setDefaultLighting();
			break;
		} // default
	} // switch
}
void Thresholds::incrementLightLevel(){
	levelIndex++;
	setLightLevel(levelIndex);
}
void Thresholds::decrementLightLevel(){
	levelIndex--;
	setLightLevel(levelIndex);
}
void Thresholds::drawLightSettingSymbol(cv::Mat g, int x, int y){
	rectangle(g,cv::Point( x-50, y-50 ),cv::Point( x+50, y+50),lowcolor,-1,0);
	circle(g,cv::Point( x, y ),25,highcolor,3,8,0 );
}