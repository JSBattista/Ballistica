/*
 *<b>Ballistica Version 2.1 "Foe-hammer". </b><br>
 *<b>Copyright 2014 Ballistica Software Defined Scope System (SDSS)</b><br>
 *<pre>
 *   This program is free software: you can redistribute it and/or modify<br>
 *   it under the terms of the GNU General Public License as published by<br>
 *   the Free Software Foundation, either version 3 of the License, or<br>
 *   (at your option) any later version.<br>
 *   <br>
 *   This program is distributed in the hope that it will be useful,<br>
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of<br>
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the<br>
 *   GNU General Public License for more details.<br>
 *   <br>
 *   You should have received a copy of the GNU General Public License<br>
 *   along with this program.  If not, see &lt;http://www.gnu.org/licenses/&gt;.<br>
 * </pre>
 * <pre>
 *   This file is part of Ballistica.<br>
 *   <br>
 *   Ballistica is free software: you can redistribute it and/or modify<br>
 *   it under the terms of the GNU General Public License as published by<br>
 *   the Free Software Foundation, either version 3 of the License, or<br>
 *   (at your option) any later version.<br>
 *   <br>
 *   Ballistica is distributed in the hope that it will be useful,<br>
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of<br>
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the<br>
 *   GNU General Public License for more details.<br>
 *   <br>
 *   You should have received a copy of the GNU General Public License<br>
 *     along with Ballistica.  If not, see &lt;http://www.gnu.org/licenses/&gt;.<br>
*/
#include "Targetbox.h"
#include <iostream>
#include <stdio.h>
#include <cmath>
using namespace std;
using namespace cv;
Targetbox::Targetbox() {
	decay  = 1000;
	defaultL = 60;      // Default Length of box
	defaultH = 60;      // Default Height of box
}
Targetbox::~Targetbox() { }
Targetbox::Targetbox(int x, int y){
	defaultL = 60;      // Default Length of box
	defaultH = 60;      // Default Height of box
	screenReferenceCOG = cv::Point(x, y);
	subboxReferenceCOG = cv::Point((int)defaultL/2, (int)defaultH/2);   // Center in the cv::Rect Construct
	sbrect = cv::Rect(x, y, defaultL, defaultH);
	color  = cv::Scalar(255.000,255.000,255.000);
	decay  = 10000;
}
Targetbox::Targetbox(int x, int y, int w, int h){
	defaultL = 60;      // Default Length of box
	defaultH = 60;      // Default Height of box
	screenReferenceCOG = cv::Point(x, y);
	subboxReferenceCOG = cv::Point((int)w/2, (int)h/2);   // Center in the cv::Rect Construct
	sbrect = cv::Rect(x, y, w, h);
	color  = cv::Scalar(255.000,255.000,255.000);
	decay  = 10000;
}
void Targetbox::setTargeBox(int cogx, int cogy, int boxl, int boxw){ // Keep Length and Width in here for Area mods later on.
	subboxReferenceCOG = cv::Point((int)boxl/2, (int)boxw/2);  // Always center of box
	sbrect = cv::Rect(cogx-((int)(boxl/2)), cogy-((int)(boxw/2)), boxl, boxw);
}
cv::Rect Targetbox::getTargetBox()
{
	return sbrect;  // return cv::Rect dimensions to be used to sub-box the main input.
}
bool Targetbox::checkROIBoundaries(int imgx, int imgy){
	if((sbrect.x + sbrect.width/2) >= imgx-10) return false;  // X bounds exceeded.
	if((sbrect.x - sbrect.width/2) <= 0+10) return false; // unlikely but check anyway
	if((sbrect.y + sbrect.height/2) >= imgy-10) return false;  // Y bounds exceeded.
	if((sbrect.y - sbrect.height/2) <= 0+10) return false; // unlikely but check anyway
	return true; // made it this far, checks good.
}
void Targetbox::applyCOGDisplacement(cv::Point newCOG){
	//  This function is called after there is a movement detecton in a sub-box,
	//  The COG of the box itself is always the center, and the box itself was searched for movement (plus a little more),
	//  But the entire cv::Rect that defines the target box must be moved the distance of the displacement
	//  of the incoming COG data the differs from the cog of the sub-box.
	if (newCOG == subboxReferenceCOG) return;  // unlikely
	if(newCOG.x < subboxReferenceCOG.x) {
		sbrect.x             -= abs(newCOG.x - subboxReferenceCOG.x);  // move the entire cv::Rect's position on the entire screen.
		screenReferenceCOG.x -= abs(newCOG.x - subboxReferenceCOG.x);  // Adjust the COG of the movement detected as carried in from the cvmoment call results
	} else if (newCOG.x > subboxReferenceCOG.x){
		sbrect.x		     += abs(newCOG.x - subboxReferenceCOG.x);
		screenReferenceCOG.x += abs(newCOG.x - subboxReferenceCOG.x);
	} else {
		// nothing
	}  // if
	if(newCOG.y < subboxReferenceCOG.y) {
		sbrect.y		     -= abs(newCOG.y - subboxReferenceCOG.y);
		screenReferenceCOG.y -= abs(newCOG.y - subboxReferenceCOG.y);
	} else if (newCOG.y > subboxReferenceCOG.y){
		sbrect.y			 += abs(newCOG.y - subboxReferenceCOG.y);
		screenReferenceCOG.y += abs(newCOG.y - subboxReferenceCOG.y);
	} else {
		// nothing
	}  // if
}
void Targetbox::drawTargetBox(Mat& g){  // Simple indication is something - non-lock
	cv::rectangle(g, Rect(sbrect.x-(int)(sbrect.width/2),sbrect.y-(int)(sbrect.height/2),sbrect.height, sbrect.width), color, 2, 1, 0);
}
cv::Point  Targetbox::getTargetBoxCenter(){
	cv::Point p = cv::Point();
	p.x = sbrect.x + (int)(sbrect.width/2);
	p.y = sbrect.y + (int)(sbrect.height/2);
	return p;
}