/*
 *<b>Ballistica Version 2.1 "Foe-hammer". </b><br>
 *<b>Copyright 2014 Ballistica Software Defined Scope System (SDSS)</b><br>
 *<pre>
 *   This program is free software: you can redistribute it and/or modify<br>
 *   it under the terms of the GNU General Public License as published by<br>
 *   the Free Software Foundation, either version 3 of the License, or<br>
 *   (at your option) any later version.<br>
 *   <br>
 *   This program is distributed in the hope that it will be useful,<br>
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of<br>
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the<br>
 *   GNU General Public License for more details.<br>
 *   <br>
 *   You should have received a copy of the GNU General Public License<br>
 *   along with this program.  If not, see &lt;http://www.gnu.org/licenses/&gt;.<br>
 * </pre>
 * <pre>
 *   This file is part of Ballistica.<br>
 *   <br>
 *   Ballistica is free software: you can redistribute it and/or modify<br>
 *   it under the terms of the GNU General Public License as published by<br>
 *   the Free Software Foundation, either version 3 of the License, or<br>
 *   (at your option) any later version.<br>
 *   <br>
 *   Ballistica is distributed in the hope that it will be useful,<br>
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of<br>
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the<br>
 *   GNU General Public License for more details.<br>
 *   <br>
 *   You should have received a copy of the GNU General Public License<br>
 *     along with Ballistica.  If not, see &lt;http://www.gnu.org/licenses/&gt;.<br>
*/
#include "Reticle.h"
#include <iostream>
#include <string>
#include <stdio.h>
#include <sstream>
#include <fstream>
#include <vector>
#include "rapidxml-1.13/rapidxml.hpp"
using  namespace cv;
using namespace std;
using namespace rapidxml;
Reticle::Reticle(std::map<std::string, FPtr>) {}
Reticle::Reticle(int x, int y, std::map<std::string, FPtr> functionmap){
	xmax	= x;
	ymax	= y;
	hpx     = (int) x/2;
	hpy	= (int) y/2;
	trackingRect = Rect(0,0,28,28);
	traversalRect = Rect(0,0,28,28);
	trackingColor = Scalar(0,0,255);
	traversalColor = Scalar(0,255,0);
	statlinecount = 8;
	reticleElements = NULL;
}
Reticle::Reticle(Rect d, std::map<std::string, FPtr> functionmap){
	xmax	= d.width;
	ymax	= d.height;
	hpx     = (int) d.width/2;
	hpy	    = (int) d.height/2;
	trackingRect = Rect(0,0,28,28);
	traversalRect = Rect(0,0,28,28);
	trackingColor = Scalar(0,0,255);
	traversalColor = Scalar(0,255,0);
	statlinecount = 8;
	reticleElements = NULL;
}
Reticle::Reticle(int x, int y, std::map<std::string, FPtr> functionmap, string filename){
	reticleElements = NULL;
	RETElement *tEle = new RETElement();
	xmax	= x;
	ymax	= y;
	hpx     = (int) x/2;
	hpy	= (int) y/2;
	trackingRect = Rect(0,0,28,28);
	traversalRect = Rect(0,0,28,28);
	trackingColor = Scalar(0,0,255);
	traversalColor = Scalar(0,255,0);
	statlinecount = 8;
	windage = functionmap["windage"];	
	elevation = functionmap["elevation"];
	reticleElements = NULL;
	xml_document<> doc;
	xml_node<> * root_node;
	// Read the xml file into a vector
	ifstream reticlefile (filename);
	vector<char> buffer((istreambuf_iterator<char>(reticlefile)), istreambuf_iterator<char>());
	buffer.push_back('\0');
	doc.parse<0>(&buffer[0]);
	root_node = doc.first_node("Reticle");
	for (xml_node<> * r_element_node = root_node->first_node("r_element"); r_element_node; r_element_node = r_element_node->next_sibling()) {	
		string fMapRef = r_element_node->first_attribute("function")->value();
		if(fMapRef.empty()){
			tEle->FnPtr = NULL;
		} else {
			tEle->FnPtr = functionmap[fMapRef];		// Pointer to function in Ballistica to call on other member functions.
		} // if
		tEle->s = r_element_node->first_attribute("label")->value();
		if (!(tEle->s.empty()))tEle->fontscale = atof(r_element_node->first_attribute("fontscale")->value());
		int ia[]={0,0,0};
		std::istringstream ss(r_element_node->first_attribute("color")->value());
		std::string token;
		int index = 0;
		while((index < 3) && (std::getline(ss, token, ','))) {
			ia[index] = atoi(token.c_str());
			index++;
		}	// while
		tEle->drawcolor = Scalar(ia[0],ia[1],ia[2]);  // direct scalar 
		tEle->fill = atoi(r_element_node->first_attribute("fill")->value());
		vector<Point> points;
		for(xml_node<> * point_node = r_element_node->first_node("point"); point_node; point_node = point_node->next_sibling()) { // install x and y location points.
			tEle->points.push_back(Point(atoi(point_node->first_attribute("x")->value()), atoi(point_node->first_attribute("y")->value()))); // Directly into the node itself
		}  // for		
		tEle->p = reticleElements;  // Push
		reticleElements = tEle;
	} // for	
}
void Reticle::resetReticleFrameDIM(int x, int y){
	xmax	= x;
	ymax	= y;
	hpx     = (int) x/2;
	hpy	= (int) y/2;
	reticleElements = NULL;
}
void Reticle::drawReticleTrackingRect(Mat& g, int x, int y, string s, int imod){
	trackingRect.x = x-(trackingRect.width/2);
	trackingRect.y = y-(trackingRect.height/2);
	rectangle(g, trackingRect, trackingColor, 1, 1, 0);
	ostringstream oss;
	oss << s;
	putText(g, oss.str(),Point(trackingRect.x-20,trackingRect.y -imod), 1, 0.6, traversalColor, 1, 1, false);
}
void Reticle::drawTraversalReticle(Mat& g, int x, int y, double speed){
	traversalRect.x = x - (int)(traversalRect.width/2);
	traversalRect.y = y - (int)(traversalRect.height/2);
	rectangle(g,traversalRect,traversalColor, 1, 1, 0);	
	ostringstream oss;
	oss << "SPEED : " << speed;
	putText(g, oss.str(),Point(x + (int)(traversalRect.width/2), (int)(y - traversalRect.height/2)), 1, 0.9, traversalColor, 1, 1, false);
}
void Reticle::drawReticleCenterReference(Mat &g){
	setDrawColor(YELLOW);
	line(g, Point(hpx-10,  hpy), Point(hpx+10, hpy), color, 1,1,0);
	line(g, Point(hpx, hpy-10), Point(hpx, hpy +10), color, 1,1,0);
}
void Reticle::drawReticle_text(Mat& g, int x, int y, string s){
	setDrawColor(WHITE);
	putText(g,s,Point(x, y), 1, 0.9, color, 1, 1, false);
}
void Reticle::drawCalibrationSquare(Mat& g, int x, int y, int pixeldimension){
	// The point of this function is to create a calibration square using "inches per pixel" data derived from the calibration of the camera.
	// Drawing a square of "known size" into the screen makes it possible then to calibrate the system or detect miscalibration.
	// This function could also be a demonstration of a range-finding indicator that, having converted known size of an object at
	// a given range with a given magnification, can be drawn here and compared to objects at range to determine the range of the object.
	putText(g, "CALIBRATION SQUARE",Point( x, y-40), 1, 1.0, Scalar(0,0,255), 1, 1, false);
	rectangle(g, Rect(x,y,pixeldimension, pixeldimension), Scalar(0,0,255), 1, 1, 0);
}
void Reticle::drawRangingCarrette(Mat& g, int x, int y, int pixeldimension, int range){
	rectangle(g, Rect(x,y,20,5),Scalar(200,200,200), 2, 1, 0);
	stringstream oss;
	oss << "RANGE: " << range;
	putText(g, oss.str(), Point( x+30, y), 1, 1.0, Scalar(0,0,255), 1, 1, false);
	rectangle(g, Rect(x, y+pixeldimension-5, 20, 5),Scalar(200,200,200), 2, 1, 0);
}
int* Reticle::localDoubleIntArrayConversion(double *d, int length){
	if ((d == NULL) || (sizeof(d) == 0)) return NULL;
	int *i = new int[10];
	for (int incr = 0; incr < length; incr++){
		i[incr] = -1*(int)floor(d[incr] + 0.5);
	}  // for
	return i;
}
void Reticle::setDrawColor(ColorSelect c){
	switch (c){ // OpenCV is BGR
	    case(BLACK) :{color = Scalar(0,0,0); return;}  // These Mouse actions are not used
	    case(RED)   :{color = Scalar(0,0,255); return;}
	    case(ORANGE):{color = Scalar(0,128,255); return;}
	    case(YELLOW):{color = Scalar(0,255,255); return;}
	    case(GREEN) :{color = Scalar(0,255,0); return;}
	    case(BLUE)  :{color = Scalar(255,0,0); return;}
	    case(INDIGO):{color = Scalar(130,0,75); return;}
	    case(VIOLET):{color = Scalar(238,130,238); return;}
	    case(WHITE) :{color = Scalar(255,255,255); return;}
	} // switch
}
void Reticle::drawMainReticle(Mat& g){
	if(reticleElements == NULL){
		drawDefaultReticle(g);
		return;
	} // if
	int xmod = (int)windage();
	int ymod = (int)elevation();
	RETElement *h = reticleElements;
	while(h){			
		if(h->points.size() == 1) { // This is a "data point" or label.
			if(h->FnPtr != NULL){  // Data point function pointer is live, call the data in
				stringstream oss;
				oss << h->FnPtr();
				putText(g, oss.str(),Point(h->points[0].x + xmod, h->points[0].y + ymod), 1, h->fontscale, h->drawcolor, 1, 1, false);
			}  else { // The function pointer being null means this is a label node.
				putText(g, h->s,Point( h->points[0].x + xmod, h->points[0].y + ymod), 1,  h->fontscale, h->drawcolor, 1, 1, false);
			}// if
		} else if (h->points.size() == 2){ // This is a line		
			line(g, Point(h->points[0].x + xmod, h->points[0].y + ymod), Point(h->points[1].x + xmod, h->points[1].y + ymod), h->drawcolor, 1,1,0);
		} else { // Here the vector is beyond 2, meaning it's a polygon
			vector<vector<Point> > polygon;
			if(h->fill) {
				polygon.push_back(h->points);
				fillPoly(g, polygon, h->drawcolor, 8,0, Point(0,0));
			} else {
				// May need to check this one
				polylines(g, polygon, true, h->drawcolor, 1);
			} // if
		} // if
		h = h->p;  // move to next pointer in the linked list
	} 	// while
}
// If no main reticle is defined, or it failed perhaps, then use this default "red x" reticle.
void Reticle::drawDefaultReticle(Mat& g){
	int x = (int)windage();
	int y = (int)elevation();
	setDrawColor(RED);
	line(g, Point(x-20,  y-20), Point(x-2, y-2), color, 1,1,0);
	line(g, Point(x+20,  y-20), Point(x+2, y-2), color, 1,1,0);
	line(g, Point(x-20,  y+20), Point(x-2, y+2), color, 1,1,0);
	line(g, Point(x+20,  y+20), Point(x+2, y+2), color, 1,1,0);
}
bool Reticle::useDefault(){
	return (reticleElements == NULL) ? true : false;
}
Reticle::~Reticle() {}
