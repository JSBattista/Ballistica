/*
Ballistica 2.1
 *<b>Ballistica Version 2 "Foe-hammer". </b><br>
 *<b>Copyright 2014 Ballistica Software Defined Scope System (SDSS)</b><br>
 *<pre>
 *   This program is free software: you can redistribute it and/or modify<br>
 *   it under the terms of the GNU General Public License as published by<br>
 *   the Free Software Foundation, either version 3 of the License, or<br>
 *   (at your option) any later version.<br>
 *   <br>
 *   This program is distributed in the hope that it will be useful,<br>
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of<br>
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the<br>
 *   GNU General Public License for more details.<br>
 *   <br>
 *   You should have received a copy of the GNU General Public License<br>
 *   along with this program.  If not, see &lt;http://www.gnu.org/licenses/&gt;.<br>
 * </pre>
 * <pre>
 *   This file is part of Ballistica.<br>
 *   <br>
 *   Ballistica is free software: you can redistribute it and/or modify<br>
 *   it under the terms of the GNU General Public License as published by<br>
 *   the Free Software Foundation, either version 3 of the License, or<br>
 *   (at your option) any later version.<br>
 *   <br>
 *   Ballistica is distributed in the hope that it will be useful,<br>
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of<br>
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the<br>
 *   GNU General Public License for more details.<br>
 *   <br>
 *   You should have received a copy of the GNU General Public License<br>
 *     along with Ballistica.  If not, see &lt;http://www.gnu.org/licenses/&gt;.<br>
*/
#ifndef TARGETBOX_H_
#define TARGETBOX_H_
#include <opencv2\highgui\highgui.hpp>
#include <opencv2\imgproc\imgproc.hpp>
#include <opencv2\core\core.hpp>
#include <iostream>
#include <stdio.h>
#include <cmath>
using namespace cv;
class Targetbox {
public:
	cv::Point screenReferenceCOG;  // This maintains the actual detected on "main screen" Center of gravity.
	cv::Point subboxReferenceCOG;  // This is the detected movement COG inside of the rectangle for narrowed movement detection
	cv::Rect sbrect;    // Rectangle construct for the Sub-Box. X and Y are modified per detections in box.
    int decay;  // this would better be set by some variation of the number of initial pixels.
    // These Mats are particular to subbox usage so are kept in here.
    Mat subbox;
    Mat sbgray;
    Mat sbprev;
    Mat	sbdiff;
    Mat sbDstImage;
    Scalar color;
	Targetbox();
	Targetbox(int,int);
	Targetbox(int, int, int, int);	
	void setTargeBox(int, int, int, int);
	cv::Point getTargetBoxCenter();
	void drawTargetBox(Mat&);
	void applyCOGDisplacement(cv::Point);
	cv::Rect getTargetBox();
	bool checkROIBoundaries(int, int);
	virtual ~Targetbox();
private:
	int defaultL;      // Default Length of box
	int defaultH;      // Default Height of box
};
#endif /* TARGETBOX_H_ */
