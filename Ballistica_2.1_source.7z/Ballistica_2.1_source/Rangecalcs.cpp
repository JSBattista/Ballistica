/*
 *<b>Ballistica Version 2.1 "Foe-hammer". </b><br>
 *<b>Copyright 2014 Ballistica Software Defined Scope System (SDSS)</b><br>
 *<pre>
 *   This program is free software: you can redistribute it and/or modify<br>
 *   it under the terms of the GNU General Public License as published by<br>
 *   the Free Software Foundation, either version 3 of the License, or<br>
 *   (at your option) any later version.<br>
 *   <br>
 *   This program is distributed in the hope that it will be useful,<br>
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of<br>
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the<br>
 *   GNU General Public License for more details.<br>
 *   <br>
 *   You should have received a copy of the GNU General Public License<br>
 *   along with this program.  If not, see &lt;http://www.gnu.org/licenses/&gt;.<br>
 * </pre>
 * <pre>
 *   This file is part of Ballistica.<br>
 *   <br>
 *   Ballistica is free software: you can redistribute it and/or modify<br>
 *   it under the terms of the GNU General Public License as published by<br>
 *   the Free Software Foundation, either version 3 of the License, or<br>
 *   (at your option) any later version.<br>
 *   <br>
 *   Ballistica is distributed in the hope that it will be useful,<br>
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of<br>
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the<br>
 *   GNU General Public License for more details.<br>
 *   <br>
 *   You should have received a copy of the GNU General Public License<br>
 *     along with Ballistica.  If not, see &lt;http://www.gnu.org/licenses/&gt;.<br>
*/
#include "Rangecalcs.h"
Rangecalcs::Rangecalcs() {
	calcs = vector<RangePATHReticleDISP>();
	rangeElementsCount = calcs.size();
	rangeMAXGranularity = 10;
}
Rangecalcs::Rangecalcs(int i, int j, int k){
        range = i;
        zoom = j;
        zero = k;
        needNewSolution = true;
        calcs = vector<RangePATHReticleDISP>();
        rangeMAXGranularity = 10;
        rangeElementsCount = calcs.size();
}
void Rangecalcs::pushNewStats(int range, double path, double retBDC, double time, double velocity, double windage, double reticleDispWND){
        RangePATHReticleDISP *rpd = new RangePATHReticleDISP();
        rpd->path    = path;
        rpd->range   = range;
        rpd->reticleDispBDC = retBDC;
        rpd->time    = time;
        rpd->velocity    = velocity;
        rpd->windage     = windage;
        rpd->reticleDispWND = reticleDispWND;
        calcs.push_back(*rpd);
        rangeElementsCount = calcs.size();
}
Rangecalcs::~Rangecalcs() {
	calcs.clear();
}
int Rangecalcs::getCurrentRange(){
	return range;
}
int Rangecalcs::getCurrentZoom(){
	return zoom;
}
int Rangecalcs::getCurrentZero(){
	return zero;
}
int* Rangecalcs::getRanges(){
	int count = calcs.size();
	int* ranges = new int[count];
	for (int incr = 0; incr < count; incr++){
		ranges[incr] = ((RangePATHReticleDISP)calcs[incr]).range;
	} // for
	return ranges;
}
int Rangecalcs::getCalcsCount(){
	return calcs.size();
}
int Rangecalcs::getRangeAtElement(int i){
	if ((i < 0) || (i >  rangeMAXGranularity-1 )) return 0;
	return ((RangePATHReticleDISP)calcs[i]).range;
}
double* Rangecalcs::getBDCPaths(){
	int count = calcs.size();
	double* paths = new double[count];
	for (int incr = 0; incr < count; incr++){
		paths[incr] = ((RangePATHReticleDISP)calcs[incr]).path;
	} // for
	return paths;
}
double* Rangecalcs::getReticleDisplacementsBDCs(){
	int count = calcs.size();
	double* retdisps = new double[count];
	for (int incr = 0; incr < count; incr++){
		retdisps[incr] = ((RangePATHReticleDISP)calcs[incr]).reticleDispBDC;
	} // for
	return retdisps;
}
double* Rangecalcs::getTimes(){
	int count = calcs.size();
	double* times = new double[count];
	for (int incr = 0; incr < count; incr++){
		times[incr] = ((RangePATHReticleDISP)calcs[incr]).time;
	} // for
	return times;
}
double* Rangecalcs::getVelocities(){
	int count = calcs.size();
	double* velocities = new double[count];
	for (int incr = 0; incr < count; incr++){
		velocities[incr] = ((RangePATHReticleDISP)calcs[incr]).velocity;
	} // for
	return velocities;
}
double* Rangecalcs::getWindages(){
	int count = calcs.size();
	double* windages = new double[count];
	for (int incr = 0; incr < count; incr++){
		windages[incr] = ((RangePATHReticleDISP)calcs[incr]).windage;
	} // for
	return windages;
}
double* Rangecalcs::getReticleDisplacementsWNDs(){
	int count = calcs.size();
	double* reticleDispWNDs = new double[count];
	for (int incr = 0; incr < count; incr++){
		reticleDispWNDs[incr] = ((RangePATHReticleDISP)calcs[incr]).reticleDispWND;
	} // for
	return reticleDispWNDs;
}
double Rangecalcs::getRangeAtRange(int range){   // This merely checks if the new range is out of existing calculated ranges
	range = roundRange(range);
	int count = calcs.size();
	for (int incr = 0; incr < count; incr++){
		if(((RangePATHReticleDISP)calcs[incr]).range == range){
			return ((RangePATHReticleDISP)calcs[incr]).range;
		} // if
	} // for
	return 0;
}
double Rangecalcs::getBDCPathAtRange(){ // This will use the internally set range
	return getBDCPathAtRange(range);
}
double Rangecalcs::getBDCPathAtRange(int range){
	range = roundRange(range);
	int count = calcs.size();
	for (int incr = 0; incr < count; incr++){
		if(((RangePATHReticleDISP)calcs[incr]).range == range){
			return ((RangePATHReticleDISP)calcs[incr]).path;
		} // if
	} // for
	return 0;
}
double Rangecalcs::getReticleDisplacementsBDCAtRange(){ // This will use the internally set range
	return getReticleDisplacementsBDCAtRange(range);
}
double Rangecalcs::getReticleDisplacementsBDCAtRange(int range){
	range = roundRange(range);
	int count = calcs.size();
	for (int incr = 0; incr < count; incr++){
		if(((RangePATHReticleDISP)calcs[incr]).range == range){
			return ((RangePATHReticleDISP)calcs[incr]).reticleDispBDC;
		} // if
	} // for
	return 0;
}
double Rangecalcs::getTimeAtRange(){ // This will use the internally set range
	return getTimeAtRange(range);
}
double Rangecalcs::getTimeAtRange(int range){
	range = roundRange(range);
	int count = calcs.size();
	for (int incr = 0; incr < count; incr++){
		if(((RangePATHReticleDISP)calcs[incr]).range == range){
			return ((RangePATHReticleDISP)calcs[incr]).time;
		} // if
	} // for
	return 0;
}
double Rangecalcs::getVelocityAtRange(){ // This will use the internally set range
	return getVelocityAtRange(range);
}
double Rangecalcs::getVelocityAtRange(int range){
	range = roundRange(range);
	int count = calcs.size();
	for (int incr = 0; incr < count; incr++){
		if(((RangePATHReticleDISP)calcs[incr]).range == range){
			return ((RangePATHReticleDISP)calcs[incr]).velocity;
		} // if
	} // for
	return 0;
}
double Rangecalcs::getWindageAtRange(){ // This will use the internally set range
	return getWindageAtRange(range);
}
double Rangecalcs::getWindageAtRange(int range){
	range = roundRange(range);
	int count = calcs.size();
	for (int incr = 0; incr < count; incr++){
		if(((RangePATHReticleDISP)calcs[incr]).range == range){
			return ((RangePATHReticleDISP)calcs[incr]).windage;
		} // if
	} // for
	return 0;
}
double Rangecalcs::getReticleDisplacementWNDAtRange(){ // This will use the internally set range
	return getReticleDisplacementWNDAtRange(range);
}
double Rangecalcs::getReticleDisplacementWNDAtRange(int range){
	range = roundRange(range);
	int count = calcs.size();
	for (int incr = 0; incr < count; incr++){
		if(((RangePATHReticleDISP)calcs[incr]).range == range){
			return ((RangePATHReticleDISP)calcs[incr]).reticleDispWND;
		} // if
	} // for
	return 0;
}
int Rangecalcs::roundRange(int i){
	if((i % 100) == 0)
		return i;
	else if((i%100) < 50)
		return  (i - (i % 100));
	else if((i%100) >= 50)
		return  (i - (i % 100)) + 100;
	return 0;   // This should never be reached
}
void Rangecalcs::updateTargetRange(int newRange){
	range = newRange;
	if(getRangeAtRange(newRange) == 0){
		needNewSolution = true;
	} // if
}
void Rangecalcs::updateZoom(int newZoom){
	zoom = newZoom;
	needNewSolution = true;
}
void Rangecalcs::updateZero(int newZero){
	zero = newZero;
	needNewSolution = true;
}
int* Rangecalcs::generateRanges(){
	return generateRanges(range);
}
int* Rangecalcs::generateRanges(int newRange){
	clear();
	range = newRange;
	int spread = (int)range/5;
	if (spread < 100)spread = 100;
	std::vector<int> alr(0);
	for (int incr = 0; incr < rangeMAXGranularity; incr++) {
		int t = 0;
		if (incr == 0)t = spread;
		else t = incr*spread;
		alr.push_back(t);
	}  //for
	if(alr.empty()) return NULL;
	int* arr = new int[alr.size()];
	for (unsigned int incr = 0; incr < alr.size(); incr++){
		arr[incr] = alr[incr];
	}  // for
	rangeElementsCount = alr.size();
	return arr;
}
int Rangecalcs::getRangeElementsCount(){
	return rangeElementsCount;
}
bool Rangecalcs::isNeedingNewSolution(){
	return needNewSolution;
}
void Rangecalcs::notifySetUpdate() {
	needNewSolution = false;
}
void Rangecalcs::clear(){
	range = 0;
	calcs.clear();
	rangeElementsCount = calcs.size();
}

void Rangecalcs::drawPlatformOverview(Mat& g, int x, int y){	
	ostringstream oss;
	oss << "RNG:  " << range << "  | ZERO:"<< zero <<"   | MAG:" << zoom;	
	putText(g, oss.str(),Point(((int)x/2), 20), 2, 0.5, Scalar(0,255,0), 1, 1, false);
}