/*
Ballistica 2.1
 *<b>Ballistica Version 2 "Foe-hammer". </b><br>
 *<b>Copyright 2014 Ballistica Software Defined Scope System (SDSS)</b><br>
 *<pre>
 *   This program is free software: you can redistribute it and/or modify<br>
 *   it under the terms of the GNU General Public License as published by<br>
 *   the Free Software Foundation, either version 3 of the License, or<br>
 *   (at your option) any later version.<br>
 *   <br>
 *   This program is distributed in the hope that it will be useful,<br>
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of<br>
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the<br>
 *   GNU General Public License for more details.<br>
 *   <br>
 *   You should have received a copy of the GNU General Public License<br>
 *   along with this program.  If not, see &lt;http://www.gnu.org/licenses/&gt;.<br>
 * </pre>
 * <pre>
 *   This file is part of Ballistica.<br>
 *   <br>
 *   Ballistica is free software: you can redistribute it and/or modify<br>
 *   it under the terms of the GNU General Public License as published by<br>
 *   the Free Software Foundation, either version 3 of the License, or<br>
 *   (at your option) any later version.<br>
 *   <br>
 *   Ballistica is distributed in the hope that it will be useful,<br>
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of<br>
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the<br>
 *   GNU General Public License for more details.<br>
 *   <br>
 *   You should have received a copy of the GNU General Public License<br>
 *     along with Ballistica.  If not, see &lt;http://www.gnu.org/licenses/&gt;.<br>
*/
#ifndef RETICLE_H_
#define RETICLE_H_
#include <string.h>
#include <stdlib.h>
#include <opencv2\highgui\highgui.hpp>
#include <opencv2\imgproc\imgproc.hpp>
#include <opencv2\core\core.hpp>
using namespace std;
using namespace cv;
typedef double (*FPtr)();
class Reticle {
public:
   	int hpx;
   	int hpy;
	Reticle(std::map<std::string, FPtr>);
	Reticle(int, int, std::map<std::string, FPtr>);
	Reticle(int, int, std::map<std::string, FPtr>, string);
	Reticle(Rect d,std::map<std::string, FPtr>);
	void resetReticleFrameDIM(int, int);
	void drawReticleTrackingRect(Mat&, int, int, string, int);
	void drawTraversalReticle(Mat&, int, int, double);
	void drawReticle_text(Mat&, int, int, string);
	void drawReticleCenterReference(Mat&);
	void drawCalibrationSquare(Mat&, int, int, int);
	void drawRangingCarrette(Mat&, int, int, int, int);	
	void drawMainReticle(Mat&);
	bool useDefault();	
	virtual ~Reticle();
private:
	int xmax, ymax;	
	Scalar color;
	enum ColorSelect {BLACK, RED, ORANGE, YELLOW, GREEN, BLUE, INDIGO, VIOLET, WHITE};
	Rect trackingRect;
	Rect traversalRect;
	Scalar trackingColor;
	Scalar traversalColor;
	vector<Point> p3Triangle;
	int statlinecount;
	int* localDoubleIntArrayConversion(double[], int);
	void setDrawColor(ColorSelect);	
	// Nested class
	class RETElement {
	public:
		RETElement *p;	// Pointer to the next class - this is intended for linked list usage.
		double (*FnPtr)();	// This is a pointer to one of the functions in main class that gets data from other member functions.
		vector<Point> points;	// One it's a data point, 2 a line, more than 2, a polygon
		string s;		// Label?
		double fontscale;
		unsigned int fill;		// for polygons
		Scalar drawcolor;
	};
	RETElement *reticleElements;		// Main pointer.
	double (*windage)();
	double (*elevation)();
	void drawDefaultReticle(Mat&);
};
#endif /* RETICLE_H_ */
