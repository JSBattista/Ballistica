/*
Ballistica 2.1
 *<b>Ballistica Version 2 "Foe-hammer". </b><br>
 *<b>Copyright 2014 Ballistica Software Defined Scope System (SDSS)</b><br>
 *<pre>
 *   This program is free software: you can redistribute it and/or modify<br>
 *   it under the terms of the GNU General Public License as published by<br>
 *   the Free Software Foundation, either version 3 of the License, or<br>
 *   (at your option) any later version.<br>
 *   <br>
 *   This program is distributed in the hope that it will be useful,<br>
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of<br>
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the<br>
 *   GNU General Public License for more details.<br>
 *   <br>
 *   You should have received a copy of the GNU General Public License<br>
 *   along with this program.  If not, see &lt;http://www.gnu.org/licenses/&gt;.<br>
 * </pre>
 * <pre>
 *   This file is part of Ballistica.<br>
 *   <br>
 *   Ballistica is free software: you can redistribute it and/or modify<br>
 *   it under the terms of the GNU General Public License as published by<br>
 *   the Free Software Foundation, either version 3 of the License, or<br>
 *   (at your option) any later version.<br>
 *   <br>
 *   Ballistica is distributed in the hope that it will be useful,<br>
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of<br>
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the<br>
 *   GNU General Public License for more details.<br>
 *   <br>
 *   You should have received a copy of the GNU General Public License<br>
 *     along with Ballistica.  If not, see &lt;http://www.gnu.org/licenses/&gt;.<br>
*/
#ifndef RANGETRACK_H_
#define RANGETRACK_H_
#include <opencv2\highgui\highgui.hpp>
#include <opencv2\imgproc\imgproc.hpp>
#include <opencv2\core\core.hpp>
class RangeTrack{
public:
	RangeTrack();
	virtual ~RangeTrack();		
	int getArea();
	int getPixelCount();
	void setToleranceDefault();
	void setToleranceLow();
	void setToleranceHigh();
	void setToleranceSpecified(float, float);		
	void incrementLightLevel();
	void decrementLightLevel();
	void setLightLevel(int);
	void setDefaultLighting();
	void setZeroLightingParameters();
	void setDirectLighting(int, int, int, int);
	void setDirectType(int);
	void drawLightSettingSymbol(cv::Mat, int, int);
	cv::Mat subbox;
	cv::Rect resRect;
	cv::Rect getCurrentRectangle(void);
	cv::Point processRangeTracking(cv::Mat &, int);		// Works with raw image and process all of it	
	cv::Point processRangeTracking(int);	// Sub-boxing version	
	void setTargetBox(int, int);
	void setTargetBox(int, int, int, int);
	void setTargetBox(cv::Rect);
	cv::Point screenReferenceCOG;  // This maintains the actual detected on "main screen" Center of gravity.
	cv::Point subboxReferenceCOG;  // This is the detected movement COG inside of the rectangle for narrowed movement detection
	cv::Rect subboxbrect;    
	bool checkROIBoundaries(int, int);
	cv::Point getTargetBoxCenter();
	void drawTargetBox(cv::Mat&);
	void applyCOGDisplacement(cv::Point);
	void getCOG(void);
	bool checkSensitivityThreshold(void);
	bool locked(void);
private:
	double area;	// Area of rectangle encompassing the contours
	int decay;  
	int pixelcount;	// Same as area
	float lowertolMOD;	// Routine will bracket the results around the size
	float uppertolMOD;  // so these are "tolerance modifiers"
	int sensitivity;	// Used as a kind of results threshold
	bool activeLocked;
	int  lighting_low ;        // default values
	int  lighting_high;
	int  lighting_smooth;
	int  lighting_type;
	int  lighting_setRangeMIN;
	int  lighting_setRangeMAX;
	int levelIndex;
	cv::Scalar drawColor;
	cv::Scalar highcolor;
	cv::Scalar lowcolor;	
	void setLightOnDark(int);
	void setLightOnLight(int);
	void setDarkOnLight(int);
	void setDarkOnDark(int);
	int defaultL;      // Default Length of box
	int defaultH;      // Default Height of box
};
#endif /* RANGETRACK_H_ */


