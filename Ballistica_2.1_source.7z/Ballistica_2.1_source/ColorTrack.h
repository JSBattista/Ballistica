/*
Ballistica 2.1
 *<b>Ballistica Version 2 "Foe-hammer". </b><br>
 *<b>Copyright 2014 Ballistica Software Defined Scope System (SDSS)</b><br>
 *<pre>
 *   This program is free software: you can redistribute it and/or modify<br>
 *   it under the terms of the GNU General Public License as published by<br>
 *   the Free Software Foundation, either version 3 of the License, or<br>
 *   (at your option) any later version.<br>
 *   <br>
 *   This program is distributed in the hope that it will be useful,<br>
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of<br>
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the<br>
 *   GNU General Public License for more details.<br>
 *   <br>
 *   You should have received a copy of the GNU General Public License<br>
 *   along with this program.  If not, see &lt;http://www.gnu.org/licenses/&gt;.<br>
 * </pre>
 * <pre>
 *   This file is part of Ballistica.<br>
 *   <br>
 *   Ballistica is free software: you can redistribute it and/or modify<br>
 *   it under the terms of the GNU General Public License as published by<br>
 *   the Free Software Foundation, either version 3 of the License, or<br>
 *   (at your option) any later version.<br>
 *   <br>
 *   Ballistica is distributed in the hope that it will be useful,<br>
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of<br>
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the<br>
 *   GNU General Public License for more details.<br>
 *   <br>
 *   You should have received a copy of the GNU General Public License<br>
 *     along with Ballistica.  If not, see &lt;http://www.gnu.org/licenses/&gt;.<br>
*/
#ifndef COLORTRACK_H_
#define COLORTRACK_H_
#include <opencv2\highgui\highgui.hpp>
#include <opencv2\imgproc\imgproc.hpp>
#include <opencv2\core\core.hpp>
#include <stdint.h>
using namespace std;
using namespace cv;
class ColorTrack{
public:
	ColorTrack();
	ColorTrack(cv::Mat&);
	virtual ~ColorTrack();
	cv::Scalar getTrackingColor();
	cv::Point processColorTracking(cv::Mat &);
	cv::Point processColorTracking();
	cv::Rect aperture;
	int getArea();
	int getPixelCount();
	void modColorTrack(int, int);
	int getColorTrackModLow();
	int getColorTrackModHigh();
	void drawColorCapture(Mat&, int, int, string);
	void drawColorTolerance(Mat&, int, int);
	bool locked(void);


	
	Mat subbox;
	void setTargetBox(int, int);
	void setTargetBox(int, int, int, int);
	void setTargetBox(Rect);
	cv::Rect getCurrentRectangle(void);
	cv::Point screenReferenceCOG;  // This maintains the actual detected on "main screen" Center of gravity.
	cv::Point subboxReferenceCOG;  // This is the detected movement COG inside of the rectangle for narrowed movement detection
	cv::Rect subboxbrect;    
	bool checkROIBoundaries(int, int);
	cv::Point getTargetBoxCenter();
	void drawTargetBox(cv::Mat&);
	void applyCOGDisplacement(cv::Point);
	void getCOG(void);
	bool checkSensitivityThreshold(void);
	
	




private:
	int decay;  
	cv::Scalar lowbgr;
	cv::Scalar highbgr;
	cv::Scalar drawColor;
	double area;
	int sensitivity;	// Used as a kind of results threshold
	int pixelcount;
	int colorToleranceLow;
	int colorToleranceHigh;
	int defaultL;      // Default Length of box
	int defaultH;      // Default Height of box
	bool activeLocked;
};
#endif /* COLORTRACK_H_ */


