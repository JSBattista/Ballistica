/*
 *<b>Ballistica Version 2.1 "Foe-hammer". </b><br>
 *<b>Copyright 2014 Ballistica Software Defined Scope System (SDSS)</b><br>
 *<pre>
 *   This program is free software: you can redistribute it and/or modify<br>
 *   it under the terms of the GNU General Public License as published by<br>
 *   the Free Software Foundation, either version 3 of the License, or<br>
 *   (at your option) any later version.<br>
 *   <br>
 *   This program is distributed in the hope that it will be useful,<br>
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of<br>
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the<br>
 *   GNU General Public License for more details.<br>
 *   <br>
 *   You should have received a copy of the GNU General Public License<br>
 *   along with this program.  If not, see &lt;http://www.gnu.org/licenses/&gt;.<br>
 * </pre>
 * <pre>
 *   This file is part of Ballistica.<br>
 *   <br>
 *   Ballistica is free software: you can redistribute it and/or modify<br>
 *   it under the terms of the GNU General Public License as published by<br>
 *   the Free Software Foundation, either version 3 of the License, or<br>
 *   (at your option) any later version.<br>
 *   <br>
 *   Ballistica is distributed in the hope that it will be useful,<br>
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of<br>
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the<br>
 *   GNU General Public License for more details.<br>
 *   <br>
 *   You should have received a copy of the GNU General Public License<br>
 *     along with Ballistica.  If not, see &lt;http://www.gnu.org/licenses/&gt;.<br>
*/
#include "Camera.h"
#include <stdio.h>
Camera::Camera(){}
/*
 * This constructor takes the number of pixels per inch at no magnification ("Naked Camera")
 * and the number of pixels per inch at maximum magnfication per the calibration
 * procedures along with the present magfication number and total magnification levels.
 * This process is known as "through calibration".
 */
Camera::Camera(double pixelsINCHNoMAG, double pixelsINCHMAXMAG, int totalMAG, int presentMAG) {
	//  Here the pixels that occupy 1" square at 1 yard are entered
	// Note that a 1" "calibration square" is assumed.
	// This will be used to help determine reticle displacement per the range of the target.
	//  Some systems can get very "farsighted" though, so use the second version of this function
	//  that takes in a yardage value.
	pINCH = 1 / pixelsINCHNoMAG;
	double pMAXMAG = 1 / pixelsINCHMAXMAG;
	magMultiplier = pINCH / pMAXMAG;
	pmag = presentMAG;
	tmag = totalMAG;
}
/*
 *  This versions takes in a yardage amount.
 */
Camera::Camera(double pixelsINCHNoMAG, double pixelsINCHMAXMAG, int totalMAG, int presentMAG, int yards) {
	//  Here the pixels that occupy 1" square at a given number of yards are entered. Some systems
	//  might be too "farsighted" for the original 1" at 1 yard through-calibration.
	// Note that a 1" "calibration square" is assumed.
	// This will be used to help determine reticle displacement per the range of the target.
	pINCH = (1 / pixelsINCHNoMAG) / yards;
	double pMAXMAG = (1 / pixelsINCHMAXMAG) / yards;
	magMultiplier = pINCH / pMAXMAG;
	pmag = presentMAG;
	tmag = totalMAG;
}
/*
 *  This version takes in two yardages, a low yards and a high yards, for "nearsighted" systems. (untested)
 */
Camera::Camera(double pixelsINCHNoMAG, double pixelsINCHMAXMAG, int totalMAG, int presentMAG, int lowyards, int highyards) {
	//  Here the pixels that occupy 1" square at a given number of yards are entered. Some systems
	//  might be too "farsighted" for the original 1" at 1 yard through-calibration.
	// Note that a 1" "calibration square" is assumed.
	// This will be used to help determine reticle displacement per the range of the target.
	pINCH = (int)((1 / pixelsINCHNoMAG) / lowyards);
	double pMAXMAG = (int)((1 / pixelsINCHMAXMAG) / highyards);
	magMultiplier = pINCH / pMAXMAG;
	pmag = presentMAG;
	tmag = totalMAG;
}
Camera::~Camera() {}
void Camera::setMAG(int m){        // This is not to be confused with the magnification constant
	pmag = m;
}
int Camera::getMAG(){        // This is not to be confused with the magnification constant
	return pmag;
}
//   This function is used to convert the number of inches of translation
//   per any drop or windage translation into pixels, and primarily to
//   to be used in cases where a displacement of the reticle is needed,
//   or any translation of where something depending on range needs a certain
//   place on the viewer.
double Camera::getReticleDisplacement(double range, double inchesBDCorWND){
	int m = (pmag > 0) ? pmag : 1;  // "naked Camera" lacking magnification could cause a divide by zero.
	double mm = (magMultiplier > 0) ? magMultiplier : 1;
	return (inchesBDCorWND / ((pINCH / (m * mm)) * range) / magMultiplier);
}
// This is the same as getReticleDisplacement
float Camera::getPixelsFromInchSpan(double range, double inches){
	int m = (pmag > 0) ? pmag : 1;  // "naked Camera" lacking magnification could cause a divide by zero.
	double mm = (magMultiplier > 0) ? magMultiplier : 1;
	return (float)(inches / ((pINCH / (m * mm)) * range) / magMultiplier);
}
// This function is the reverse of getReticleDisplacement whereby we would
// know the pixel to pixel "distance" of some activity in the viewer,
// but need to translate that to inches.
double Camera::getInchesFromPixelSpan(double range, int pixelSpan){
	int m = (pmag > 0) ? pmag : 1;  // "naked Camera" lacking magnification could cause a divide by zero.
	double mm = (magMultiplier > 0) ? magMultiplier : 1;
	return (pixelSpan * ((pINCH / (m * mm)) * range));
}
// In this case the inches of the object is known,
// and the span of pixels in the viewer is known, this can be used
// to determine the range
double Camera::getRangeFromPixelSpan(double inches, double pixelSpan){
	int m = (pmag > 0) ? pmag : 1;  // "naked Camera" lacking magnification could cause a divide by zero.
	double mm = (magMultiplier > 0) ? magMultiplier : 1;
	return inches / (pixelSpan * (pINCH/(m * mm)));
}
/* additional notes:
      The resolution of each Camera will make this different, so
     this class stores the dialed in statistics .

      Because the Camera is the "bridge" between the mathematical representation
      of ballistical data and the real world this class is to operate in two ways:

      1. Determination of range based on the known size of the object. Thus, a 3.6 inch/1 MOA target at 100 yards
         will occupy so many known pixels at a given magnification. The higher the magnification, the more pixels the
         object of known size will take up. Chances are a 'double zoom' method of range determination might be in use here.
         In all tests, the range and magnification are known, but the pixels may be unique for each Camera.
         Magnification and known size come in, and Range comes out.
      2. Determination of how many pixels the reticle will move given the known range of the target, and the elevation and
         windage adjusted from that data. So MOA values should come in, and pixel values go out.

      4. The display screen size may also have something to "say" about this.

      A challenge here is that some interpolation/extrapolation may be needed
      to come down to atomic level solution. Such a case might be construed to mean that
      on construction of this class, only two figures might be needed. That would be
      the Pixels per MOA, the range in yards, and the magnification of the scope or Camera.
      Pixels per MOA would have to be discovered during range calibration efforts.
      It might be best to go with these sets of data for interpolation/extrapolation routines on construction of this class:

      1.  The calibration object of 3.6"/1 MOA is viewed at close range at low range and high magnification.
      1a. The calibration object is viewed at 100 yards with high magnification.
      2.  The calibration object is viewed at close range with low magnification.
      2a. The object is viewed at 100 yards with low magnification.

      Somewhere in there is an equation where the known size, and magnification and range comprise
      a algebraic situation, a "solve for n" case where:
      Be advised that when checking with a dot reticle scope, the dot is the same size, but gets recorded
      as smaller and overlaying a ruler, because the image actually got bigger with higher magnification.
*
*   "scope clarity" is how sharp the edges still are at range, and this could
*   have an effect on the total pixel measurement.
*
*   Observations from the field indicate that using a dot reticle scope, and
*   putting the dot on a ruler, showed that the ruler is bigger at greater
*   magnifications as indicated by the dot being smaller against the ruler.
*
*
* Reticle against a ruler measurements, measurements are of a reticle dot.
*      yds         5X          16x         25x
*      ---         --          ---         ---
*      12.5        1/8"        1/16"       1/32"
*      25          1/4"        1/8"        1/16"
*      50          1/2"        1/4"        1/8"
*      100         1"          1/2"        1/4"
*
* So at 25X an object is 4X larger than at 5X. This shows the relationship
* of object size, distance, and magnification.
*
* The next test would be to use a Camera whereby instead of a dot
* of a mildot reticle, an object of fixed known size is used, and the number of
* pixels that the object takes up is determinant of unkown values.
*
*/
