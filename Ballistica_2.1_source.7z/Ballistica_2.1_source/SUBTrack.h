/*
Ballistica 2.1
 *<b>Ballistica Version 2 "Foe-hammer". </b><br>
 *<b>Copyright 2014 Ballistica Software Defined Scope System (SDSS)</b><br>
 *<pre>
 *   This program is free software: you can redistribute it and/or modify<br>
 *   it under the terms of the GNU General Public License as published by<br>
 *   the Free Software Foundation, either version 3 of the License, or<br>
 *   (at your option) any later version.<br>
 *   <br>
 *   This program is distributed in the hope that it will be useful,<br>
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of<br>
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the<br>
 *   GNU General Public License for more details.<br>
 *   <br>
 *   You should have received a copy of the GNU General Public License<br>
 *   along with this program.  If not, see &lt;http://www.gnu.org/licenses/&gt;.<br>
 * </pre>
 * <pre>
 *   This file is part of Ballistica.<br>
 *   <br>
 *   Ballistica is free software: you can redistribute it and/or modify<br>
 *   it under the terms of the GNU General Public License as published by<br>
 *   the Free Software Foundation, either version 3 of the License, or<br>
 *   (at your option) any later version.<br>
 *   <br>
 *   Ballistica is distributed in the hope that it will be useful,<br>
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of<br>
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the<br>
 *   GNU General Public License for more details.<br>
 *   <br>
 *   You should have received a copy of the GNU General Public License<br>
 *     along with Ballistica.  If not, see &lt;http://www.gnu.org/licenses/&gt;.<br>
*/
#ifndef SUBTRACK_H_
#define SUBTRACK_H_
#include <opencv2\highgui\highgui.hpp>
#include <opencv2\imgproc\imgproc.hpp>
#include <opencv2\core\core.hpp>
#include <opencv2\video\background_segm.hpp>
#include <list>
using namespace std;
using namespace cv;
class SUBTrack
{
public:
	SUBTrack(double(*)(double,double), int);
	SUBTrack::SUBTrack(int,float,bool, int, double(*)(double,double), int);
	~SUBTrack(void);
	void processSUBTracking(cv::Mat &);
	cv::Point processSUBTracking(int);  // Sub-boxing version
	Rect resRect;
	Rect aperture;			
	void setHistory(int);
	void setThreshold(float);
	void toggleShadowDetect();
	bool shadowDetecting();
	void toggleUpdate();
	bool updating();
	//int getArea();
	//int getPixelCount();	
	Rect getCurrentRectangle(void);
	Rect getCurrentSUBBRect(void);
	double getCurrentRange(void);
	void setThreatHeightINCH(int);
	int getArea(void);
	int getPixelCount(void);
	void setTargetBox(int, int);
	void setTargetBox(int, int, int, int);
	void setTargetBox(Rect);
	


	Mat subbox;
	cv::Point screenReferenceCOG;  // This maintains the actual detected on "main screen" Center of gravity.
	cv::Point subboxReferenceCOG;  // This is the detected movement COG inside of the rectangle for narrowed movement detection
	cv::Rect subboxbrect;    
	bool checkROIBoundaries(int, int);
	cv::Point getTargetBoxCenter();
	void drawTargetBox(cv::Mat&);
	void applyCOGDisplacement(cv::Point);
	void getCOG(void);
	int sensitivity;	// Used as a kind of results threshold
	bool checkSensitivityThreshold(void);
	bool locked(void);

private:
	int decay;  
	BackgroundSubtractorMOG2 sub_model;
	Mat foreground;
	Mat foregroundmask;
	Scalar drawColor;
	//Mat	background;
	int subhistory;	// History that the model will "keep"
	float subthreshold; // Threshold value for the SUB model	
	int pixelcount;	// Same as area	
	int area;	
	float lowertolMOD;	// Routine will bracket the results around the size
	float uppertolMOD;  // so these are "tolerance modifiers"
	bool shadowdetect;
	bool update;	
	//int occurence;		// value to filter out very small boxes	
	int threatheightINCH;	// Known threat dimension
	double (*getCalculatedRange)(double, double);
	double range;
	int detectionThreshold;	// Set the threshold of detected counter-containing rectangle.
	int defaultL;      // Default Length of box
	int defaultH;      // Default Height of box
	bool activeLocked;
};

#endif