/*
 *<b>Ballistica Version 2.1 "Foe-hammer". </b><br>
 *<b>Copyright 2014 Ballistica Software Defined Scope System (SDSS)</b><br>
 *<pre>
 *   This program is free software: you can redistribute it and/or modify<br>
 *   it under the terms of the GNU General Public License as published by<br>
 *   the Free Software Foundation, either version 3 of the License, or<br>
 *   (at your option) any later version.<br>
 *   <br>
 *   This program is distributed in the hope that it will be useful,<br>
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of<br>
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the<br>
 *   GNU General Public License for more details.<br>
 *   <br>
 *   You should have received a copy of the GNU General Public License<br>
 *   along with this program.  If not, see &lt;http://www.gnu.org/licenses/&gt;.<br>
 * </pre>
 * <pre>
 *   This file is part of Ballistica.<br>
 *   <br>
 *   Ballistica is free software: you can redistribute it and/or modify<br>
 *   it under the terms of the GNU General Public License as published by<br>
 *   the Free Software Foundation, either version 3 of the License, or<br>
 *   (at your option) any later version.<br>
 *   <br>
 *   Ballistica is distributed in the hope that it will be useful,<br>
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of<br>
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the<br>
 *   GNU General Public License for more details.<br>
 *   <br>
 *   You should have received a copy of the GNU General Public License<br>
 *     along with Ballistica.  If not, see &lt;http://www.gnu.org/licenses/&gt;.<br>
*/
#include "Calibrator.h"
#include <stdio.h>
#include <cmath>
#include <vector>
#include <memory.h>
using namespace std;
Calibrator::Calibrator() {
	 minx = 32767;
	 miny = 32767;
	 maxx = 0;
	 maxy = 0;
	 caplow = false;
	 caphigh = false;
	 lowcapped = false;
	 highcapped = false;
	 lowmagpixelscap = 0;
	 maxmagpixelscap = 0;
	 caldistance = 1;
	 scanArea = 0;
}
Calibrator::~Calibrator() {}
void Calibrator::setLowPixCap(){
	if(!calRect) return;
	caplow = true;
}
void Calibrator::setHighPixCap(){
	if(!calRect) return;
	caphigh = true;
}
bool Calibrator::getCalCapStatus(){
        return lowcapped && highcapped;
}
bool Calibrator::lowCaptured(){
	return lowcapped;
}
bool Calibrator::highCaptured(){
	return highcapped;
}
double Calibrator::getLowPixelCal(){
        return (double)lowmagpixelscap;
}
double Calibrator::getHighPixelCal(){
        return (double)maxmagpixelscap;
}
void Calibrator::incrementCalibrationDistance(){
        caldistance++;
}
void Calibrator::decrementCalibrationDistance(){
        caldistance--;
        if (caldistance < 1) caldistance = 1;
}
int Calibrator::getCalibrationYardage(){
        return caldistance;
}
void Calibrator::displayThroughCalibrationCapture(cv::Mat &src) {
		ostringstream oss;
        int dimx = src.size().width;  // Unlikely that screen size changes, but it can.
        int dimy = src.size().height;
        cv::Mat dst;
        cv::Mat src_gray;
        cvtColor( src, src_gray, CV_RGB2GRAY );
        cv::threshold( src_gray, dst, 100, 255, cv::THRESH_BINARY_INV );
        vector<vector<cv::Point> > contours;
        vector<cv::Vec4i> hierarchy;
        calRect = NULL;		
        cv::Scalar color = cv::Scalar(255,255,255);
		oss << "CALIBRATION MODE - VIEW 1\" CALIBRATION SQUARE NOW AND STEADY PLATFORM\0";      
		cv::putText(src, oss.str(), cv::Point(20, dimy/4), 1, 0.6, color, 1, 1, false);
		oss.str("");
        if (!caplow){
			oss << "SET YARDS & LOWEST MAGNIFICATION THEN MIDDLE CLICK";
			cv::putText(src, oss.str(), cv::Point(20, dimy - 70), 1, 0.6, color, 1, 1, false);
        } else if (!caphigh){
			oss << "NOW SET LARGEST MAGNIFICATION THEN MIDDLE CLICK";
			cv::putText(src, oss.str(), cv::Point(20, dimy - 70), 1, 0.6, color, 1, 1, false);
        } // if
		oss.str("");
		oss << "CONTROL: CURRENT YDS=" << caldistance <<"  L CLICK -/+ R CLICK";
        cv::putText(src, oss.str(), cv::Point(10, dimy-40), 1, 0.6, color, 1, 1, false);
        cv::findContours( dst, contours, hierarchy, cv::RETR_EXTERNAL, cv::CHAIN_APPROX_SIMPLE, cv::Point(0, 0) );
        vector<vector<cv::Point> > contours_poly( contours.size() );
        for( size_t i = 0; i < contours.size(); i++ ) {
        	cv::approxPolyDP( cv::Mat(contours[i]), contours_poly[i], 3, true );
        	cv::Rect tRect =  cv::boundingRect(cv::Mat(contours_poly[i]));
        	if(tRect.area() >= (dimx*dimy*.70)) return; // filter out "major false rectangle captures" and the entire screen being "rected".
        	if (tRect.area() > (dimx*dimy*.20)){  // Assume here that some calibration square is in view taking up so much percentage of total area.
        		calRect = new cv::Rect(tRect);
        	} //if
        } // for
        // Here the capture of pixel span for known size has minimum magnification capture and maximum capture.
        if (!calRect)return; // No calibration Rectangle get out now.
        cv::rectangle( src, calRect->tl(), calRect->br(), color, 2, 8, 0 );
        if(caplow){
            lowmagpixelscap = (int)((calRect->br().x -calRect->tl().x) + (calRect->br().y - calRect->tl().y)) /2;
            if ((lowmagpixelscap != 0 ) && (abs(lowmagpixelscap) != 32767)) lowcapped = true;
        } // if
        if (caphigh){
            maxmagpixelscap = (int)((calRect->br().x -calRect->tl().x) + (calRect->br().y - calRect->tl().y)) /2;
            if ((maxmagpixelscap != 0 ) && (abs(maxmagpixelscap) != 32767))highcapped = true;
        } // if
}
/*
 *
 *
 *
 * notes: calibration class may have to take on a second role as setting up the Thresholds class.
 * If the rectangle detection is affected by image processing thresholds operations, such that these values
 * are altered until detection is met, it might be worthwhile to have several calibration squares, one for
 * "light on light" background, one for "dark on light", "dark on dark", etc. So using "threshold" before "findcontours"
 *  might be a working solution.
 *
 *
 */
