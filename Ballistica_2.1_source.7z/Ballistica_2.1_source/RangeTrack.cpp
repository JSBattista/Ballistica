/*
 *<b>Ballistica Version 2.1 "Foe-hammer". </b><br>
 *<b>Copyright 2014 Ballistica Software Defined Scope System (SDSS)</b><br>
 *<pre>
 *   This program is free software: you can redistribute it and/or modify<br>
 *   it under the terms of the GNU General Public License as published by<br>
 *   the Free Software Foundation, either version 3 of the License, or<br>
 *   (at your option) any later version.<br>
 *   <br>
 *   This program is distributed in the hope that it will be useful,<br>
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of<br>
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the<br>
 *   GNU General Public License for more details.<br>
 *   <br>
 *   You should have received a copy of the GNU General Public License<br>
 *   along with this program.  If not, see &lt;http://www.gnu.org/licenses/&gt;.<br>
 * </pre>
 * <pre>
 *   This file is part of Ballistica.<br>
 *   <br>
 *   Ballistica is free software: you can redistribute it and/or modify<br>
 *   it under the terms of the GNU General Public License as published by<br>
 *   the Free Software Foundation, either version 3 of the License, or<br>
 *   (at your option) any later version.<br>
 *   <br>
 *   Ballistica is distributed in the hope that it will be useful,<br>
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of<br>
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the<br>
 *   GNU General Public License for more details.<br>
 *   <br>
 *   You should have received a copy of the GNU General Public License<br>
 *     along with Ballistica.  If not, see &lt;http://www.gnu.org/licenses/&gt;.<br>
*/
#include "RangeTrack.h"
#include <stdio.h>
using namespace cv;
RangeTrack::RangeTrack(){
	area = 0;
	pixelcount = 0;
	setToleranceDefault();
	lighting_setRangeMIN = 0;
	lighting_setRangeMAX = 40;
	levelIndex = 0;
	resRect = Rect(0,0,0,0);
	drawColor = Scalar(0,255,0);
	sensitivity = 100;
	activeLocked = false;
	decay = 0;
	subbox = NULL;
}
RangeTrack::~RangeTrack(){}
Point RangeTrack::processRangeTracking(Mat &mainimage,  int targetheightPIX){	
	std::vector < std::vector < cv::Point > >contours;
	Mat src_gray = Mat(Size(mainimage.size().width, mainimage.size().height), IPL_DEPTH_16U, 1);
    Mat dst  = Mat(Size(mainimage.size().width, mainimage.size().height), IPL_DEPTH_16U, 1);
    cvtColor( mainimage, src_gray, CV_RGB2GRAY );
    //threshold( src_gray, dst, 100, 255, cv::THRESH_BINARY_INV );
	threshold( src_gray, dst, lighting_low, lighting_high, lighting_type );	// deb100 what happened here?
    findContours (dst, contours, CV_RETR_EXTERNAL, CV_CHAIN_APPROX_NONE);
    for( size_t i = 0; i < contours.size(); i++ ) {
    	approxPolyDP( cv::Mat(contours[i]), contours[i], 3, true );
    	Rect tRect =  cv::boundingRect(cv::Mat(contours[i]));
		float rectheight = abs(tRect.tl().y - tRect.br().y);   			// This is where comparison to target height is done.
		float rectlength = abs(tRect.tl().x - tRect.br().x);		// possibly length too
		if((((rectheight * lowertolMOD) < targetheightPIX) && (rectheight*uppertolMOD) > targetheightPIX) ||
		   (((rectlength * lowertolMOD) < targetheightPIX) && (rectlength*uppertolMOD) > targetheightPIX)) {  // Target might be horizontil
			resRect = Rect(tRect);
			pixelcount = (int)(resRect.height * resRect.width);
			area = (int)(resRect.height * resRect.width);
			break;
		}  // if
    } // for
	if(resRect.area() > 0){
		// Side effect? Draw to main image to box the target
		rectangle( mainimage, resRect.tl(), resRect.br(), Scalar(0,255,0), 1, 8, 0 );
		return Point(resRect.x + (int)(resRect.width/2), resRect.y + (int)(resRect.height/2));
	} else {
		activeLocked = false;
		resRect = Rect(0,0,0,0);
		return Point(0,0);
	} // if
}
Point RangeTrack::processRangeTracking(int targetheightPIX){	
	std::vector < std::vector < cv::Point > >contours;
	Mat src_gray = Mat(Size(subbox.size().width, subbox.size().height), IPL_DEPTH_16U, 1);
    Mat dst  = Mat(Size(subbox.size().width, subbox.size().height), IPL_DEPTH_16U, 1);
    cvtColor( subbox, src_gray, CV_RGB2GRAY );
    //threshold( src_gray, dst, 100, 255, cv::THRESH_BINARY_INV );
	threshold( src_gray, dst, lighting_low, lighting_high, lighting_type );	// deb100 what happened here?
    findContours (dst, contours, CV_RETR_EXTERNAL, CV_CHAIN_APPROX_NONE);
    for( size_t i = 0; i < contours.size(); i++ ) {
    	approxPolyDP( cv::Mat(contours[i]), contours[i], 3, true );
    	Rect tRect =  cv::boundingRect(cv::Mat(contours[i]));
		float rectheight = abs(tRect.tl().y - tRect.br().y);   			// This is where comparison to target height is done.
		float rectlength = abs(tRect.tl().x - tRect.br().x);		// possibly length too
		if((((rectheight * lowertolMOD) < targetheightPIX) && (rectheight*uppertolMOD) > targetheightPIX) ||
		   (((rectlength * lowertolMOD) < targetheightPIX) && (rectlength*uppertolMOD) > targetheightPIX)) {  // Target might be horizontil
			resRect = Rect(tRect);
			pixelcount = (int)(resRect.height * resRect.width);
			area = (int)(resRect.height * resRect.width);
			break;
		}  // if
    } // for
	if(resRect.area() > 0){
		// Side effect? Draw to main image to box the target
		//rectangle( mainimage, resRect.tl(), resRect.br(), Scalar(0,255,0), 1, 8, 0 );
		return Point(resRect.x + (int)(resRect.width/2), resRect.y + (int)(resRect.height/2));
	} else {
		activeLocked = false;
		resRect = Rect(0,0,0,0);
		subbox = NULL;
		return Point(0,0);
	} // if
}


int RangeTrack::getArea(){
	return (int)area;
}
int RangeTrack::getPixelCount(){
	return	pixelcount;
}
bool RangeTrack::checkSensitivityThreshold(){
	decay--;		// Side effect
	if(pixelcount > sensitivity){  // And the rectangle has to have some substance to it. 
		if ((area != 0) && (decay > 0)) { 
			return true;
		} else {
			activeLocked = false;
			pixelcount = 0;
			decay = 0;		
		} // if
	} // if
	return false; // having gotten this far...
}
void RangeTrack::setToleranceDefault(){
	lowertolMOD = 0.70f;	// defaults
	uppertolMOD = 1.10f;
}
void RangeTrack::setToleranceLow(){
	lowertolMOD = 0.90f;
	uppertolMOD = 1.05f;
}
void RangeTrack::setToleranceHigh(){
	lowertolMOD = 0.60f;
	uppertolMOD = 1.20f;
}
void RangeTrack::setToleranceSpecified(float l, float h){
	lowertolMOD = l;
	uppertolMOD = h;
}
void RangeTrack::setLightLevel(int level){
	if(level > lighting_setRangeMAX)levelIndex = lighting_setRangeMAX;
	if(level < lighting_setRangeMIN)levelIndex = lighting_setRangeMIN;
	switch (level) {
		case 0:{levelIndex = 10;setLightOnDark(levelIndex);break;}// 0 - 10 are light on dark settings
		case 1:{levelIndex = 10;setLightOnDark(levelIndex);break;}
		case 2:{levelIndex = 10;setLightOnDark(levelIndex);break;}
		case 3:{levelIndex = 10;setLightOnDark(levelIndex);break;}
		case 4:{levelIndex = 10;setLightOnDark(levelIndex);break;}
		case 5:{levelIndex = 10;setLightOnDark(levelIndex);break;}
		case 6:{levelIndex = 10;setLightOnDark(levelIndex);break;}
		case 7:{levelIndex = 10;setLightOnDark(levelIndex);break;}
		case 8:{levelIndex = 10;setLightOnDark(levelIndex);break;}
		case 9:{levelIndex = 10;setLightOnDark(levelIndex);break;}
		case 10:{
			levelIndex = 10;
			setLightOnDark(levelIndex);
			break;} // 10
		case 11:{levelIndex = 20;setLightOnLight(levelIndex);break;}
		case 12:{levelIndex = 20;setLightOnLight(levelIndex);break;}
		case 13:{levelIndex = 20;setLightOnLight(levelIndex);break;}
		case 14:{levelIndex = 20;setLightOnLight(levelIndex);break;}
		case 15:{levelIndex = 20;setLightOnLight(levelIndex);break;}
		case 16:{levelIndex = 20;setLightOnLight(levelIndex);break;}
		case 17:{levelIndex = 20;setLightOnLight(levelIndex);break;}
		case 18:{levelIndex = 20;setLightOnLight(levelIndex);break;}
		case 19:{
			levelIndex = 20;
			setLightOnLight(levelIndex);
			break;}
		case 20:{ // 11 - 20 are light on light settings
			levelIndex = 20;
			setLightOnLight(levelIndex);
			break;
		} // 20
		case 21:{levelIndex = 30;setDarkOnLight(levelIndex);break;}// 21-30 are dark on light settings
		case 22:{levelIndex = 30;setDarkOnLight(levelIndex);break;}
		case 23:{levelIndex = 30;setDarkOnLight(levelIndex);break;}
		case 24:{levelIndex = 30;setDarkOnLight(levelIndex);break;}
		case 25:{levelIndex = 30;setDarkOnLight(levelIndex);break;}
		case 26:{levelIndex = 30;setDarkOnLight(levelIndex);break;}
		case 27:{levelIndex = 30;setDarkOnLight(levelIndex);break;}
		case 28:{levelIndex = 30;setDarkOnLight(levelIndex);break;}
		case 29:{levelIndex = 30;setDarkOnLight(levelIndex);break;}
		case 30:{
			levelIndex = 30;
			setDarkOnLight(levelIndex);
			break;
		} // 30
		case 31:{levelIndex = 40;setDarkOnDark(levelIndex);break;}// 31-40 are dark on dark settings
		case 32:{levelIndex = 40;setDarkOnDark(levelIndex);break;}
		case 33:{levelIndex = 40;setDarkOnDark(levelIndex);break;}
		case 34:{levelIndex = 40;setDarkOnDark(levelIndex);break;}
		case 35:{levelIndex = 40;setDarkOnDark(levelIndex);break;}
		case 36:{levelIndex = 40;setDarkOnDark(levelIndex);break;}
		case 37:{levelIndex = 40;setDarkOnDark(levelIndex);break;}
		case 38:{levelIndex = 40;setDarkOnDark(levelIndex);break;}
		case 39:{levelIndex = 40;setDarkOnDark(levelIndex);break;}
		case 40:{
			levelIndex = 40;
			setDarkOnDark(levelIndex);
			break;
		} // 40
		case 41:{
			levelIndex = 0;
			setDefaultLighting();
			break;
		} // 41
		default:{
			levelIndex = 0;
			break;
		}
	} // switch
	// Note: further additional case blocks that represent other light spectrums
	// should have a value that represents the starting wavelengh of the band.
}
void RangeTrack::setDefaultLighting(){
	lighting_low          = 65;        // default values
	lighting_high         = 255;
	lighting_smooth       = 1;
	lighting_type         = CV_THRESH_BINARY;
}
void RangeTrack::setZeroLightingParameters(){
	lighting_low          = 0;        // default values
	lighting_high         = 0;
	lighting_smooth       = 1;
	lighting_type         = CV_THRESH_BINARY;
}
void RangeTrack::setDirectLighting(int a, int b, int c, int d){
	lighting_low = a;
	lighting_high = b;
	lighting_smooth = c;
	if (d > 4) d = 0;
	lighting_type = d;
}
void RangeTrack::setDirectType(int i) {
	// See OpenCV Imgproc settings
	if (i > 4) i = 0;
	lighting_type = i;
}
void RangeTrack::setLightOnDark(int level){
	   switch (level) {
		case 10: {
			lighting_low = 1;
			lighting_high = 255;
			lighting_smooth = 3;  // This can really bog down a blur algorithm so don't use this in a "wide area" scan
			lighting_type = CV_THRESH_TOZERO_INV;
			highcolor = cv::Scalar(255,255,255);//WHITE
			lowcolor = cv::Scalar(0,0,0);//BLACK
			break;
		} //case 10
		default :{setDefaultLighting();break;} // default
	} // switch
}
void RangeTrack::setLightOnLight(int level){
	switch (level) {
		case 19:{
			lighting_low = 1;
			lighting_high = 255;
			lighting_smooth = 1;
			lighting_type = CV_THRESH_BINARY_INV;
			highcolor = cv::Scalar(170,170,170);//GRAY;
			lowcolor = cv::Scalar(85,85,85);//DARK_GRAY;
			return;
		} //case 19
		case 20:{
			lighting_low = 0;
			lighting_high = 1;
			lighting_smooth = 17;// This can really bog down a blur algorithm so don't use this in a "wide area" scan
			lighting_type = CV_THRESH_BINARY_INV;
			highcolor = cv::Scalar(170,170,170);//GRAY;
			lowcolor = cv::Scalar(85,85,85);//DARK_GRAY;
			return;
		} //case 20
		default :{setDefaultLighting();break;} // default
	} // switch
}
void RangeTrack::setDarkOnLight(int level){
	switch (level) {
		case 30: {
			lighting_low = 194;
			lighting_high = 24;
			lighting_smooth = 19;// This can really bog down a blur algorithm so don't use this in a "wide area" scan
			lighting_type = CV_THRESH_BINARY;
			highcolor = cv::Scalar(0,0,0);//BLACK;
			lowcolor = cv::Scalar(255,255,255);//WHITE
			break;
		} // case 30
		default :{setDefaultLighting();
				break;
		} // default
	} // switch
}
void RangeTrack::setDarkOnDark(int level){
	switch (level) {
		case 40: {
			lighting_low = 45;
			lighting_high = 60;
			lighting_smooth = 9;
			lighting_type = CV_THRESH_TOZERO;
			highcolor = cv::Scalar(85,85,85); //DARK_GRAY
			lowcolor = cv::Scalar(0,0,0);//BLACK
			break;
		} // case 40
		default :{setDefaultLighting();
			break;
		} // default
	} // switch
}
void RangeTrack::incrementLightLevel(){
	levelIndex++;
	setLightLevel(levelIndex);
}
void RangeTrack::decrementLightLevel(){
	levelIndex--;
	setLightLevel(levelIndex);
}
void RangeTrack::drawLightSettingSymbol(cv::Mat g, int x, int y){
	rectangle(g,cv::Point( x-50, y-50 ),cv::Point( x+50, y+50),lowcolor,-1,0);
	circle(g,cv::Point( x, y ),25,highcolor,3,8,0 );
}
Rect RangeTrack::getCurrentRectangle(){
	return subboxbrect;
}
bool RangeTrack::locked(){
	return activeLocked;
}
void RangeTrack::setTargetBox(int x, int y){
	defaultL = 60;      // Default Length of box
	defaultH = 60;      // Default Height of box
	screenReferenceCOG = cv::Point(x, y);
	subboxReferenceCOG = cv::Point((int)defaultL/2, (int)defaultH/2);   // Center in the cv::Rect Construct
	subboxbrect = cv::Rect(x, y, defaultL, defaultH);	
	decay  = 10000;
	sensitivity = area;
	activeLocked = true;
}
void RangeTrack::setTargetBox(int x, int y, int w, int h){
	defaultL = 60;      // Default Length of box
	defaultH = 60;      // Default Height of box
	screenReferenceCOG = cv::Point(x, y);
	subboxReferenceCOG = cv::Point((int)w/2, (int)h/2);   // Center in the cv::Rect Construct
	subboxbrect = cv::Rect(x, y, w, h);	
	decay  = 10000;
	sensitivity = area;
	activeLocked = true;
}
void RangeTrack::setTargetBox(Rect r){
	defaultL = 60;      // Default Length of box
	defaultH = 60;      // Default Height of box
	screenReferenceCOG = cv::Point(r.x, r.y);
	subboxReferenceCOG = cv::Point((int)r.width/2, (int)r.height/2);   // Center in the cv::Rect Construct
	subboxbrect = r;
	decay  = 10000;
	sensitivity = area;
	activeLocked = true;
}

bool RangeTrack::checkROIBoundaries(int imgx, int imgy){
	if((subboxbrect.x + subboxbrect.width/2) >= imgx-10) return false;  // X bounds exceeded.
	if((subboxbrect.x - subboxbrect.width/2) <= 0+10) return false; // unlikely but check anyway
	if((subboxbrect.y + subboxbrect.height/2) >= imgy-10) return false;  // Y bounds exceeded.
	if((subboxbrect.y - subboxbrect.height/2) <= 0+10) return false; // unlikely but check anyway
	return true; // made it this far, checks good.
}
void RangeTrack::applyCOGDisplacement(cv::Point modCOG){
	//  This function is called after there is a movement detecton in a sub-box,
	//  The COG of the box itself is always the center, and the box itself was searched for movement (plus a little more),
	//  But the entire cv::Rect that defines the target box must be moved the distance of the displacement
	//  of the incoming COG data the differs from the cog of the sub-box.
	if (modCOG == subboxReferenceCOG) return;  // unlikely
	if(modCOG.x < subboxReferenceCOG.x) {
		subboxbrect.x -= abs(modCOG.x - subboxReferenceCOG.x);  // move the entire cv::Rect's position on the entire screen.
		screenReferenceCOG.x -= abs(modCOG.x - subboxReferenceCOG.x);  // Adjust the COG of the movement detected as carried in from the cvmoment call results
	} else if (modCOG.x > subboxReferenceCOG.x){
		subboxbrect.x += abs(modCOG.x - subboxReferenceCOG.x);
		screenReferenceCOG.x += abs(modCOG.x - subboxReferenceCOG.x);
	} else {
		// nothing
	}  // if
	if(modCOG.y < subboxReferenceCOG.y) {
		subboxbrect.y -= abs(modCOG.y - subboxReferenceCOG.y);
		screenReferenceCOG.y -= abs(modCOG.y - subboxReferenceCOG.y);
	} else if (modCOG.y > subboxReferenceCOG.y){
		subboxbrect.y += abs(modCOG.y - subboxReferenceCOG.y);
		screenReferenceCOG.y += abs(modCOG.y - subboxReferenceCOG.y);
	} else {
		// nothing
	}  // if
}
void RangeTrack::drawTargetBox(Mat& g){  // Simple indication is something -
	cv::rectangle(g, Rect(subboxbrect.x-(int)(subboxbrect.width/2),subboxbrect.y-(int)(subboxbrect.height/2),subboxbrect.height, subboxbrect.width), drawColor, 2, 1, 0);
}
cv::Point  RangeTrack::getTargetBoxCenter(){
	cv::Point p = cv::Point();
	p.x = subboxbrect.x + (int)(subboxbrect.width/2);
	p.y = subboxbrect.y + (int)(subboxbrect.height/2);
	return p;
}

