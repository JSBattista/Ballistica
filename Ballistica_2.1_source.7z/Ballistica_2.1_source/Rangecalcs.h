/*
Ballistica 2.1
 *<b>Ballistica Version 2 "Foe-hammer". </b><br>
 *<b>Copyright 2014 Ballistica Software Defined Scope System (SDSS)</b><br>
 *<pre>
 *   This program is free software: you can redistribute it and/or modify<br>
 *   it under the terms of the GNU General Public License as published by<br>
 *   the Free Software Foundation, either version 3 of the License, or<br>
 *   (at your option) any later version.<br>
 *   <br>
 *   This program is distributed in the hope that it will be useful,<br>
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of<br>
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the<br>
 *   GNU General Public License for more details.<br>
 *   <br>
 *   You should have received a copy of the GNU General Public License<br>
 *   along with this program.  If not, see &lt;http://www.gnu.org/licenses/&gt;.<br>
 * </pre>
 * <pre>
 *   This file is part of Ballistica.<br>
 *   <br>
 *   Ballistica is free software: you can redistribute it and/or modify<br>
 *   it under the terms of the GNU General Public License as published by<br>
 *   the Free Software Foundation, either version 3 of the License, or<br>
 *   (at your option) any later version.<br>
 *   <br>
 *   Ballistica is distributed in the hope that it will be useful,<br>
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of<br>
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the<br>
 *   GNU General Public License for more details.<br>
 *   <br>
 *   You should have received a copy of the GNU General Public License<br>
 *     along with Ballistica.  If not, see &lt;http://www.gnu.org/licenses/&gt;.<br>
*/
#ifndef RANGECALCS_H_
#define RANGECALCS_H_
#include <string.h>
#include <stdlib.h>
#include <opencv2\highgui\highgui.hpp>
#include <opencv2\imgproc\imgproc.hpp>
#include <opencv2\core\core.hpp>
using namespace std;
using namespace cv;
#include <iostream>
#include <vector>
#include <stdio.h>
using namespace std;
class Rangecalcs {
public:
	Rangecalcs();
	Rangecalcs(int, int, int);
	void pushNewStats(int, double, double, double, double, double, double);
	virtual ~Rangecalcs();
	void clear();
	int getCurrentRange();
	int getCurrentZoom();
	int getCurrentZero();
	int* getRanges();
	int getCalcsCount();
	int getRangeAtElement(int);
	double* getBDCPaths();
	double* getReticleDisplacementsBDCs();
	double* getTimes();
	double* getVelocities();
	double* getWindages();
	double* getReticleDisplacementsWNDs();
	double getBDCPathAtRange();
	double getBDCPathAtRange(int);
	double getRangeAtRange(int);
	double getReticleDisplacementsBDCAtRange();
	double getReticleDisplacementsBDCAtRange(int);
	double getTimeAtRange();
	double getTimeAtRange(int);
	double getVelocityAtRange();
	double getVelocityAtRange(int);
	double getWindageAtRange();
	double getWindageAtRange(int);
	double getReticleDisplacementWNDAtRange();
	double getReticleDisplacementWNDAtRange(int);
	void updateTargetRange(int);
	void updateZoom(int);
	void updateZero(int);
	int* generateRanges();
	int* generateRanges(int);
	bool isNeedingNewSolution();
	void notifySetUpdate();
	int getRangeElementsCount();
	void drawPlatformOverview(Mat&, int, int);
	int rangeElementsCount;
private:
	// NESTED CLASS
	class RangePATHReticleDISP { 
	public:
			int      range;
			double   path;
			double   reticleDispBDC;
			double   time;
			double   velocity;
			double   windage;
			double   reticleDispWND;
	};
	int range;
    int zoom;
    int zero;
    bool needNewSolution;
    std::vector<RangePATHReticleDISP> calcs;
    int rangeMAXGranularity;
	int roundRange(int);
};
#endif /* RANGECALCS_H_ */
