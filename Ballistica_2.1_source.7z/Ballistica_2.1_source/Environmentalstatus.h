/*
Ballistica 2.1
 *<b>Ballistica Version 2 "Foe-hammer". </b><br>
 *<b>Copyright 2014 Ballistica Software Defined Scope System (SDSS)</b><br>
 *<pre>
 *   This program is free software: you can redistribute it and/or modify<br>
 *   it under the terms of the GNU General Public License as published by<br>
 *   the Free Software Foundation, either version 3 of the License, or<br>
 *   (at your option) any later version.<br>
 *   <br>
 *   This program is distributed in the hope that it will be useful,<br>
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of<br>
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the<br>
 *   GNU General Public License for more details.<br>
 *   <br>
 *   You should have received a copy of the GNU General Public License<br>
 *   along with this program.  If not, see &lt;http://www.gnu.org/licenses/&gt;.<br>
 * </pre>
 * <pre>
 *   This file is part of Ballistica.<br>
 *   <br>
 *   Ballistica is free software: you can redistribute it and/or modify<br>
 *   it under the terms of the GNU General Public License as published by<br>
 *   the Free Software Foundation, either version 3 of the License, or<br>
 *   (at your option) any later version.<br>
 *   <br>
 *   Ballistica is distributed in the hope that it will be useful,<br>
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of<br>
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the<br>
 *   GNU General Public License for more details.<br>
 *   <br>
 *   You should have received a copy of the GNU General Public License<br>
 *     along with Ballistica.  If not, see &lt;http://www.gnu.org/licenses/&gt;.<br>
*/
#ifndef ENVIRONMENTALSTATUS_H_
#define ENVIRONMENTALSTATUS_H_
#include <string.h>
#include <stdlib.h>
#include <opencv2\highgui\highgui.hpp>
#include <opencv2\imgproc\imgproc.hpp>
#include <opencv2\core\core.hpp>
using namespace std;
using namespace cv;
class Environmentalstatus {
public:
	Environmentalstatus();
	virtual ~Environmentalstatus();
	double getAltitude();
	void setAltitude(double);
	double getBarometric();
	void setBarometric(double);
	double getTempurature();
	void setTempurature(double);
	double getWindSpeed();
	void setWindSpeed(double);
	double getWindDirection();
	void setWindDirection(double);
	double getRelativeHumidity();
	void setRelativeHumidity(double);
	void drawWindDirection(Mat&, int, int);
	void drawTempuratureIndication(Mat&, int, int);
	void drawBarometricIndication(Mat&, int, int);
	void drawAltitudeIndication(Mat&, int, int);
	//double* getENVVal();
	bool checkENVStatusUpdate();
	bool isChanged();
private:
	double altitude;
    double temperature;
    double barometric;
    double relativeHumidity;
    double windSpeed; // The wind speed in miles per hour.
    double windAngle; // The wind angle (0=headwind, 90=right to left, 180=tailwind, 270/-90=left to right
    int iENVStatIterationControl; // checking environment every iteration of the loop may be too much. For an aerial platform, the frequency of this check might have to increase as altitude and barometric can change rapidly.
    int  iENVStatReset;    // Check every 100th time in this case
    bool changeEvent;
};
#endif /* ENVIRONMENTALSTATUS_H_ */
