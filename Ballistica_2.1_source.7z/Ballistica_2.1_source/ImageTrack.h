/*
Ballistica 2.1
 *<b>Ballistica Version 2 "Foe-hammer". </b><br>
 *<b>Copyright 2014 Ballistica Software Defined Scope System (SDSS)</b><br>
 *<pre>
 *   This program is free software: you can redistribute it and/or modify<br>
 *   it under the terms of the GNU General Public License as published by<br>
 *   the Free Software Foundation, either version 3 of the License, or<br>
 *   (at your option) any later version.<br>
 *   <br>
 *   This program is distributed in the hope that it will be useful,<br>
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of<br>
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the<br>
 *   GNU General Public License for more details.<br>
 *   <br>
 *   You should have received a copy of the GNU General Public License<br>
 *   along with this program.  If not, see &lt;http://www.gnu.org/licenses/&gt;.<br>
 * </pre>
 * <pre>
 *   This file is part of Ballistica.<br>
 *   <br>
 *   Ballistica is free software: you can redistribute it and/or modify<br>
 *   it under the terms of the GNU General Public License as published by<br>
 *   the Free Software Foundation, either version 3 of the License, or<br>
 *   (at your option) any later version.<br>
 *   <br>
 *   Ballistica is distributed in the hope that it will be useful,<br>
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of<br>
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the<br>
 *   GNU General Public License for more details.<br>
 *   <br>
 *   You should have received a copy of the GNU General Public License<br>
 *     along with Ballistica.  If not, see &lt;http://www.gnu.org/licenses/&gt;.<br>
*/
#ifndef IMAGETRACK_H_
#define IMAGETRACK_H_
#include <opencv2\highgui\highgui.hpp>
#include <opencv2\imgproc\imgproc.hpp>
#include <opencv2\core\core.hpp>
using namespace std;
using namespace cv;
class ImageTrack{
public:
	ImageTrack();
	virtual ~ImageTrack();
	unsigned int getCaptureReticleSize();
	cv::Rect aperture;
	unsigned int getDisplacement();
	void setCaptureApertureSize(unsigned int);
	void setTrackingImage(cv::Mat &, int, int);
	cv::Point processImageTracking(cv::Mat &);
	cv::Point ImageTrack::processImageTracking();
	void drawImageCapture(cv::Mat& , int, int, String);
	int getArea();
	int getPixelCount();
	
	
	
	Mat subbox;
	void setTargetBox(int, int);
	void setTargetBox(int, int, int, int);
	void setTargetBox(Rect);
	cv::Point screenReferenceCOG;  // This maintains the actual detected on "main screen" Center of gravity.
	cv::Point subboxReferenceCOG;  // This is the detected movement COG inside of the rectangle for narrowed movement detection
	cv::Rect subboxbrect;    
	cv::Rect getCurrentRectangle(void);
	bool checkROIBoundaries(int, int);
	cv::Point getTargetBoxCenter();
	void drawTargetBox(cv::Mat&);
	void applyCOGDisplacement(cv::Point);
	void getCOG(void);
	int sensitivity;	// Used as a kind of results threshold
	bool checkSensitivityThreshold(void);
	bool locked(void);
	bool compareAssignRect(cv::Rect, cv::Rect);

private:
	int decay;  
	cv::Mat trackimage;
	cv::Mat matchresult;
	cv::Mat difference;
	cv::Scalar drawColor;
	double area;
	int pixelcount;
	unsigned int aperturesize;
	int xlimit;
	int ylimit;
	unsigned int displacement;
	int defaultL;      // Default Length of box
	int defaultH;      // Default Height of box
	bool activeLocked;
};
#endif /* IMAGETRACK_H_ */
