/*
 *<b>Ballistica Version 2.1 "Foe-hammer". </b><br>
 *<b>Copyright 2014 Ballistica Software Defined Scope System (SDSS)</b><br>
 *<pre>
 *   This program is free software: you can redistribute it and/or modify<br>
 *   it under the terms of the GNU General Public License as published by<br>
 *   the Free Software Foundation, either version 3 of the License, or<br>
 *   (at your option) any later version.<br>
 *   <br>
 *   This program is distributed in the hope that it will be useful,<br>
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of<br>
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the<br>
 *   GNU General Public License for more details.<br>
 *   <br>
 *   You should have received a copy of the GNU General Public License<br>
 *   along with this program.  If not, see &lt;http://www.gnu.org/licenses/&gt;.<br>
 * </pre>
 * <pre>
 *   This file is part of Ballistica.<br>
 *   <br>
 *   Ballistica is free software: you can redistribute it and/or modify<br>
 *   it under the terms of the GNU General Public License as published by<br>
 *   the Free Software Foundation, either version 3 of the License, or<br>
 *   (at your option) any later version.<br>
 *   <br>
 *   Ballistica is distributed in the hope that it will be useful,<br>
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of<br>
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the<br>
 *   GNU General Public License for more details.<br>
 *   <br>
 *   You should have received a copy of the GNU General Public License<br>
 *     along with Ballistica.  If not, see &lt;http://www.gnu.org/licenses/&gt;.<br>
*/
#include "Targetvector.h"
#include <cmath>
#include <time.h>
#include <stdio.h>
#include <windows.h>
using namespace std;
using namespace cv;
Targetvector::Targetvector() {
	timeConstant = 1000;			// millisecond block to anchor time around
	previousTime = 0;
	speedRefMPH = 0;
	vectorREF = Point(0,0);
}
Targetvector::Targetvector(int x, int y){
	vectorREF =  Point(x, y);
	//vectorREF = Point(0,0);
	timeConstant = 1000;			// millisecond block to anchor time around
	previousTime = 0;
	timeREF = currentTimeMillis();
	speedRefMPH = 0;
}
Targetvector::~Targetvector() {}
void Targetvector::update(){
	timeREF = currentTimeMillis();
}
void Targetvector::update(Point ncog){
	timeREF = currentTimeMillis();
}
Point Targetvector::getRefCOG(){
	return vectorREF;
}
long Targetvector::getTimeRef(){
	return timeREF;
}
double Targetvector::getCOGDistance(Point presentCOG){//  This calculates the distance between two Points
	return sqrt(abs(presentCOG.x - vectorREF.x) + abs(presentCOG.y - vectorREF.y));
}
float Targetvector::getSpeed(double inchesMoved){  //  Taking the number of inches moved from one time stamp to another,
	long currentTime = currentTimeMillis();
	long span = abs(currentTime - previousTime);
	if(span == 0)span = 1; // In the unlikely event....
	speedFPS = (((inchesMoved*span) / (timeConstant * span)) /12) * 1000;
	speedIPS = speedFPS * 12;
	speedMPH = ((speedFPS*3600) / 5280) ;
	previousTime = currentTime;
	return speedMPH;
}
float Targetvector::getLeadInchesPerSecond(double timeToTarget){
	return speedIPS * timeToTarget;
}
float Targetvector::getLeadFeetPerSecond(double timeToTarget){
	return speedFPS * timeToTarget;
}
void Targetvector::drawVector(Mat& m, Point presentCOG, double time){
	//  See possibly Bresenham's line algorithm.
	if (presentCOG == vectorREF) {
		return;
	} // if
	try{
		Point vectorline = Point((int)(vectorREF.x + speedMPH*(presentCOG.x - vectorREF.x)),(int)(vectorREF.y + speedMPH*(presentCOG.y - vectorREF.y)));
		Scalar s;
		if (speedMPH > speedRefMPH)
			s = Scalar(0,255,127);
		else
			s = Scalar(0,0,255);		
		stringstream oss;		
		oss << "SPEED MPH " << speedMPH;
		putText(m, oss.str(), Point(presentCOG.x, presentCOG.y+40), 1, 0.9, s, 1, 1, false);
		speedRefMPH = speedMPH;
		line(m,	vectorline,	presentCOG, s, 1,1,0);
		vectorREF = presentCOG;
	} catch (int e) {
		// transient error though unlikely
	}  // try
}
long Targetvector::currentTimeMillis() {
	//struct timeval t;
	//gettimeofday(&t, NULL);
	//return ((t.tv_sec) * 1000 + t.tv_usec/1000.0) + 0.5;
	//unsigned int now =  timeGetTime();
	return timeGetTime();
}
