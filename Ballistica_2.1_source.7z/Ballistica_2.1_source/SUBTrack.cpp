/*
 *<b>Ballistica Version 2.1 "Foe-hammer". </b><br>
 *<b>Copyright 2014 Ballistica Software Defined Scope System (SDSS)</b><br>
 *<pre>
 *   This program is free software: you can redistribute it and/or modify<br>
 *   it under the terms of the GNU General Public License as published by<br>
 *   the Free Software Foundation, either version 3 of the License, or<br>
 *   (at your option) any later version.<br>
 *   <br>
 *   This program is distributed in the hope that it will be useful,<br>
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of<br>
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the<br>
 *   GNU General Public License for more details.<br>
 *   <br>
 *   You should have received a copy of the GNU General Public License<br>
 *   along with this program.  If not, see &lt;http://www.gnu.org/licenses/&gt;.<br>
 * </pre>
 * <pre>
 *   This file is part of Ballistica.<br>
 *   <br>
 *   Ballistica is free software: you can redistribute it and/or modify<br>
 *   it under the terms of the GNU General Public License as published by<br>
 *   the Free Software Foundation, either version 3 of the License, or<br>
 *   (at your option) any later version.<br>
 *   <br>
 *   Ballistica is distributed in the hope that it will be useful,<br>
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of<br>
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the<br>
 *   GNU General Public License for more details.<br>
 *   <br>
 *   You should have received a copy of the GNU General Public License<br>
 *     along with Ballistica.  If not, see &lt;http://www.gnu.org/licenses/&gt;.<br>
*/
#include "SUBTrack.h"
SUBTrack::SUBTrack(double(*cameraFP)(double,double), int threatheight){
	sub_model = BackgroundSubtractorMOG2();
	subhistory = 100;  // Long history helps the blurred foreground mask generate contours
	subthreshold = 16.0;
	update = true;
	shadowdetect = false;
	resRect = Rect(0,0,0,0);
	//occurence = 100;			
	getCalculatedRange = cameraFP;
	lowertolMOD  = 0.9f;
	uppertolMOD = 1.10f;	
	threatheightINCH = threatheight;
	range = 0;
	detectionThreshold = 50;
	drawColor = Scalar(0,0,255);
	sensitivity = 100;
	activeLocked = false;
	decay = 0;
	subbox = NULL;
}
SUBTrack::SUBTrack( int history, float threshold, bool shadow, int oc, double(*cameraFP)(double,double),  int threatheight){
	subhistory = history;
	subthreshold = threshold;
	shadowdetect =  shadow;
	sub_model = BackgroundSubtractorMOG2(history, threshold, shadowdetect);
	update = true;
	resRect = Rect(0,0,0,0);
	//occurence = oc;
	getCalculatedRange = cameraFP;
	lowertolMOD  = 0.9f;
	uppertolMOD = 1.10f;
	threatheightINCH = threatheight;
	range = 0;
	detectionThreshold = 50;
	drawColor = Scalar(0,0,255);
	sensitivity = 100;
	activeLocked = false;
	decay = 0;
	subbox = NULL;
}
SUBTrack::~SUBTrack(void)
{
}
/*
Code copied in. Note the initial values of the history and threshold are tested. 
Also needed here are the "auxilliary" functions to affect the thresh, etc.
There was also the "tilted boxing code that may or may not need to be here - but some means of keeping "where on the rectangle" the target was locked is important.
*/
void SUBTrack::processSUBTracking(cv::Mat &img){	
	if( foreground.empty())foreground.create(img.size(), img.type());
	sub_model(img, foregroundmask, update ? -1 : 0);
	foreground = Scalar::all(0);	
	img.copyTo(foreground, foregroundmask);
   // sub_model.getBackgroundImage(background);	
	std::vector < std::vector < cv::Point > >contours;
	findContours (foregroundmask, contours, CV_RETR_EXTERNAL, CV_CHAIN_APPROX_NONE);
	int areaAcc = 0;
	stringstream oss;
	for( size_t i = 0; i < contours.size(); i++ ) {			
    	approxPolyDP( cv::Mat(contours[i]), contours[i], 3, true );
    	Rect tRect =  cv::boundingRect(cv::Mat(contours[i]));
		float rectheight = abs(tRect.tl().y - tRect.br().y);   			// This is where comparison to target height is done.
		float rectwidth = abs(tRect.tl().x - tRect.br().x);		// possibly length too
		areaAcc += tRect.area();
		if(tRect.area() > detectionThreshold){   // Meaning we have a rect of some "area"
			// Side effect
			if(rectheight > rectwidth){
				range = getCalculatedRange(threatheightINCH, rectheight);
			}else{
				range = getCalculatedRange(threatheightINCH, rectwidth);
			}// if
			rectangle( img, resRect.tl(), resRect.br(), Scalar(0,255,0), 1, 8, 0 );
			// draw a range.... deb100
			oss.str("");
			oss << "RANGE: " << range;
			putText(img, oss.str(), Point( tRect.x-20, tRect.y-20 ), 1, 1.0, Scalar(0,0,255), 1, 1, false);
		} else {
			detectionThreshold = (int)((areaAcc / i) * 0.80f); //look for an average area and 80 percent of that.
		}// if
	} // for
}
cv::Point SUBTrack::processSUBTracking(int targetheightPIX){	
	if( foreground.empty())foreground.create(subbox.size(), subbox.type());
	sub_model(subbox, foregroundmask, update ? -1 : 0);
	foreground = Scalar::all(0);	
	subbox.copyTo(foreground, foregroundmask);
   // sub_model.getBackgroundImage(background);	
	std::vector < std::vector < cv::Point > >contours;
	findContours (foregroundmask, contours, CV_RETR_EXTERNAL, CV_CHAIN_APPROX_NONE);
    for( size_t i = 0; i < contours.size(); i++ ) {
    	approxPolyDP( cv::Mat(contours[i]), contours[i], 3, true );
    	Rect tRect =  cv::boundingRect(cv::Mat(contours[i]));
		float rectheight = abs(tRect.tl().y - tRect.br().y);   			// This is where comparison to target height is done.
		float rectlength = abs(tRect.tl().x - tRect.br().x);		// possibly length too
		if((((rectheight * lowertolMOD) < targetheightPIX) && (rectheight*uppertolMOD) > targetheightPIX) ||
		   (((rectlength * lowertolMOD) < targetheightPIX) && (rectlength*uppertolMOD) > targetheightPIX)) {  // Target might be horizontil
			resRect = Rect(tRect);
			pixelcount = (int)(resRect.height * resRect.width);
			area = (int)(resRect.height * resRect.width);
			break;
		}  // if
    } // for
	if(resRect.area() > 0){
		// Side effect
		//rectangle( img, resRect.tl(), resRect.br(), Scalar(0,255,0), 1, 8, 0 );
		return Point(resRect.x + (int)(resRect.width/2), resRect.y + (int)(resRect.height/2));
	} else {
		activeLocked = false;
		resRect = Rect(0,0,0,0);
		subbox = NULL;
		return Point(0,0);
	} // if
}
void SUBTrack::setHistory(int h){
	subhistory = h;
	sub_model = BackgroundSubtractorMOG2(subhistory, subthreshold, shadowdetect);
}
void SUBTrack::setThreshold(float t){
	subthreshold = t;
	sub_model = BackgroundSubtractorMOG2(subhistory, subthreshold, shadowdetect);
}
void SUBTrack::toggleShadowDetect(){
	shadowdetect = !shadowdetect;
}
bool SUBTrack::shadowDetecting(){
	return shadowdetect;
}
void SUBTrack::toggleUpdate(){
	update = !update;
}
bool SUBTrack::updating(){
	return update;
}
Rect SUBTrack::getCurrentRectangle(){
	return subboxbrect;
}
double SUBTrack::getCurrentRange(){
	return range;
}
void SUBTrack::setThreatHeightINCH(int h) {
	threatheightINCH = h;
}
int SUBTrack::getPixelCount(){
	return pixelcount;
}
int SUBTrack::getArea(){
	return resRect.area();
}
bool SUBTrack::locked(){
	return activeLocked;
}
bool SUBTrack::checkSensitivityThreshold(){
	decay--;		// Side effect
	if(pixelcount > sensitivity){  // And the rectangle has to have some substance to it. 
		if ((area != 0) && (decay > 0)) {  
			return true;
		} else {
			activeLocked = false;
			pixelcount = 0;
			decay = 0;
		} // if
	} // if
	return false; // having gotten this far...
}
void SUBTrack::setTargetBox(int x, int y){
	defaultL = 60;      // Default Length of box
	defaultH = 60;      // Default Height of box
	screenReferenceCOG = cv::Point(x, y);
	subboxReferenceCOG = cv::Point((int)defaultL/2, (int)defaultH/2);   // Center in the cv::Rect Construct
	subboxbrect = cv::Rect(x, y, defaultL, defaultH);	
	decay  = 10000;
	sensitivity = area;
	activeLocked = true;
}
void SUBTrack::setTargetBox(int x, int y, int w, int h){
	defaultL = 60;      // Default Length of box
	defaultH = 60;      // Default Height of box
	screenReferenceCOG = cv::Point(x, y);
	subboxReferenceCOG = cv::Point((int)w/2, (int)h/2);   // Center in the cv::Rect Construct
	subboxbrect = cv::Rect(x, y, w, h);	
	decay  = 10000;
	sensitivity = 100;
}
void SUBTrack::setTargetBox(Rect r){
	defaultL = 60;      // Default Length of box
	defaultH = 60;      // Default Height of box
	screenReferenceCOG = cv::Point(r.x, r.y);
	subboxReferenceCOG = cv::Point((int)r.width/2, (int)r.height/2);   // Center in the cv::Rect Construct
	subboxbrect = r;
	decay  = 10000;
	sensitivity = 100;
}
bool SUBTrack::checkROIBoundaries(int imgx, int imgy){
	if((subboxbrect.x + subboxbrect.width/2) >= imgx-10) return false;  // X bounds exceeded.
	if((subboxbrect.x - subboxbrect.width/2) <= 0+10) return false; // unlikely but check anyway
	if((subboxbrect.y + subboxbrect.height/2) >= imgy-10) return false;  // Y bounds exceeded.
	if((subboxbrect.y - subboxbrect.height/2) <= 0+10) return false; // unlikely but check anyway
	return true; // made it this far, checks good.
}
void SUBTrack::applyCOGDisplacement(cv::Point modCOG){
	//  This function is called after there is a movement detecton in a sub-box,
	//  The COG of the box itself is always the center, and the box itself was searched for movement (plus a little more),
	//  But the entire cv::Rect that defines the target box must be moved the distance of the displacement
	//  of the incoming COG data the differs from the cog of the sub-box.
	if (modCOG == subboxReferenceCOG) return;  // unlikely
	if(modCOG.x < subboxReferenceCOG.x) {
		subboxbrect.x -= abs(modCOG.x - subboxReferenceCOG.x);  // move the entire cv::Rect's position on the entire screen.
		screenReferenceCOG.x -= abs(modCOG.x - subboxReferenceCOG.x);  // Adjust the COG of the movement detected as carried in from the cvmoment call results
	} else if (modCOG.x > subboxReferenceCOG.x){
		subboxbrect.x += abs(modCOG.x - subboxReferenceCOG.x);
		screenReferenceCOG.x += abs(modCOG.x - subboxReferenceCOG.x);
	} else {
		// nothing
	}  // if
	if(modCOG.y < subboxReferenceCOG.y) {
		subboxbrect.y -= abs(modCOG.y - subboxReferenceCOG.y);
		screenReferenceCOG.y -= abs(modCOG.y - subboxReferenceCOG.y);
	} else if (modCOG.y > subboxReferenceCOG.y){
		subboxbrect.y += abs(modCOG.y - subboxReferenceCOG.y);
		screenReferenceCOG.y += abs(modCOG.y - subboxReferenceCOG.y);
	} else {
		// nothing
	}  // if
}
void SUBTrack::drawTargetBox(Mat& g){  // Simple indication is something -
	cv::rectangle(g, Rect(subboxbrect.x-(int)(subboxbrect.width/2),subboxbrect.y-(int)(subboxbrect.height/2),subboxbrect.height, subboxbrect.width), drawColor, 2, 1, 0);
}
cv::Point  SUBTrack::getTargetBoxCenter(){
	cv::Point p = cv::Point();
	p.x = subboxbrect.x + (int)(subboxbrect.width/2);
	p.y = subboxbrect.y + (int)(subboxbrect.height/2);
	return p;
}
