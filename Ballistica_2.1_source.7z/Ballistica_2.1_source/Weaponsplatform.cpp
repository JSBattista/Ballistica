/*
 *<b>Ballistica Version 2.1 "Foe-hammer". </b><br>
 *<b>Copyright 2014 Ballistica Software Defined Scope System (SDSS)</b><br>
 *<pre>
 *   This program is free software: you can redistribute it and/or modify<br>
 *   it under the terms of the GNU General Public License as published by<br>
 *   the Free Software Foundation, either version 3 of the License, or<br>
 *   (at your option) any later version.<br>
 *   <br>
 *   This program is distributed in the hope that it will be useful,<br>
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of<br>
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the<br>
 *   GNU General Public License for more details.<br>
 *   <br>
 *   You should have received a copy of the GNU General Public License<br>
 *   along with this program.  If not, see &lt;http://www.gnu.org/licenses/&gt;.<br>
 * </pre>
 * <pre>
 *   This file is part of Ballistica.<br>
 *   <br>
 *   Ballistica is free software: you can redistribute it and/or modify<br>
 *   it under the terms of the GNU General Public License as published by<br>
 *   the Free Software Foundation, either version 3 of the License, or<br>
 *   (at your option) any later version.<br>
 *   <br>
 *   Ballistica is distributed in the hope that it will be useful,<br>
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of<br>
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the<br>
 *   GNU General Public License for more details.<br>
 *   <br>
 *   You should have received a copy of the GNU General Public License<br>
 *     along with Ballistica.  If not, see &lt;http://www.gnu.org/licenses/&gt;.<br>
*/
#include "Weaponsplatform.h"
#include <cmath>
Weaponsplatform::Weaponsplatform(){
	boresiteAngle = 0;
	rangeZero = 100;   // Default value when not given.
    maxmag = 1; // Max magnification assumed to be 1 (lest there be div/0 issues)
    heightOverBore = 1.5;  // default height over bore

}
Weaponsplatform::Weaponsplatform (double a, double rangezeroed, double hb){
    boresiteAngle = a;
    rangeZero = rangezeroed;
    heightOverBore = hb;
    maxmag = 1; // Max magnification assumed to be 1 (lest there be div/0 issues)
}
Weaponsplatform::Weaponsplatform (double a, double rangezeroed, int mm, double hb){
        boresiteAngle = a;
        rangeZero = rangezeroed;
        maxmag = mm;
        heightOverBore = hb;
}
Weaponsplatform::~Weaponsplatform() {}
void Weaponsplatform::setCantDeviation(double c){
        boresiteAngle = c;
    }
double Weaponsplatform::getCantDeviation(){
    return boresiteAngle;
}
bool Weaponsplatform::cantDeviationPresent(){
    if (boresiteAngle != 0)return true;
    return false;
}
double Weaponsplatform::getCantDeviationHorizontil(double bulletDropINCHES) {  // This appears to the a horizontil deviation
    if (boresiteAngle == 0)return 0.0f;
    return sin(boresiteAngle) * bulletDropINCHES;
}
double Weaponsplatform::getCantDeviationVertical(double bulletDropINCHES) {      // Apparently this is a vertical drop
    if (boresiteAngle == 0)return 0.0f;
    return cos((90 - boresiteAngle)*bulletDropINCHES);
}
void Weaponsplatform::drawCantIndication(Mat& g, int x, int y){
	ellipse(g, Point(x-50, y ), Size( 200, 100), 0, 360, 180, Scalar(255,255,255),2,0);
	stringstream oss;
	if(boresiteAngle < 0){
		oss << "CANTING LEFT: " << boresiteAngle;
		putText(g, oss.str(), Point(x-125, y+25), 1, 0.9, Scalar(0,255,255), 1, 1, false);
	} else if (boresiteAngle > 0){
		oss.str("");
		oss << "CANTING RIGHT: " << boresiteAngle;
		putText(g, oss.str(), Point(x+25, y+25), 1, 0.9, Scalar(0,255,0), 1, 1, false);
	}  else {
		oss.str("");
		oss << "NO CANT: " << boresiteAngle;
		putText(g, oss.str(),Point(x, y), 1, 0.9, Scalar(255,255,255), 1, 1, false);
	}// if
}