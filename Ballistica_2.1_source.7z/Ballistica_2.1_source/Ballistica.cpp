/*
 *<b>Ballistica Version 2.1 "Foe-hammer". </b><br>
 *<b>Copyright 2014 Ballistica Software Defined Scope System (SDSS)</b><br>
 *<pre>
 *   This program is free software: you can redistribute it and/or modify<br>
 *   it under the terms of the GNU General Public License as published by<br>
 *   the Free Software Foundation, either version 3 of the License, or<br>
 *   (at your option) any later version.<br>
 *   <br>
 *   This program is distributed in the hope that it will be useful,<br>
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of<br>
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the<br>
 *   GNU General Public License for more details.<br>
 *   <br>
 *   You should have received a copy of the GNU General Public License<br>
 *   along with this program.  If not, see &lt;http://www.gnu.org/licenses/&gt;.<br>
 * </pre>
 * <pre>
 *   This file is part of Ballistica.<br>
 *   <br>
 *   Ballistica is free software: you can redistribute it and/or modify<br>
 *   it under the terms of the GNU General Public License as published by<br>
 *   the Free Software Foundation, either version 3 of the License, or<br>
 *   (at your option) any later version.<br>
 *   <br>
 *   Ballistica is distributed in the hope that it will be useful,<br>
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of<br>
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the<br>
 *   GNU General Public License for more details.<br>
 *   <br>
 *   You should have received a copy of the GNU General Public License<br>
 *     along with Ballistica.  If not, see &lt;http://www.gnu.org/licenses/&gt;.<br>
 * </pre>
 * references:
    * http://opencv-srf.blogspot.com/2013/10/smooth-images.html
    * http://docs.opencv.org/modules/core/doc/operations_on_arrays.html
    * http://docs.opencv.org/doc/tutorials/imgproc/threshold/threshold.html
    * http://docs.opencv.org/modules/core/doc/operations_on_arrays.html?highlight=cvinranges#void%20cvInRangeS%28const%20CvArr%2a%20src,%20CvScalar%20lower,%20CvScalar%20upper,%20CvArr%2a%20dst%29
    * http://stackoverflow.com/questions/9018906/detect-rgb-color-interval-with-opencv-and-c
    * http://docs.opencv.org/modules/imgproc/doc/motion_analysis_and_object_tracking.html
    * http://stackoverflow.com/questions/13345772/how-to-capture-video-feed-from-java-program
    * http://www.longrangehunting.com/forums/f26/how-much-adjust-scope-shoot-500-yards-8730/
    * http://stackoverflow.com/questions/10018190/how-to-change-webcam-format-in-javacv
    * https://sites.google.com/site/todddanko/home/webcam_laser_ranger
    * http://www.eng.buffalo.edu/ubr/ff03laser.php
    * http://stackoverflow.com/questions/14287/increasing-camera-capture-resolution-in-opencv
    * https://code.google.com/p/javacv/wiki/Windows7AndOpenCV
    * http://www.longrangehunting.com/articles/canting-rifle-long-range-accuracy-1.php
    * http://www.mil-dot.com/articles/how-to-get-the-most-out-of-your-mil-dot-reticle
    * https://gist.github.com/1085940
    * http://gundata.org/blog/post/convert-fps-to-mph/
    * https://gist.github.com/1085940
    * http://stackoverflow.com/questions/8848312/preventing-native-memory-leak-by-customizing-garbage-collector
    * http://www.ibm.com/developerworks/java/library/j-nativememory-linux/
    * http://www.softwareverify.com/blog/?p=221
    * http://ganeshtiwaridotcomdotnp.blogspot.com/2012/04/colored-object-tracking-in-java-javacv.html
    * http://opencv.willowgarage.com/documentation/structural_analysis_and_shape_descriptors.html#findcontours
    * http://opencv.willowgarage.com/documentation/structural_analysis_and_shape_descriptors.html#approxpoly
    * http://stackoverflow.com/questions/10668573/find-contours-in-javacv-or-opencv
    * http://www.javaadvent.com/2012/12/hand-and-finger-detection-using-javacv.html
    * http://stackoverflow.com/questions/12106307/how-to-get-x-y-coordinates-of-extracted-objects-in-javacv
    * http://www.shervinemami.info/faceRecognition.html
    * http://opencv-srf.blogspot.com/2011/11/mouse-events.html
    * http://docs.opencv.org/modules/imgproc/doc/geometric_transformations.html#void getRectSubPix(InputArray image, Size patchSize, Point2f center, OutputArray patch, int patchType)
    * http://www.riflescopelevel.com/cant_errors.html
    * http://stackoverflow.com/questions/4839010/how-to-compare-hough-line-positions-in-opencv
    * http://stackoverflow.com/questions/21248611/opencv-assertion-failed
	* http://artoftherifleblog.com/moving-target-engagement/2011/12/moving-target-engagement.html
	* http://stackoverflow.com/questions/2494356/how-to-use-gettimeofday-or-something-equivalent-with-visual-studio-c-2008
	* http://www.oopweb.com/CPP/Documents/FunctionPointers/Volume/CCPP/FPT/em_fpt.html
	* http://docs.opencv.org/modules/video/doc/motion_analysis_and_object_tracking.html#backgroundsubtractormog2
	* http://msdn.microsoft.com/en-us/magazine/cc163717.aspx
	* https://stackoverflow.com/questions/14287/increasing-camera-capture-resolution-in-opencv
 */
#include <map>
#include <string>
#include "stdafx.h"
#include <stdio.h>
#include <stdlib.h>
#include <memory.h>
#include "Angle.h"
#include "Calibrator.h"
#include "Camera.h"
#include "Environmentalstatus.h"
#include "Projectile.h"
#include "Rangecalcs.h"
#include "Reticle.h"
#include "Targetvector.h"
#include "Threatlibrary.h"
#include "SUBTrack.h"
#include "Weaponsplatform.h"
#include "ColorTrack.h"
#include "ImageTrack.h"
#include "RangeTrack.h"
#include "GNUBallistics.h"
#include <cmath>
using namespace cv;
using namespace std;
static unsigned int MODESELECTMAX = 14;       // selector variable for the diaplay modes ranging from targeting assets to settings changes.
static unsigned int RETSELECTMAX = 4;         // Controls the displayed targeting reticle.
static unsigned int RETSELECTMIN = 0;
Mat incomingCaptureImage;	// This is used with the image grab incoming from the camera system
Mat itemplate;           	// Routinely used as the image sample for track by image
Mat matchrResult;        	// Results of the image track
Mat cvtDstImage;			// To avoid having to blur the main incoming image that's written out to and displayed.
static Reticle  			*reticle;         // Reticle handling and drawing class
static Rangecalcs 			*rc;              // Used to store a collection of range calculations to reduce overhead of calling the ballistics library
static Camera 				*camera;          // Camera handling class.
static Targetvector 		*tvector;         // Handling and drawing of the target tvectorand/or speed.
static Environmentalstatus *environmental;    // Storage and management of environmental data like wind, temp, etc
static Projectile			*projectile;      // Characteristics of the projectile maintained in this class
static Weaponsplatform 		*platform;        // Class for containment and management of platform-specific information.
static Angle				*angle;           // Angle of target from position of platform (presently not in use)
static Threatlibrary 		*threat;          // Target size library (minimal use for now
static Calibrator	 		*calibration;     // Special calibration utility used to set up the camera resolution values for Through-Calibration
static GNUBallistics		*ballistics;	  // The GNU Ballistics library converted to a C++ class for use here.
static ColorTrack           *colortrack;	  // Handles the "track by color" routines
static ImageTrack		    *imagetrack;      // Handles the "track by image snapshot" routines
static RangeTrack			*rangetrack;	  // Formerly movement tracking, this now takes contours and looks for "size by distance" comparison.
static SUBTrack				*subtrack;
// Utility fields
static int lock = 0;                        // State of the tracking system, locked and not locked.
static int halfx, halfy;                    // Hold the values that comprise dead center of the screen
static int sensitivity = 100;               // This is the used with the number of pixels "detected" after image process calls - may be camera specific
static int rangeCarretteMod = 100;          // Ranging reticle value in yards
static int rangecarrettedecay = 0;          // display decay values for these adjustment oriented reticles.
static int windretdecay = 0;
static int angleretdecay = 0;
static int tempretdecay = 0;
static int baroretdecay = 0;
static int altretdecay = 0;
static int retselectdecay = 0;
static int colorTolerancedecay = 0;
static int imagecapretdecay = 0;
static unsigned int reticleselectindex = 0;  // Reticle selection variable (though you might want to mod this to change with target, movement, etc)
static unsigned int modeselect = 0;          // The modeselect mode and what aspect to adjust
static int modupdown = 0;           		 // Modifier of up and down for the range, zero, etc.
static string modeselindication = "RANGE TRACK";       // Display string
static int targetBoxDirective = 0;  		 // Given to TargetBox constructor to determine capture box sizing determination.
static float leadInches = 0.0F;
static double distancePixels =  0.0;
static double inchesMoved = 0.0;
static double speedMPH = 0.0;
static Point p;
static double bullet_coefficient = 0.0;
static double initial_velocity = 0.0;
static double boresite_angle = 0.0;
static double range_zeroed_to = 0.0;
static double height_over_bore = 0.0;
static double pixper_inch_low = 0.0;
static double pixper_inch_high = 0.0;
static int weather = 1;                     // Toggle this variable for weather influence. 0 of off, 1 is on.
static int cal_yards_low = 0;
static int cal_yards_high = 0;
static int maxmag = 0;
static int drag_function = 0;
static int present_zoom = 0;
static int present_range = 0;
static int camera_number = 0; 
static int targetsize_inches = 0;
static int capturewidth = 0;
static int captureheight = 0;
static int displaysize_X = 0;
static int displaysize_Y = 0;
static string reticle_filename = "";
stringstream oss;		// stringstream for output
static string command = "";	// store the command line that called this program, if any commands are given of course.
void mouseCallback(int event, int x, int y, int flags, void* userdata) {
	switch (event){ // Dump unwanted events.
		case(EVENT_MOUSEMOVE):{return;}  // These Mouse actions are not used
        case(EVENT_LBUTTONUP):{return;}
        case(EVENT_RBUTTONUP):{return;}
        case(EVENT_MBUTTONUP):{return;}
	} // switch
	if ((calibration) && (!calibration->getCalCapStatus())){   // Calibration event handling block
    	switch (event){
       		case EVENT_LBUTTONDOWN:{
    			calibration->decrementCalibrationDistance();
    			break;
       		} // EVENT_MBUTTONDOWN
       		case EVENT_RBUTTONDOWN:{
       			calibration->incrementCalibrationDistance();
       			break;
    		} // EVENT_RBUTTONDOWN
    		case EVENT_MBUTTONDOWN:{
    			if (!calibration->lowCaptured()){
    				calibration->setLowPixCap();
    			} else if (!calibration->highCaptured()){
    				calibration->setHighPixCap();
    			}  // if
    			break;
    		} // EVENT_MBUTTONDOWN
    	} // switch
        return;
    } // if
    switch (event){         // Bulk of general input response is here.
    	case EVENT_MBUTTONDOWN:{
    		if(lock == 0) modeselect++;   // Go into mode select
    		if (modeselect > MODESELECTMAX)modeselect = 0;
    		break;
    	} // EVENT_MBUTTONDOWN
    	case EVENT_LBUTTONDOWN:{
    		if(modeselect==0){ // No locking in mode select.
    			if(lock==1){
    				lock = 0;  // Get out of selection mode, unlock target    				
    				return;
    			} else {					
    					colortrack = new ColorTrack(incomingCaptureImage);
    					imagetrack->setTrackingImage(incomingCaptureImage,0,0);
    				lock=1; // Not in selection mode, lock present tracked target
    				return;
    			} // if
    		} else if (modeselect > 0){  // Selection mode is on for range.
    			modupdown = -1;
    		} // if
    		break;
    	} // EVENT_LBUTTONDOWN
    	case EVENT_RBUTTONDOWN:{			
    		break;
    	} // EVENT_RBUTTONDOWN
    } // switch
    switch (modeselect){
              case(0):{ // target change mode
            	  modeselindication = "TARGETING MODE";
            	  rangecarrettedecay = -1;
            	  windretdecay = -1;
            	  angleretdecay = -1;
            	  break;
              }  //0
              case(1):{ // Range change mode
            	  modeselindication = "RANGE MOD";
            	  int nr;
            	  if(modupdown == 1)
            		  nr = rc->getCurrentRange() + 100;
            	  else if (modupdown == -1)
            		  nr = rc->getCurrentRange() - 100;
            	  else break;
            	  rc->updateTargetRange(nr);
            	  break;
              }  //1
              case(2):{ // Zero change mode
            	  modeselindication = "PLATFORM ZERO MOD";
            	  int nz;
            	  if(modupdown == 1)
            		  nz = rc->getCurrentZero() + 100;
            	  else if (modupdown==-1)
            		  nz = rc->getCurrentZero() - 100;
            	  else break;
            	  rc->updateZero(nz);
            	  break;
              }  // 2
              case(3):{   // Scope Magnification mode
            	  modeselindication = "MAGNIFICATION MOD";
            	  int nz;
            	  if(modupdown == -1)
            		  nz = rc->getCurrentZoom() - 1;
            	  else if (modupdown==1)
            		  nz = rc->getCurrentZoom() + 1;
            	  else break;
            	  if (nz > 10)nz=10;
            	  rc->updateZoom(nz);
            	  break;
              }  // 3
              case(4):{   // Lighting select (for camera lighting sensitivity
            	  modeselindication = "LIGHTING/SENSITIVITY MOD";
            	  if(modupdown ==1){
            		  rangetrack->incrementLightLevel();
            	  } else if (modupdown==-1) {
            		  rangetrack->decrementLightLevel();
            	  }  // if
            	  break;
              }  // 4
              case(5):{   // Ranging to Target
            	  modeselindication = "RANGING TO TARGET";
            	  rangecarrettedecay = 50;  // Ranging carette decays
            	  windretdecay = -1;
            	  if(modupdown == 1){
            		  rangeCarretteMod += 100;
            	  } else if (modupdown== -1) {
            		  rangeCarretteMod -= 100;
            		  if (rangeCarretteMod <= 100) rangeCarretteMod = 100;
            	  }  // if
            	  break;
              } // 5
              case(6):{
            	  modeselindication = "WIND DIRECTION ADJ";
            	  rangecarrettedecay = -1;
            	  windretdecay = 100;
            	  if(modupdown == 1){
            		  environmental->setWindDirection(environmental->getWindDirection()+90);
            		  if (environmental->getWindDirection() > 270) environmental->setWindDirection(0);
            	  } else if (modupdown == -1) {
            		  environmental->setWindDirection(environmental->getWindDirection()-90);
            		  if (environmental->getWindDirection() < 0) environmental->setWindDirection(0);
            	  }  // if
            	  break;
              }  // 6
              case(7):{
            	  modeselindication = "WIND SPEED ADJ";
            	  windretdecay = 100;  // Wind speed and direction will use the same reticle and decay
            	  double ws = environmental->getWindSpeed();
            	  if(modupdown == 1){
            		  environmental->setWindSpeed(ws+1);
            	  } else if (modupdown== -1) {
            		  environmental->setWindSpeed(ws-1);
            	  }  // if
            	  break;
              }  // 7
              case(8):{
            	  modeselindication = "CANT ANGLE ADJ";
            	  rangecarrettedecay = -1;
            	  windretdecay = -1;
            	  angleretdecay = 100;  // Wind speed and direction will use the same reticle and decay
            	  if(modupdown == 1){
            		  platform->setCantDeviation(platform->getCantDeviation()+1);
            	  } else if (modupdown== -1) {
            		  platform->setCantDeviation(platform->getCantDeviation()-1);
            	  }  // if
            	  break;
              }  // 8
              case(9):{
            	  modeselindication = "TEMPURATURE ADJ";
            	  angleretdecay = -1;
            	  tempretdecay = 100;  // Wind speed and direction will use the same reticle and decay
            	  if(modupdown == 1){
            		  environmental->setTempurature(environmental->getTempurature()+1);
            	  } else if (modupdown== -1) {
            		  environmental->setTempurature(environmental->getTempurature()-1);
            	  }  // if
            	  break;
              }  // 9
              case(10):{
            	  modeselindication = "BAROMETRIC ADJ";
            	  tempretdecay = -1;
            	  baroretdecay = 100;  // Wind speed and direction will use the same reticle and decay
            	  if(modupdown == 1){
            		  environmental->setBarometric(environmental->getBarometric()+2);
            	  } else if (modupdown== -1) {
            		  environmental->setBarometric(environmental->getBarometric()-2);
            	  }  // if
            	  break;
              }  // 10
              case(11):{
            	  modeselindication = "ALTITUDE ADJ";
            	  baroretdecay = -1;
            	  altretdecay = 100;  // Wind speed and direction will use the same reticle and decay
            	  if(modupdown == 1){
            		  environmental->setAltitude(environmental->getAltitude()+5);
            	  } else if (modupdown== -1) {
            		  environmental->setAltitude(environmental->getAltitude()-5);
            	  }  // if
            	  break;
              }  // 11
              case(12):{
            	  if(!colortrack)colortrack = new ColorTrack();
            	  modeselindication = "COLOR TOLERANCE ADJ";
            	  altretdecay = -1;
            	  colorTolerancedecay = 100;  // Wind speed and direction will use the same reticle and decay
            	  if(modupdown == 1){
            		  colortrack->modColorTrack(5, -5);
            	  } else if (modupdown== -1) {
            		  colortrack->modColorTrack(-5, 5);
            	  }  // if
            	  break;
              }  // 12
              case(13):{
            	  unsigned int uicapret;
            	  uicapret = imagetrack->getCaptureReticleSize();
            	  modeselindication = "IMAGE CAP SIZE ADJ";
            	  colorTolerancedecay = -1;
            	  imagecapretdecay = 100;  		 // Wind speed and direction will use the same reticle and decay            
            	  if(modupdown == 1){
            		  uicapret  += 5;
            	  } else if (modupdown== -1) {
            		  uicapret  -= 10;
            	  }  // if
            	  if (uicapret < 10)uicapret = 5;
            	  imagetrack->setCaptureApertureSize(uicapret);
            	  break;
              }  // 13
              case(14):{
            	  modeselindication = "RETICLE SELECT";
            	  imagecapretdecay = -1;
            	  retselectdecay = 100;  // Wind speed and direction will use the same reticle and decay            	  
            	  if(modupdown == 1){
            		  reticleselectindex++;
            	  } else if (modupdown== -1) {
            		  reticleselectindex--;
            	  }  // if
            	  if(reticleselectindex > RETSELECTMAX)reticleselectindex = 0;
            	  if(reticleselectindex < RETSELECTMIN)reticleselectindex = RETSELECTMAX;
            	  break;
              }  // 14
              default:{
            	  modeselindication = "MODE NO POSITION";
            	  break;
              } //default
    } // switch
    modupdown = 0;
}
static int modeReturnCheck (int tocheck){
    tocheck--;
    if (tocheck <= 0) {
        modeselindication = "TARGETING MODE";
        modeselect = 0;  // Reset back to targeting mode.
        return 0;
    } // if
    return tocheck;
}
static void errorOutput(int x, int y, string s){putText(incomingCaptureImage, s,Point(x, y), 1, 0.9, Scalar(0,0,255), 1, 1, false);}
static void buildCommandLine(char *param, char *value){
	command.append(param);
	command.append(" ");
	command.append(value);
	command.append(" ");
}
void drawPlatformStats(Mat& g, int range, int zero, int mag, int focus){
	Scalar color = Scalar(255,255,255);
	rectangle(g, Rect(halfx-25, halfy-20, 250, 50),color, 1, 1, 0);
	stringstream oss;
	oss << "RANGE " << range << " ZERO " << zero << " MAG "<< mag;
	putText(g, oss.str(),Point(halfx, halfy), 1, 0.9, color, 1, 1, false);
	color = Scalar(0,0,255);
	switch (focus){
	   case(1):{ // Range change mode
		   rectangle(g, Rect(halfx-20, halfy-15, 50, 20),color, 1, 1, 0);
		   break;
	   }  //1
	   case(2):{ // Zero change mode
		   rectangle(g, Rect(halfx+68, halfy-15, 37, 20),color, 1, 1, 0);
		   break;
	   }  // 2
	   case(3):{ // Mag change mode
		   rectangle(g, Rect(halfx+143, halfy-15, 32, 20),color, 1, 1, 0);
		   break;
	   }  // 2
	}	// switch
}
//------------------ 
// These local functions are for calling into member functions.
// C++ compilers will not allow a pointer to a member function to be assigned into another object. 
// Calling them from here then providing pointers to them also allows some modification
// The main user of pointers to these calls will be the Reticle class, which uses a generic "node" 
// of data making a call to a double-returning function where a statistic is called for
double getCurrentRange(){return (double)rc->getCurrentRange();}  
double getCurrentZoom(){return (double)rc->getCurrentZoom();}
double getCurrentZero(){return (double)rc->getCurrentZero();}
double getWindage(){return (-1 *(rc->getReticleDisplacementWNDAtRange() + platform->getCantDeviationHorizontil(rc->getReticleDisplacementWNDAtRange())) + floor(leadInches + 0.5));} 
double getBDC(){return (rc->getBDCPathAtRange() + platform->getCantDeviationVertical(rc->getReticleDisplacementsBDCAtRange()));}
double getVelocity(){return rc->getVelocityAtRange();}
double getTimeToTarget(){return rc->getTimeAtRange();}
double getTargetSpeed(){return tvector->getSpeed(inchesMoved);}
double getLeadInches(){return tvector->getLeadInchesPerSecond(rc->getTimeAtRange());}
double getLeadFeet(){return tvector->getLeadFeetPerSecond(rc->getTimeAtRange());}
double getTargetAngle(){return angle->getTargetAngle(rc->getCurrentRange());}
double getTargetHeight(){return angle->getTargetHeight(0,0.0f,0.0f);} // call to stub for now
double getAltitude(){return environmental->getAltitude();}
double getBarometric(){return environmental->getBarometric();}
double getTempurature(){return environmental->getTempurature();}
double getWindSpeed(){return environmental->getWindSpeed();}
double getWindDirection(){return environmental->getWindDirection();}
double getRelativeHumidity(){return environmental->getRelativeHumidity();}
double getCantDeviation(){return platform->getCantDeviation();}
double getCantDeviationHorizontil(){return platform->getCantDeviationHorizontil(rc->getReticleDisplacementWNDAtRange());}
double getCantDeviationVertical(){return platform->getCantDeviationVertical(rc->getReticleDisplacementsBDCAtRange());}
double getCameraRangePixels(double targetInchSpan, double targetBoxHeight){return camera->getRangeFromPixelSpan(targetInchSpan, targetBoxHeight);}
int    getThreatHeight(){return threat->getTargetInchSpan();}
// These functions are for parsing the command line parameters passed to a call that invokes this program.
// Each parameter gets it's own char* to int/double/string function because it gives an opportunity
// to handle them individually as needs develop later on.
//doubles
double getCoefficient(const char *c) {
	bullet_coefficient  = (atof(c) > 0) ? atof(c) : 0;
	return atof(c);
}
double getInitialVelocity(const char *c) {
	initial_velocity  = (atof(c) > 0) ? atof(c) : 0;
	return atof(c);
}
double getBoresiteAngle(const char *c) {
	boresite_angle  = (atof(c) > 0) ? atof(c) : 0;
	return atof(c);
}
double getRangeZeroedTo(const char *c) {
	range_zeroed_to  = (atof(c) > 0) ? atof(c) : 100.0;
	return atof(c);
}
double getHeightOverBore(const char *c) {
	height_over_bore  = (atof(c) > 0) ? atof(c) : 0;
	return atof(c);
}
double getPixelsPerInchZoomLOW(const char *c) {
	pixper_inch_low  = (atof(c) > 0) ? atof(c) : 0;
	return atof(c);
}
double getPixelsPerInchZoomHIGH(const char *c) {
	pixper_inch_high  = (atof(c) > 0) ? atof(c) : 0;
	return atof(c);
}
// ints
int getRange(char *c) {
	present_range  = (atoi(c) > 0) ? atoi(c) : 0;
	return atoi(c);
}
int getZoom(char *c) {
	present_zoom  = (atoi(c) > 0) ? atoi(c) : 1;
	return atoi(c);
}
int getDragFunction(char *c) {
	drag_function  = ((atoi(c) > 0) || (atoi(c) < 7))? atoi(c) : 1;
	return atoi(c);
}
int getMaxMagnication(char *c) {
	maxmag  = (atoi(c) > 0) ? atoi(c) : 1;
	return atoi(c);
}
int getCalibrationYardageLOW(char *c) {
	cal_yards_low  = (atoi(c) > 0) ? atoi(c) : 0;
	return atoi(c);
} // for "low" yard calibration or general use when one calibration yardage value is used.
int getCalibrationYardageHIGH(char *c) {	// Not yet in use, nor is this parameter in the Camera class constructor in use
	cal_yards_high  = (atoi(c) > 0) ? atoi(c) : 0;
	return atoi(c);
}  
int getWeatherActivation(char *c) {	
	weather  = (atoi(c) > 0) ? 1 : 0;  // basically a "switch" variable.
	return atoi(c);
}
int getCameraNumber(char *c){
	camera_number  = (atoi(c) > 0) ? atoi(c) : -1;
	return atoi(c);
}
int getTargetSizeInches(char *c){
	targetsize_inches  = (atoi(c) > 0) ? atoi(c) : 0;
	return atoi(c);
}
int getCamCaptureX(char *c){
	capturewidth  = (atoi(c) > 0) ? atoi(c) : 0;
	return atoi(c);
}
int getCamCaptureY(char *c){
	captureheight  = (atoi(c) > 0) ? atoi(c) : 0;
	return atoi(c);
}
int getDisplaySizeX(char *c){
	displaysize_X  = (atoi(c) > 0) ? atoi(c) : 0;
	return atoi(c);
}
int getDisplaySizeY(char *c){
	displaysize_Y  = (atoi(c) > 0) ? atoi(c) : 0;
	return atoi(c);
}
// strings
string getReticleFilePathName(char *c) {
	reticle_filename.assign(c);
	return string(c);
}
// Specialized
int main(int argc, char* argv[]){
	command.append(argv[0]);
	{   // Start of Construction Block --------------------------------------------------------------------
		// The function maps are not needed beyond their assignment into the reticle class that uses them,
		// or from the parsing routines for assigning values if given.
		// These are function pointers referenced by the function map name. Driving parameter names		
		typedef double (*FnPtrCH_DBL)(const char* s);  // Function pointer for function that takes char* and returns double
		std::map<std::string, FnPtrCH_DBL> fuMapWCH_DBL;
		fuMapWCH_DBL["--coefficient"] = getCoefficient;		
		fuMapWCH_DBL["--initial-velocity"] = getInitialVelocity;	
		fuMapWCH_DBL["--boresite-angle"] = getBoresiteAngle;
		fuMapWCH_DBL["--zeroed-range"] = getRangeZeroedTo;
		fuMapWCH_DBL["--height-over-bore"] = getHeightOverBore;
		fuMapWCH_DBL["--pix-per-inch-low"] = getPixelsPerInchZoomLOW;
		fuMapWCH_DBL["--pix-per-inch-high"] = getPixelsPerInchZoomHIGH;
		// Integer parsing functions map
		typedef int (*FnPtrCH_INT)(char* s);  // Function pointer for function that takes char* and returns double
		std::map<std::string, FnPtrCH_INT> fuMapWCH_INT;	
		fuMapWCH_INT["--current-range"]= getRange;
		fuMapWCH_INT["--current-zoom"]= getZoom;
		fuMapWCH_INT["--drag-function"]= getDragFunction;
		fuMapWCH_INT["--max-magnification"]= getMaxMagnication;
		fuMapWCH_INT["--calibration-yards-low"]= getCalibrationYardageLOW;
		fuMapWCH_INT["--calibration-yards-high"]= getCalibrationYardageHIGH;
		fuMapWCH_INT["--weather"]= getWeatherActivation;
		fuMapWCH_INT["--camera-number"]= getCameraNumber;
		fuMapWCH_INT["--target-size"]=getTargetSizeInches;
		fuMapWCH_INT["--camera-capture-size-x"]=getCamCaptureX;
		fuMapWCH_INT["--camera-capture-size-y"]=getCamCaptureY;
		fuMapWCH_INT["--display-size-x"]=getDisplaySizeX;
		fuMapWCH_INT["--display-size-y"]=getDisplaySizeY;
		// String parsing
		typedef string (*FnPtrCH_STR)(char* s);  // Function pointer for function that takes char* and returns double
		std::map<std::string, FnPtrCH_STR> fuMapWCH_STR;
		fuMapWCH_STR["--reticle-file"]= getReticleFilePathName;
			// Loop through, catching the parameter name as it goes, assigning variables in the run.
		for (int i = 1; i < argc; ++i) { 		
			if(fuMapWCH_DBL[string(argv[i])] != NULL){  // double-fetching function
				if (i + 1 < argc) { // Make sure we aren't at the end of argv!
					buildCommandLine(argv[i], argv[i+1]);
					fuMapWCH_DBL[string(argv[i])](argv[i++]);					
				} // if
				continue;
			} // if
			if(fuMapWCH_INT[string(argv[i])] != NULL){  // int-fetching function
				if (i + 1 < argc) { // Make sure we aren't at the end of argv!
					buildCommandLine(argv[i], argv[i+1]);
					fuMapWCH_INT[string(argv[i])](argv[i++]);
				} // if
				continue;
			} // if
			if(fuMapWCH_STR[string(argv[i])] != NULL){  // int-fetching function
				if (i + 1 < argc) { // Make sure we aren't at the end of argv!
					buildCommandLine(argv[i], argv[i+1]);
					fuMapWCH_STR[string(argv[i])](argv[i++]);
				} // if
				continue;
			} // if
		} // for
		rc = new Rangecalcs(present_range,  present_zoom, range_zeroed_to);  
		projectile = new Projectile(bullet_coefficient, initial_velocity, drag_function);//ballistics->G1); 
		platform = new Weaponsplatform(boresite_angle,rc->getCurrentZero(), maxmag, height_over_bore);   		
		// Build function map here and pass it to Reticle construction where it will take 
		// the right nodes that it needs.  The rest will not be used.
		typedef double (*FnPtr)();
		std::map<std::string, FnPtr> utilityFunctMAP;
		utilityFunctMAP["windage"]		= getWindage;
		utilityFunctMAP["elevation"]	= getBDC;
		utilityFunctMAP["range"]		= getCurrentRange;  
		utilityFunctMAP["zoom"]		= getCurrentZoom;
		utilityFunctMAP["zero"]		= getCurrentZero;
		utilityFunctMAP["velocity"]	= getVelocity;
		utilityFunctMAP["TTT"]			= getTimeToTarget;
		utilityFunctMAP["TSpeed"]		= getTargetSpeed;
		utilityFunctMAP["leadINCH"]	= getLeadInches;
		utilityFunctMAP["leadFT"]		= getLeadFeet;
		utilityFunctMAP["angle"]		= getTargetAngle;
		utilityFunctMAP["height"]		= getTargetHeight;
		utilityFunctMAP["alt"]			= getAltitude;
		utilityFunctMAP["baro"]		= getBarometric;
		utilityFunctMAP["temp"]		= getTempurature;
		utilityFunctMAP["windspeed"]	= getWindSpeed;
		utilityFunctMAP["winddirection"] = getWindDirection;
		utilityFunctMAP["humidity"]	= getRelativeHumidity;
		utilityFunctMAP["cant"]		= getCantDeviation;
		utilityFunctMAP["cantHZL"]		= getCantDeviationHorizontil;
		utilityFunctMAP["cantVTL"]		= getCantDeviationVertical;
		if(reticle_filename.empty()){ // Hopefully the right name was given
			// default reticle call on at least windage and elevation routines by function pointer?
			printf("No reticle file given. Using default\n");
			reticle = new Reticle(incomingCaptureImage.size().width, incomingCaptureImage.size().height, utilityFunctMAP);
		} else { // A file name for the reticle is given, but was the name OK?
			if (FILE *file = fopen(reticle_filename.c_str(), "r")) {
				fclose(file);
				reticle = new Reticle(incomingCaptureImage.size().width, incomingCaptureImage.size().height, utilityFunctMAP, reticle_filename);
			} // if 			
		} // if				
	}  // End of Construction Block
    Mat iprev;  // for general "work".
    Mat idiff;
    Mat igray;		        
    environmental = new Environmentalstatus();        
    angle = new Angle();
    rangetrack = new RangeTrack();	
    threat = new Threatlibrary(targetsize_inches);
    rangetrack->setDefaultLighting();
    colortrack = new ColorTrack();
    imagetrack = new ImageTrack();
    CvCapture* capture;
    capture = cvCaptureFromCAM( camera_number );	
    if (capture == NULL) {			
        printf("Failed cvCreateCameraCapture\n");
        return 0;  // Really no point in going on if the camera system is offline
    } // if
	// Note: the camera system used usually "locks" to values like 320x240, 640x480 and 1280x960 and this has a very 
	// signficant effect on through calibration and resolution and larger capture can slow things down a bit too.
	if((capturewidth > 0) && (captureheight > 0)) {  
		cvSetCaptureProperty( capture, CV_CAP_PROP_FRAME_WIDTH,  capturewidth );
		cvSetCaptureProperty( capture, CV_CAP_PROP_FRAME_HEIGHT, captureheight );
		// a default 640 by 480 will be used if these are not called but some systems might vary
	}  // if	
	if ((displaysize_X > 0) && (displaysize_Y > 0)){
		namedWindow("Ballistica", 0);  // this can make the window resizable to the screen:  , WINDOW_NORMAL);   or lock to the image size: WINDOW_AUTOSIZE
		resizeWindow("Ballistica", displaysize_X, displaysize_Y);
	} else {
		 namedWindow("Ballistica", WINDOW_NORMAL); //  or lock to the image size: WINDOW_AUTOSIZE
	} // if
    cvSetMouseCallback("Ballistica", mouseCallback, NULL);
    incomingCaptureImage.data = NULL;
    int keyEvent;
    incomingCaptureImage = cvQueryFrame(capture); // needed for image statistics for these classes.
	if (!tvector)tvector= new Targetvector(incomingCaptureImage.size().width/2, incomingCaptureImage.size().width/2);
    while (true) {  // This is an infinite loop but ESC via keypress will terminate this.
        incomingCaptureImage = cvQueryFrame(capture);
        if (!incomingCaptureImage.data){//== NULL) {
            printf("Failed cvQueryFrame");
            break; // Capture failure, break out of infinite grabbing loop - return might leave behind a running process.
        } // if		
		if (!camera) {   // Camera is not calibrated, check and see if the data used to contruct it was not provided at launch.
			if((cal_yards_low != 0)/* && (cal_yards_high != 0)*/ && (pixper_inch_low > 0) && (pixper_inch_high > 0)){
				camera = new Camera(pixper_inch_low, pixper_inch_high, rc->getCurrentZoom(), platform->maxmag, cal_yards_low);				
				subtrack = new SUBTrack(&getCameraRangePixels, threat->getTargetInchSpan());  // Set up with member pointer (not directly to member - not allowed).
			} else {  // Camera construction data not given, therefore run the calibration to get through-calibration data.			
            	if (!calibration)calibration = new Calibrator();
				calibration->displayThroughCalibrationCapture(incomingCaptureImage);
				if (calibration->getCalCapStatus()){ // Through-Calibration is ready...
					// Refresher: Assuming 1" calibration square. Low pixels is 1" square at low mag, high pixels is 1" square at high mag, yardage is constant
					// There is an untested 2-yardage constructor for Camera class to overcome near/farsightedness			
					camera = new Camera(calibration->getLowPixelCal(), calibration->getHighPixelCal(), rc->getCurrentZoom(), platform->maxmag, calibration->getCalibrationYardage());
					subtrack = new SUBTrack(&getCameraRangePixels, threat->getTargetInchSpan());  // Set up with member pointer (not directly to member - not allowed).
					calibration = NULL;    // Calibration work complete, assume regular image processing.
				} // if
			}  // if
        } else {    // Main line image processing routines.
			if(((rangetrack->locked())  ||
			    (subtrack->locked())    ||
			    (imagetrack->locked())  || 
			    (colortrack->locked())) &&  (lock > 0)) {  // Targeting box active, narrow search.
                try {
					distancePixels = 0.0;                  
					#pragma omp parallel sections shared(lock) //private(newimg2) private(newimg1)     
					{
						#pragma omp section 
						{  // Background Subtraction
			// Subtraction tracking. This is the first stop and the sub box should not have a lot of trouble handling this. 
			// The locked mode is more like the range tracking routine
							if((subtrack->checkROIBoundaries(incomingCaptureImage.size().width, incomingCaptureImage.size().height)) && (subtrack->checkSensitivityThreshold())){
								Mat roi(incomingCaptureImage, Rect(subtrack->subboxbrect.x-(int)(subtrack->subboxbrect.width/2), subtrack->subboxbrect.y-(int)(subtrack->subboxbrect.height/2), subtrack->subboxbrect.height, subtrack->subboxbrect.width));
									subtrack->subbox = roi.clone();
									subtrack->applyCOGDisplacement(subtrack->processSUBTracking((int)(camera->getPixelsFromInchSpan(rc->getCurrentRange(), threat->getTargetInchSpan()))));
									if(subtrack->locked()){ 												
										subtrack->drawTargetBox(incomingCaptureImage); 
//										distancePixels =  tvector->getCOGDistance(rangetrack->screenReferenceCOG);   // From one COG to another
									} else {
										// Lock dropped off, do nothing, there is a chance to get this back down the chain
									} //if			
								} else {
									errorOutput(subtrack->screenReferenceCOG.x, subtrack->screenReferenceCOG.x, "SUB TRACK OOB");									
								}  // if
						}  // RANGE
						#pragma omp section
						{ // RANGE
			// Range tracking uses contour detection and then filters out the object per the size. In locked mode, much is filtered out to ensure accurate tracking.
			// If range tracking falls off, and background subtraction tracking was successful, then range tracking will pull the updated COG rectangle and update itself
			// to maintain its lock status.
			// If both the background subtraction tracking and the range tracking were successful in this block, then the color tracking class is updated with 
			// the sub box image of the range tracking class. Color of an item might change with it's position and therefore an update keeps the color tracking 
			// on target. Color tracking is sensitive to movement and lighting, hue, and shadow changes but can maintain a lock on a stationary target.
								if((rangetrack->checkROIBoundaries(incomingCaptureImage.size().width, incomingCaptureImage.size().height)) && (rangetrack->checkSensitivityThreshold())){
									//Mat roi(incomingCaptureImage, Rect(targetbox->sbrect.x-(int)(targetbox->sbrect.width/2), targetbox->sbrect.y-(int)(targetbox->sbrect.height/2), targetbox->sbrect.height, targetbox->sbrect.width));
									Mat roi(incomingCaptureImage, Rect(rangetrack->subboxbrect.x-(int)(rangetrack->subboxbrect.width/2), rangetrack->subboxbrect.y-(int)(rangetrack->subboxbrect.height/2), rangetrack->subboxbrect.height, rangetrack->subboxbrect.width));
									rangetrack->subbox = roi.clone();
									rangetrack->applyCOGDisplacement(rangetrack->processRangeTracking((int)(camera->getPixelsFromInchSpan(rc->getCurrentRange(), threat->getTargetInchSpan()))));
									if(rangetrack->locked()){										
										rangetrack->drawTargetBox(incomingCaptureImage); 										
									} else {
										// nothing
									} //if									
								} else {
									errorOutput(rangetrack->screenReferenceCOG.x, rangetrack->screenReferenceCOG.x, "RANGE TRACK OOB");									
								}  // if
							//	break;						
						}  // RANGE
						#pragma omp section
						{  // COLOR
			// Color track will attempt to center on the color and if it's found that the resulting center of the result is not on par with background subtraction and range
			// tracking, it will presume it fell off the map so to speak (though unlikely if it was just updated) and become unlocked. Note the checking done in the previous block.
			// If range and background subtraction have failed also, then color tracking will remain offline.
								if((colortrack->checkROIBoundaries(incomingCaptureImage.size().width, incomingCaptureImage.size().height) && (colortrack->checkSensitivityThreshold()))) {	// Make sure it's not null lest this crash it
									Mat roi(incomingCaptureImage, Rect(colortrack->subboxbrect.x-(int)(colortrack->subboxbrect.width/2), colortrack->subboxbrect.y-(int)(colortrack->subboxbrect.height/2), colortrack->subboxbrect.height, colortrack->subboxbrect.width));
									colortrack->subbox = roi.clone();
									colortrack->applyCOGDisplacement(colortrack->processColorTracking());
									if(colortrack->locked()){  
										colortrack->drawTargetBox(incomingCaptureImage);
										distancePixels =  tvector->getCOGDistance(rangetrack->screenReferenceCOG);   // From one COG to another
									} //if									
								} else {
									errorOutput(colortrack->screenReferenceCOG.x, colortrack->screenReferenceCOG.x, "COLOR TRACK OOB");
								} // if
							//	break;							
						} // COLOR
						#pragma omp section
						{	//	IMAGE 
			// Image tracking is by far the most sensitive to failure. Image tracking attempts to maintain a copy of the locked image and then find that image in the incoming
			// image stream. Some slight movement of the target is possible, but not by a wide margin. There is a bit of a compromise to how loose the tolerance can be 
			// versus to accurate the tracking will be. Even more complex is that the sub box needs to be a little bigger while the incoming image to search needs to be a little smaller.						
			//	The Image handling class will attempt to find the target. 
			//	If it fails, it will query both SUB and RANGE to see if they are locked and if they are locked, see if their COG/RECTS match. 
			//	If they match, it will update it's image. 
			//	If not, it will check color.
			//	If color has dropped off, the IMAGE will also drop off. Otherwise it will set a new image from Color
			//	If IMAGE was initially successful, then it will compare with SUB and RANGE and if they are very close (narrow margin) it will update from the one that was closer
			//  was closest to the successful scan for the image.
								if(imagetrack->checkROIBoundaries(incomingCaptureImage.size().width, incomingCaptureImage.size().height)){	// Make sure it's not null lest this crash the program
									Mat roi(incomingCaptureImage, Rect(imagetrack->subboxbrect.x-(int)(imagetrack->subboxbrect.width/2), imagetrack->subboxbrect.y-(int)(imagetrack->subboxbrect.height/2), imagetrack->subboxbrect.height, imagetrack->subboxbrect.width));
									imagetrack->subbox = roi.clone();
									imagetrack->applyCOGDisplacement(imagetrack->processImageTracking());
									if(imagetrack->locked()){
										imagetrack->drawTargetBox(incomingCaptureImage);
									} else {
									} //if
								} else {
									errorOutput(imagetrack->screenReferenceCOG.x, imagetrack->screenReferenceCOG.x, "IMAGE TRACK OOB");
									lock = 0;	// Image tracking lags when lock breaks and it goes searching, so shut lock off.
								} // if							
						} // IMAGE
					} // omp parallel sections 
					// Here is where the tracking objects back each other up. The logic here is tricky. (Penn and Teller level)
					if(subtrack->locked()){ 																								
						distancePixels =  tvector->getCOGDistance(subtrack->screenReferenceCOG);   // From one COG to another
					} // if	
					if(rangetrack->locked()){																
						distancePixels =  tvector->getCOGDistance(rangetrack->screenReferenceCOG);   // From one COG to another
						if(subtrack->locked()){  // if range and subtraction tracking both maintained lock, then update the color tracking with a new color.
							colortrack = new ColorTrack(subtrack->subbox);	// Set new color to track																		
						} else {						
							subtrack->setTargetBox(rangetrack->getCurrentRectangle());  // Backup the background subtraction system that fell off							
						} // if
					} else {
						if(subtrack->locked())rangetrack->setTargetBox(subtrack->getCurrentRectangle());  // Subtraction system restoring range tracking system
					} //if					
					if(imagetrack->locked()){						
						distancePixels =  tvector->getCOGDistance(rangetrack->screenReferenceCOG);   // From one COG to another
						if(subtrack->locked() && rangetrack->locked())imagetrack->compareAssignRect(subtrack->getCurrentRectangle(), rangetrack->getCurrentRectangle());
					} else {
						if(subtrack->locked() && rangetrack->locked()){											
							if (subtrack->getCurrentRectangle() == rangetrack->getCurrentRectangle()){
								imagetrack->setTrackingImage(rangetrack->subbox, 0, 0);
							} else if (colortrack->locked()) {
								imagetrack->setTrackingImage(colortrack->subbox, 0,0);
							} // if
						} // if
					} //if
					if (distancePixels > 0) {   // must have gotten set somewhere.
						inchesMoved = camera->getInchesFromPixelSpan(rc->getCurrentRange(), distancePixels);
						speedMPH = tvector->getSpeed(inchesMoved);
						leadInches = tvector->getLeadInchesPerSecond(rc->getTimeAtRange());
					} else {   //  it would appear that nothing is moving - and hopefully the platform is not
						inchesMoved = 0;
						speedMPH = 0;
						leadInches = 0; 
					} // if
                } catch (Exception* e){
                    errorOutput(10, 110, "CVEXC LOCK DROP");
                    //targetbox =  NULL;         // lock can be assumed to have fallen off and cannot get up.
              
                    sensitivity = 100;
                    leadInches = 0.0f;                  
					lock = 0; // Drop off lock as wide scan image search lags considerably.					
                } // try            
			// This is only drawn under lock.
			switch (reticleselectindex){
					case 0 :{
						// deb100 draw the programmed reticle here.
						reticle->drawMainReticle(incomingCaptureImage);
						break;
					} // 0				
					case 1 :{						
						reticle->drawReticleCenterReference(incomingCaptureImage);
						break;
					} // 0	
					case 2 :{  // calibration square
						int pixinch = (int)camera->getPixelsFromInchSpan(rc->getCurrentRange(), threat->getTargetInchSpan());
						reticle->drawCalibrationSquare(
								incomingCaptureImage,
								halfx,
								halfy,
								pixinch);							
						oss.str("");
						oss << "CALIBRATION:  HGT INCHES " <<  threat->getTargetInchSpan() << " AT RANGE " << rc->getCurrentRange();
						putText(incomingCaptureImage, oss.str(), Point(halfx-(int)(pixinch/2), halfy-(int)(pixinch/2)), 1, 0.9, Scalar(0,0,255), 1, 1, false);
						break;
					} // 2				
					case 3 :{  // Traversal reticle
						if (rangetrack->locked()){
							reticle->drawTraversalReticle(incomingCaptureImage, rangetrack->screenReferenceCOG.x, rangetrack->screenReferenceCOG.y, speedMPH);							
						} else if (subtrack->locked()){
							reticle->drawTraversalReticle(incomingCaptureImage, subtrack->screenReferenceCOG.x, subtrack->screenReferenceCOG.y, speedMPH);							
						} else if (colortrack->locked()){
							reticle->drawTraversalReticle(incomingCaptureImage, colortrack->screenReferenceCOG.x, colortrack->screenReferenceCOG.y, speedMPH);							
						} else if (imagetrack->locked()){
							reticle->drawTraversalReticle(incomingCaptureImage, imagetrack->screenReferenceCOG.x, imagetrack->screenReferenceCOG.y, speedMPH);							
						}// if						
						oss.str("");
						oss << "TRAVERSAL";
						putText(incomingCaptureImage, oss.str(),Point(2, incomingCaptureImage.size().height-10), 1, 0.7, Scalar(255,255,255), 1, 1, false);
						break;
					} // 3
					default :{  // Nothing
						putText(incomingCaptureImage,"RET NO POSITION", Point(halfx, halfy), 1, 0.9, Scalar(0,0,255), 1, 1, true);
						break;
					} // default
				} // switch
			} else {  // in this case lock is not established and the entire camera capture image is used.
               try {			    
					// First order is to check and see if any utility indications are needed, then go onto the wide are image processing.
					if (modeselect > 0){  // Additional auxiliary display options.
						switch (modeselect){
							case(0):{ // target change mode
								break;
							}  //0
							case(1):{ // Range change mode
                    			drawPlatformStats(incomingCaptureImage, rc->getCurrentRange(), rc->getCurrentZero(), rc->getCurrentZoom(), modeselect);
								break;
							}  //1
							case(2):{ // Zero change mode
                    			drawPlatformStats(incomingCaptureImage, rc->getCurrentRange(), rc->getCurrentZero(), rc->getCurrentZoom(), modeselect);
								break;
							}  // 2
							case(3):{   // Scope Magnification mode
								drawPlatformStats(incomingCaptureImage, rc->getCurrentRange(), rc->getCurrentZero(), rc->getCurrentZoom(), modeselect);
								break;
							}  // 3
							case(4):{   // Lighting select (for camera lighting sensitivity
								modeselindication = "LIGHTING/SENSITIVITY MOD";
								rangetrack->drawLightSettingSymbol(incomingCaptureImage, halfx, halfy);
								break;
							}  // 4
							default:{
								break;
							} //default
						}  // switch
					} else if (rangecarrettedecay > 0) {
						reticle->drawRangingCarrette(incomingCaptureImage, halfx-1, halfy, (int)camera->getPixelsFromInchSpan(rangeCarretteMod, threat->getTargetInchSpan()),rangeCarretteMod);
						rangecarrettedecay = modeReturnCheck(rangecarrettedecay);
					} else if (windretdecay > 0){
						environmental->drawWindDirection(incomingCaptureImage, halfx, halfy);
						windretdecay = modeReturnCheck(windretdecay);
					} else if (angleretdecay > 0){
						platform->drawCantIndication(incomingCaptureImage, halfx, halfy);
						angleretdecay = modeReturnCheck(angleretdecay);
					} else if (tempretdecay > 0){                    
						environmental->drawTempuratureIndication(incomingCaptureImage, halfx, halfy);
						tempretdecay = modeReturnCheck(tempretdecay);
					} else if (baroretdecay > 0){             
						environmental->drawBarometricIndication(incomingCaptureImage, halfx, halfy);
						baroretdecay = modeReturnCheck(baroretdecay);
					} else if (altretdecay > 0){					
						environmental->drawAltitudeIndication(incomingCaptureImage, halfx, halfy);
						altretdecay = modeReturnCheck(altretdecay);
					} else if (colorTolerancedecay > 0){                
						colortrack->drawColorTolerance(incomingCaptureImage, halfx, halfy);                						
						colorTolerancedecay = modeReturnCheck(colorTolerancedecay);
					} else if (retselectdecay > 0) {
						retselectdecay = modeReturnCheck(retselectdecay);
					} else {			
						Point p;
						halfx = incomingCaptureImage.size().width/2;  // Unlikely that screen size changes, but it can so keep it here
						halfy = incomingCaptureImage.size().height/2;
						
						#pragma omp parallel shared(p) shared(subtrack) shared(rangetrack) shared(colortrack) shared(imagetrack)
						{						
							#pragma omp single nowait // no wait might be a bad idea here
							{ // SUBMOG2-------------------------------------------------------------------------------------
                           			//targetBoxDirective = 2;
									if(subtrack){ 
										subtrack->processSUBTracking(incomingCaptureImage);  // "wide area multi-boxing".
									} else {
                            			errorOutput(halfx, halfy, "MOG2 TRACK OFFLINE");
									} // if					 
							 } // SUBMOG2		
							#pragma omp single
							 { // range-------------------------------------------------------------------------------------
                           			//targetBoxDirective = 2;
									if(rangetrack){ // this block will box targets per the current "set range" of the platform.
                            			p = rangetrack->processRangeTracking(incomingCaptureImage,(int)(camera->getPixelsFromInchSpan(rc->getCurrentRange(),threat->getTargetInchSpan())));
                            			if((p.x > 0)&&(p.y > 0)) {  // Point comes back 0s if nothing happened								
											reticle->drawReticleTrackingRect(incomingCaptureImage, p.x, p.y, "RNG", 0);   // Basic non-lock tracking reticle draw, why Point is extracted
											if(lock > 0){  // attain target lock for this mode										
												rangetrack->setTargetBox(p.x, p.y);		
												subtrack->setTargetBox(p.x, p.y);  // slave in target box setting for background subtraction class
											} // if																			
										} // if
									} else {
                            			errorOutput(halfx, halfy, "RANGE TRACK OFFLINE");  
									} // if					 							
							 } // range			
							 #pragma omp single
							 { // color-------------------------------------------------------------------------------------							
							   // "Lock" in the color sense means that a color is being sought after and a lock on a set color reestablished as it may have already been set
							   // So generally, there is no attempt at tracking a color if there is no lock condition.	
									if(lock > 0){  // Color tracking is only active when lock is active.
										if(colortrack){										
											p = colortrack->processColorTracking(incomingCaptureImage);
											if((p.x > 0)&&(p.y > 0)) {  // Point comes back 0s if nothing happened								
													reticle->drawReticleTrackingRect(incomingCaptureImage, p.x, p.y, "COL", 10);   // Basic non-lock tracking reticle draw, why Point is extracted								
												if(lock > 0){  // attain target lock for this mode										
													colortrack->setTargetBox(p.x, p.y);										
												} // if																			
											} // if
										} else {
											errorOutput(halfx, halfy, "COLOR TRACK OFFLINE");
										} // if									
									} // if							
							 } // color  							 
							 #pragma omp single							
							 { //  image-------------------------------------------------------------------------------------														
									if(lock > 0){ // Image tracking can fall off a lot, so here an opportunity is taken to try to get that image back in the wide scan
										if(imagetrack){
											p = imagetrack->processImageTracking(incomingCaptureImage);
											if((p.x > 0)&&(p.y > 0)) {  // Point comes back 0s if nothing happened								
												reticle->drawReticleTrackingRect(incomingCaptureImage, p.x, p.y, "IMG", 20);   // Basic non-lock tracking reticle draw, why Point is extracted																				
												if(lock > 0){  // attain target lock for this mode								
													imagetrack->setTargetBox(p.x, p.y);										
												} // if																																											
											}  // if
										} else {
											errorOutput(halfx, halfy, "IMAGE TRACK OFFLINE");
										} // if
										sensitivity = 0 ;   // results of an image track result is likely to be very small.
									} // if
							} //  image								
						}  // pragma omp						
					}   // if												 
                } catch (Exception* e){
                    errorOutput(halfx, halfy, "CV ERROR TRAP LOCK LOSS");
                }// Exceptions are unlikely but sometimes it will get picky with inputs and throw a transient error.
				
            } // if						
            // Changes to environmental and platform trigger the processing intensive ballistics calculations. Even an 8 processor system will lag on this if called in every loop.
			#pragma omp parallel    
			{
				if((weather > 0 && environmental->isChanged()) || (rc->isNeedingNewSolution()) || (rc->getCurrentZoom() != camera->getMAG())) {// Weather or range has changed.
					platform->rangeZero = rc->getCurrentZero();
					camera->setMAG(rc->getCurrentZoom());
					int* currentRanges = rc->generateRanges();
					int maxelements = rc->getRangeElementsCount();
					double ballisticsCoeff = ballistics->AtmCorrect(projectile->ballisticsCoefficient, environmental->getAltitude(), environmental->getBarometric(), environmental->getTempurature(),environmental->getRelativeHumidity());
					double zeroangle = ballistics->ZeroAngle(ballistics->G1, ballisticsCoeff, projectile->initialVelocity, platform->heightOverBore, platform->rangeZero, 0);
					double *firingsolution;	// pointer for holding the firing solution.
					int k = ballistics->SolveAll(projectile->dragFunction,			// from the enumeration __DragFunctions
                   									ballisticsCoeff,				// Calculated from environmental stats and ballistics coefficient
                   									projectile->initialVelocity,	// Velocity of the projectile
                   									platform->heightOverBore,
                   									angle->getTargetAngle(rc->getCurrentRange()),
                   									zeroangle,
                   									environmental->getWindSpeed(),
                   									environmental->getWindDirection(),
                   									&firingsolution);
					#pragma omp parallel for
					for (int incr = 0; incr < maxelements; incr++) {
						double path = ballistics->GetPath(firingsolution,currentRanges[incr]);
						double reticleDispBDCIncr = camera->getReticleDisplacement(currentRanges[incr], path);
						double time = ballistics->GetTime(firingsolution, currentRanges[incr]);
						double velocity = ballistics->GetVelocity(firingsolution,currentRanges[incr]);
						double windage = ballistics->GetWindage(firingsolution,currentRanges[incr]);
						double reticleDispWND = camera->getReticleDisplacement(currentRanges[incr], windage);
						rc->pushNewStats(currentRanges[incr], path, reticleDispBDCIncr, time, velocity, windage, reticleDispWND);
					}  //for
					rc->notifySetUpdate();       // Without this, the loop will update EVERY TIME and things will get very slow.
				} // if
			} // parallel
        } // if
		
        keyEvent = cvWaitKey(1);
        if (keyEvent == 27)break; // ESC      
        rc->drawPlatformOverview(incomingCaptureImage, halfx, halfy);
        if(modeselindication != "")reticle->drawReticle_text(incomingCaptureImage, 0, incomingCaptureImage.size().height - 20, modeselindication);
        if( !incomingCaptureImage.empty() ) { imshow( "Ballistica", incomingCaptureImage ); }
    }  // while
    cvReleaseCapture(&capture);
    capture =  NULL;
    cvDestroyWindow("Ballistica"); // The end
	if (argc) {  // Output the command line for future use.
		printf("Run by command:\n%s\n", command.c_str());
	}   // if
} // main



/**
Back notes (the stuff to be worked on, not yet ToDo (hmmmm says I)

Multithreading (DONE)
GPU usage

//	All well and good that a reticle was built from a file.
		//	Now what about a ballistics data sheet file that can be given to this program
		//	and used, foregoing the use of the GNU ballistics class in cases where it's preferable to 
		//	use a file for ballistics data?
		//
		//	Can this be based on Range Calcs in such manner that the file is filling uop range calculation values?

		// a function that pulls COGs from all tracking classes and runs comparison.... that might be good or an averaging system
		// like a comparator - but drops the ones that are way way off.

*/