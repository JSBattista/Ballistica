/*
 *<b>Ballistica Version 2.1 "Foe-hammer". </b><br>
 *<b>Copyright 2014 Ballistica Software Defined Scope System (SDSS)</b><br>
 *<pre>
 *   This program is free software: you can redistribute it and/or modify<br>
 *   it under the terms of the GNU General Public License as published by<br>
 *   the Free Software Foundation, either version 3 of the License, or<br>
 *   (at your option) any later version.<br>
 *   <br>
 *   This program is distributed in the hope that it will be useful,<br>
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of<br>
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the<br>
 *   GNU General Public License for more details.<br>
 *   <br>
 *   You should have received a copy of the GNU General Public License<br>
 *   along with this program.  If not, see &lt;http://www.gnu.org/licenses/&gt;.<br>
 * </pre>
 * <pre>
 *   This file is part of Ballistica.<br>
 *   <br>
 *   Ballistica is free software: you can redistribute it and/or modify<br>
 *   it under the terms of the GNU General Public License as published by<br>
 *   the Free Software Foundation, either version 3 of the License, or<br>
 *   (at your option) any later version.<br>
 *   <br>
 *   Ballistica is distributed in the hope that it will be useful,<br>
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of<br>
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the<br>
 *   GNU General Public License for more details.<br>
 *   <br>
 *   You should have received a copy of the GNU General Public License<br>
 *     along with Ballistica.  If not, see &lt;http://www.gnu.org/licenses/&gt;.<br>
*/
#include "ColorTrack.h"
#include <stdlib.h>
using namespace cv;
ColorTrack::ColorTrack(){
	lowbgr = Scalar(0,0,0);
	highbgr = Scalar(0,0,0);
	colorToleranceLow = 20;
	colorToleranceHigh = 10;
	drawColor = Scalar(255,0,0);
	sensitivity = 0;
	activeLocked = false;
	decay = 0;
	subbox = NULL;
}
ColorTrack::ColorTrack(Mat &pixelbuffer){
	colorToleranceLow = 20;
	colorToleranceHigh = 10;
	int halfx = pixelbuffer.size().width/2;
	int halfy = pixelbuffer.size().height/2;
	uint8_t* pixelPtr = (uint8_t*)pixelbuffer.data;
	int cn = pixelbuffer.channels();
    int lb = pixelPtr[halfx*pixelbuffer.cols*cn + halfy*cn + 0]-colorToleranceLow;  // low high mods hard coded here - should this be a controlled variable?
    int lg = pixelPtr[halfx*pixelbuffer.cols*cn + halfy*cn + 1]-colorToleranceLow;
    int lr = pixelPtr[halfx*pixelbuffer.cols*cn + halfy*cn + 2]-colorToleranceLow;
    int hb = pixelPtr[halfx*pixelbuffer.cols*cn + halfy*cn + 0]+colorToleranceHigh;
    int hg = pixelPtr[halfx*pixelbuffer.cols*cn + halfy*cn + 1]+colorToleranceHigh;
    int hr = pixelPtr[halfx*pixelbuffer.cols*cn + halfy*cn + 2]+colorToleranceHigh;
    if(lb < 0)lb = 0;
    if(lg < 0)lg = 0;
    if(lr < 0)lr = 0;
    if(hb > 255)hb = 255;
    if(hg > 255)hg = 255;
    if(hr > 255)hr = 255;
    lowbgr = (Scalar((unsigned short)lb, (unsigned short)lg, (unsigned short)lr));
    highbgr = (Scalar((unsigned short)hb, (unsigned short)hg, (unsigned short)hr));
	drawColor = Scalar(255,0,0);
	sensitivity = 100;
	activeLocked = true;		//deb100 dubious at best
	subbox = NULL;
}
ColorTrack::~ColorTrack() {}
void ColorTrack::modColorTrack(int  l, int  h){
	if((colorToleranceLow + l) > 255){
		colorToleranceLow = 255;
 	} else if ((colorToleranceLow + l) < 0){
 		colorToleranceLow = 0;
 	} else
 		colorToleranceLow += l;
	if((colorToleranceHigh + h) > 255){
		colorToleranceHigh = 255;
	} else if ((colorToleranceHigh + h) < 0){
		colorToleranceHigh = 0;
	}else
		colorToleranceHigh += h;
}
int ColorTrack::getColorTrackModLow(){return colorToleranceLow;}
int ColorTrack::getColorTrackModHigh(){return colorToleranceHigh;}
Point ColorTrack::processColorTracking(Mat &image){
	Mat idiff = Mat(Size(image.size().width, image.size().height), IPL_DEPTH_8U, 1);
	inRange(image, lowbgr, highbgr, idiff);  // Color Detection
	medianBlur(idiff, idiff, 1 );	
	pixelcount = countNonZero(idiff);   // non-zero (non-black) means motion
	Moments moms = moments(idiff, true);
	area = moms.m00;
	if (moms.m00 >  0) {   // create COG Point        moms.m00 is "area"
			return Point((int) floor((moms.m10/moms.m00) + 0.5), floor((moms.m01/moms.m00) + 0.5));  // moms.m10.moms.m00 is X moms.m01/moms.m00 is Y
	} // if
	activeLocked = false;
	return Point(0, 0);
}
Point ColorTrack::processColorTracking(){
	Mat idiff = Mat(Size(subbox.size().width, subbox.size().height), IPL_DEPTH_8U, 1);
	inRange(subbox, lowbgr, highbgr, idiff);  // Color Detection
	medianBlur(idiff, idiff, 1 );	
	pixelcount = countNonZero(idiff);   // non-zero (non-black) means motion
	Moments moms = moments(idiff, true);
	area = moms.m00;
	if (moms.m00 >  0) {   // create COG Point        moms.m00 is "area"
			return Point((int) floor((moms.m10/moms.m00) + 0.5), floor((moms.m01/moms.m00) + 0.5));  // moms.m10.moms.m00 is X moms.m01/moms.m00 is Y
	} // if
	activeLocked = false;
	subbox = NULL;
	return Point(0, 0);
}
int ColorTrack::getArea(){
	return (int)area;
}
int ColorTrack::getPixelCount(){
	return	pixelcount;
}
bool ColorTrack::locked(){
	return activeLocked;
}
bool ColorTrack::checkSensitivityThreshold(){
	decay--;		// Side effect
	if(pixelcount > sensitivity){  // And the rectangle has to have some substance to it. 
		if ((area != 0) && (decay > 0)) { 
			return true;
		} else {
			activeLocked = false;
			pixelcount = 0;
			decay = 0;
		} // if
	} // if
}
void ColorTrack::drawColorCapture(Mat& g, int x, int y, String s){
	// Incoming X and Y values are the screen center.
	int dim = 20;
	int halfdim = 10;
	rectangle(g, Rect(x-halfdim, y-halfdim, dim, dim),Scalar(255,255,255), 1, 1, 0);
	line(g, Point(x-dim, y), Point(x-halfdim, y), Scalar(255,255,255), 1,1,1);
	line(g, Point(x+halfdim, y), Point(x+dim, y), Scalar(255,255,255), 1,1,1);
	line(g, Point(x, y-dim), Point(x, y-halfdim), Scalar(255,255,255), 1,1,1);
	line(g, Point(x, y+halfdim), Point(x, y+dim), Scalar(255,255,255), 1,1,1);
	putText(g,s,Point(x+dim, y-halfdim), 1, 0.9, Scalar(255,255,255), 1, 1, false);
}
void ColorTrack::drawColorTolerance(Mat& g, int x, int y){
	stringstream oss;
	oss << "COLOR RANGE LOW " << colorToleranceLow;
	putText(g, oss.str(),Point(x-150, y-20), 1, 0.9, Scalar(255,255,255), 1, 1, false);
	oss.str("");
	oss << "COLOR RANGE HIGH " << colorToleranceHigh;
	putText(g, oss.str(),Point(x+100, y-20), 1, 0.9, Scalar(255,255,255), 1, 1, false);
	rectangle(g, Rect(x-50, y, 100, 20),Scalar(255,255,255), 1, 1, 0);
	line(g, Point(x-40, y), Point(x-40, y+20), Scalar(255,255,255), 1,1,0);
	line(g, Point(x-30, y), Point(x-30, y+20), Scalar(255,255,255), 1,1,0);
	line(g, Point(x-20, y), Point(x-20, y+20), Scalar(255,255,255), 1,1,0);
	line(g, Point(x-10, y), Point(x-10, y+20), Scalar(255,255,255), 1,1,0);
	line(g, Point(x, y),    Point(x,    y+20), Scalar(000,000,255), 2,1,0);
	line(g, Point(x+10, y), Point(x+10, y+20), Scalar(255,255,255), 1,1,0);
	line(g, Point(x+20, y), Point(x+20, y+20), Scalar(255,255,255), 1,1,0);
	line(g, Point(x+30, y), Point(x+30, y+20), Scalar(255,255,255), 1,1,0);
	line(g, Point(x+40, y), Point(x+40, y+20), Scalar(255,255,255), 1,1,0);
}


void ColorTrack::setTargetBox(int x, int y){
	defaultL = 60;      // Default Length of box
	defaultH = 60;      // Default Height of box
	screenReferenceCOG = cv::Point(x, y);
	subboxReferenceCOG = cv::Point((int)defaultL/2, (int)defaultH/2);   // Center in the cv::Rect Construct
	subboxbrect = cv::Rect(x, y, defaultL, defaultH);	
	decay  = 10000;
	sensitivity = area;
	activeLocked = true;
}
void ColorTrack::setTargetBox(int x, int y, int w, int h){
	defaultL = 60;      // Default Length of box
	defaultH = 60;      // Default Height of box
	screenReferenceCOG = cv::Point(x, y);
	subboxReferenceCOG = cv::Point((int)w/2, (int)h/2);   // Center in the cv::Rect Construct
	subboxbrect = cv::Rect(x, y, w, h);	
	decay  = 10000;
	sensitivity = area;
	activeLocked = true;
}
void ColorTrack::setTargetBox(Rect r){
	defaultL = 60;      // Default Length of box
	defaultH = 60;      // Default Height of box
	screenReferenceCOG = cv::Point(r.x, r.y);
	subboxReferenceCOG = cv::Point((int)r.width/2, (int)r.height/2);   // Center in the cv::Rect Construct
	subboxbrect = r;
	decay  = 10000;
	sensitivity = area;
	activeLocked = true;
}
Rect ColorTrack::getCurrentRectangle(){
	return subboxbrect;
}
bool ColorTrack::checkROIBoundaries(int imgx, int imgy){
	if((subboxbrect.x + subboxbrect.width/2) >= imgx-10) return false;  // X bounds exceeded.
	if((subboxbrect.x - subboxbrect.width/2) <= 0+10) return false; // unlikely but check anyway
	if((subboxbrect.y + subboxbrect.height/2) >= imgy-10) return false;  // Y bounds exceeded.
	if((subboxbrect.y - subboxbrect.height/2) <= 0+10) return false; // unlikely but check anyway
	return true; // made it this far, checks good.
}
void ColorTrack::applyCOGDisplacement(cv::Point modCOG){
	//  This function is called after there is a movement detecton in a sub-box,
	//  The COG of the box itself is always the center, and the box itself was searched for movement (plus a little more),
	//  But the entire cv::Rect that defines the target box must be moved the distance of the displacement
	//  of the incoming COG data the differs from the cog of the sub-box.
	if (modCOG == subboxReferenceCOG) return;  // unlikely
	if(modCOG.x < subboxReferenceCOG.x) {
		subboxbrect.x -= abs(modCOG.x - subboxReferenceCOG.x);  // move the entire cv::Rect's position on the entire screen.
		screenReferenceCOG.x -= abs(modCOG.x - subboxReferenceCOG.x);  // Adjust the COG of the movement detected as carried in from the cvmoment call results
	} else if (modCOG.x > subboxReferenceCOG.x){
		subboxbrect.x += abs(modCOG.x - subboxReferenceCOG.x);
		screenReferenceCOG.x += abs(modCOG.x - subboxReferenceCOG.x);
	} else {
		// nothing
	}  // if
	if(modCOG.y < subboxReferenceCOG.y) {
		subboxbrect.y -= abs(modCOG.y - subboxReferenceCOG.y);
		screenReferenceCOG.y -= abs(modCOG.y - subboxReferenceCOG.y);
	} else if (modCOG.y > subboxReferenceCOG.y){
		subboxbrect.y += abs(modCOG.y - subboxReferenceCOG.y);
		screenReferenceCOG.y += abs(modCOG.y - subboxReferenceCOG.y);
	} else {
		// nothing
	}  // if
}
void ColorTrack::drawTargetBox(Mat& g){  // Simple indication is something -
	cv::rectangle(g, Rect(subboxbrect.x-(int)(subboxbrect.width/2),subboxbrect.y-(int)(subboxbrect.height/2),subboxbrect.height, subboxbrect.width), drawColor, 2, 1, 0);
}
cv::Point  ColorTrack::getTargetBoxCenter(){
	cv::Point p = cv::Point();
//	p.x = screenReferenceCOG.x;
//	p.y = screenReferenceCOG.y;

	p.x = subboxbrect.x + (int)(subboxbrect.width/2);
	p.y = subboxbrect.y + (int)(subboxbrect.height/2);
	return p;
}

