/*
 *<b>Ballistica Version 2.1 "Foe-hammer". </b><br>
 *<b>Copyright 2014 Ballistica Software Defined Scope System (SDSS)</b><br>
 *<pre>
 *   This program is free software: you can redistribute it and/or modify<br>
 *   it under the terms of the GNU General Public License as published by<br>
 *   the Free Software Foundation, either version 3 of the License, or<br>
 *   (at your option) any later version.<br>
 *   <br>
 *   This program is distributed in the hope that it will be useful,<br>
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of<br>
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the<br>
 *   GNU General Public License for more details.<br>
 *   <br>
 *   You should have received a copy of the GNU General Public License<br>
 *   along with this program.  If not, see &lt;http://www.gnu.org/licenses/&gt;.<br>
 * </pre>
 * <pre>
 *   This file is part of Ballistica.<br>
 *   <br>
 *   Ballistica is free software: you can redistribute it and/or modify<br>
 *   it under the terms of the GNU General Public License as published by<br>
 *   the Free Software Foundation, either version 3 of the License, or<br>
 *   (at your option) any later version.<br>
 *   <br>
 *   Ballistica is distributed in the hope that it will be useful,<br>
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of<br>
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the<br>
 *   GNU General Public License for more details.<br>
 *   <br>
 *   You should have received a copy of the GNU General Public License<br>
 *     along with Ballistica.  If not, see &lt;http://www.gnu.org/licenses/&gt;.<br>
*/
#include "ImageTrack.h"
#include <stdio.h>
using namespace cv;
ImageTrack::ImageTrack(){
	xlimit = 200;
	ylimit = 200;
	aperturesize = 20;	// default initial setting.
	drawColor = Scalar(255,255,255);
	displacement = (unsigned int)((aperturesize - (aperturesize - 4))/2);	// This is to help keep the targeting reticle out of the capture image.	
	sensitivity = 1;	//deb100  check this - originally a 0 was being used
	activeLocked = false;
	decay = 0;
	subbox = NULL;
}
unsigned int ImageTrack::getCaptureReticleSize(){
	return aperturesize;
}
void ImageTrack::setCaptureApertureSize(unsigned int c){
	aperturesize = c;
	displacement = (unsigned int)((c - (c - 4))/2);	// This is to help keep the targeting reticle out of the capture image.
}
unsigned int ImageTrack::getDisplacement() {
	return displacement;
}
void ImageTrack::setTrackingImage(Mat &image, int x, int y){
	if ((x==0)&&(y==0)){  // this means to use the central point.
		x = (int)(image.size().width/2);
		y = (int)(image.size().height/2);
	} // if
	int halfap = (int)(aperturesize/2);	// Offset position (rect location not on a central origin)
	//Rect r = Rect(x-halfap, y-halfap, aperturesize, aperturesize);
	aperture = Rect(x-halfap, y-halfap, aperturesize, aperturesize);
	//Mat roi(image, r);
	Mat roi(image, aperture);
	//trackimage = Mat(Size(r.height, r.width), IPL_DEPTH_1U, 1);
	trackimage = Mat(Size(aperture.height, aperture.width), IPL_DEPTH_1U, 1);
	trackimage = roi.clone();
	int iwidth = abs(image.size().width - trackimage.size().width + 1);
	int iheight = abs(image.size().height - trackimage.size().height + 1);
	matchresult=  Mat( Size( iwidth, iheight ), IPL_DEPTH_1U, 1 );
	sensitivity = 0;
}
ImageTrack::~ImageTrack(){}
Point ImageTrack::processImageTracking(Mat &image){
	matchTemplate( image, trackimage, matchresult, CV_TM_SQDIFF); // see actual variable names  CV_TM_SQDIFF works
	convertScaleAbs(matchresult, difference, 10000, 0);
	medianBlur(difference, difference, 0 );
	pixelcount = countNonZero(difference);   // non-zero (non-black) means motion
	Moments moms = moments(difference, true);
	area = moms.m00;
	if (moms.m00 >  0) {   // create COG Point        moms.m00 is "area"
		return Point((int) (floor((moms.m10/moms.m00) + 0.5)+(area)), (int)(floor((moms.m01/moms.m00) + 0.5)+(area)));  // moms.m10.moms.m00 is X moms.m01/moms.m00 is Y
	} // if
	activeLocked = false;
	return Point (0,0);
	//deb100  here would also be a chance to go ahead and set aside a magnified sub-image? :-)
}
Point ImageTrack::processImageTracking(){
	matchTemplate( subbox, trackimage, matchresult, CV_TM_SQDIFF); // see actual variable names  CV_TM_SQDIFF works
	convertScaleAbs(matchresult, difference, 10000, 0);
	medianBlur(difference, difference, 0 );
	pixelcount = countNonZero(difference);   // non-zero (non-black) means motion
	Moments moms = moments(difference, true);
	area = moms.m00;
	if (moms.m00 >  0) {   // create COG Point        moms.m00 is "area"
		return Point((int) (floor((moms.m10/moms.m00) + 0.5)+(area)), (int)(floor((moms.m01/moms.m00) + 0.5)+(area)));  // moms.m10.moms.m00 is X moms.m01/moms.m00 is Y
	} // if
	activeLocked = false;
	return Point (0,0);
	//deb100  here would also be a chance to go ahead and set aside a magnified sub-image? :-)
}
int ImageTrack::getArea(){
	return (int)area;
}
int ImageTrack::getPixelCount(){
	return	pixelcount;
}
bool ImageTrack::locked(){
	return activeLocked;
}
bool ImageTrack::checkSensitivityThreshold(){
	decay--;		// Side effect
	if(pixelcount > sensitivity){  // And the rectangle has to have some substance to it. 
		if ((area != 0) && (decay > 0)) { 
			return true;
		} else {
			activeLocked = false;
			pixelcount = 0;
			decay = 0;
		} // if
	} // if
}
void ImageTrack::drawImageCapture(Mat& g, int x, int y, String s){
	// Incoming X and Y values are the screen center.
	unsigned int halfdim = (int)(aperturesize / 2);
	unsigned int halfdisp = (int)displacement/2;
	rectangle(g, Rect(x-halfdim-halfdisp, y-halfdim-halfdisp, aperturesize+displacement, aperturesize+displacement),Scalar(255,255,255), 1, 1, 0);  // Keep lines out of actual capture zone
	putText(g,s,Point(x+aperturesize, y-halfdim), 1, 0.9, Scalar(255,255,255), 1, 1, false);
}

void ImageTrack::setTargetBox(int x, int y){
	defaultL = aperturesize*3;      // Default Length of box
	defaultH = aperturesize*3;      // Default Height of box
	screenReferenceCOG = cv::Point(x, y);
	subboxReferenceCOG = cv::Point((int)defaultL/2, (int)defaultH/2);   // Center in the cv::Rect Construct
	subboxbrect = cv::Rect(x, y, defaultL, defaultH);	
	decay  = 10000;
	sensitivity = area;
	activeLocked = true;
}
void ImageTrack::setTargetBox(Rect r){
	defaultL = 60;      // Default Length of box
	defaultH = 60;      // Default Height of box
	screenReferenceCOG = cv::Point(r.x, r.y);
	subboxReferenceCOG = cv::Point((int)r.width/2, (int)r.height/2);   // Center in the cv::Rect Construct
	subboxbrect = r;
	decay  = 10000;
	sensitivity = area;
	activeLocked = true;
}
Rect ImageTrack::getCurrentRectangle(){
	return subboxbrect;
}
bool ImageTrack::checkROIBoundaries(int imgx, int imgy){
	if((subboxbrect.x + subboxbrect.width/2) >= imgx-10) return false;  // X bounds exceeded.
	if((subboxbrect.x - subboxbrect.width/2) <= 0+10) return false; // unlikely but check anyway
	if((subboxbrect.y + subboxbrect.height/2) >= imgy-10) return false;  // Y bounds exceeded.
	if((subboxbrect.y - subboxbrect.height/2) <= 0+10) return false; // unlikely but check anyway	
	return true; // made it this far, checks good.
}
void ImageTrack::applyCOGDisplacement(cv::Point modCOG){
	//  This function is called after there is a movement detecton in a sub-box,
	//  The COG of the box itself is always the center, and the box itself was searched for movement (plus a little more),
	//  But the entire cv::Rect that defines the target box must be moved the distance of the displacement
	//  of the incoming COG data the differs from the cog of the sub-box.
	if (modCOG == subboxReferenceCOG) return;  // unlikely
	if(modCOG.x < subboxReferenceCOG.x) {
		subboxbrect.x -= abs(modCOG.x - subboxReferenceCOG.x);  // move the entire cv::Rect's position on the entire screen.
		screenReferenceCOG.x -= abs(modCOG.x - subboxReferenceCOG.x);  // Adjust the COG of the movement detected as carried in from the cvmoment call results
	} else if (modCOG.x > subboxReferenceCOG.x){
		subboxbrect.x += abs(modCOG.x - subboxReferenceCOG.x);
		screenReferenceCOG.x += abs(modCOG.x - subboxReferenceCOG.x);
	} else {
		// nothing
	}  // if
	if(modCOG.y < subboxReferenceCOG.y) {
		subboxbrect.y -= abs(modCOG.y - subboxReferenceCOG.y);
		screenReferenceCOG.y -= abs(modCOG.y - subboxReferenceCOG.y);
	} else if (modCOG.y > subboxReferenceCOG.y){
		subboxbrect.y += abs(modCOG.y - subboxReferenceCOG.y);
		screenReferenceCOG.y += abs(modCOG.y - subboxReferenceCOG.y);
	} else {
		// nothing
	}  // if
}
void ImageTrack::drawTargetBox(Mat& g){  
	cv::rectangle(g, Rect(subboxbrect.x-(int)(subboxbrect.width/2),subboxbrect.y-(int)(subboxbrect.height/2),subboxbrect.height, subboxbrect.width), drawColor, 2, 1, 0);
}
cv::Point  ImageTrack::getTargetBoxCenter(){
	cv::Point p = cv::Point();
//	p.x = screenReferenceCOG.x;
//	p.y = screenReferenceCOG.y;

	p.x = subboxbrect.x + (int)(subboxbrect.width/2);
	p.y = subboxbrect.y + (int)(subboxbrect.height/2);
	return p;
}


// this function has the side effect of changing the sub box rectangle to either one that's closer.
bool ImageTrack::compareAssignRect(Rect r1, Rect r2){
	// roughly 10 pixels tends to be the range of deviation when looking for an image in an image.
	if((abs(r1.x - subboxbrect.x) < 10) && (abs(r1.y -  subboxbrect.y) < 10)){
		setTargetBox(r1.x, r1.y); // Rectangle 1 meets criteria.
		return true;
	} // if
	if((abs(r2.x - subboxbrect.x) < 10) && (abs(r2.y -  subboxbrect.y) < 10)){
		setTargetBox(r2.x, r2.y);
		return true;
	} // if
	return false;
}